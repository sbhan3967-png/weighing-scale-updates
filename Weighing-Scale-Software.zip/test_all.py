"""Headless TEST 1-10 from the brief, run against db.py + excel_export.py.
GUI is not launched (no display needed); every calculation path is shared with the GUI.
"""
import os, sys, shutil, tempfile
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from db import Database, OverWeightError, ValidationError
from excel_export import sync_excel, excel_path_for, pending_dates
from openpyxl import load_workbook

base = tempfile.mkdtemp(prefix="weighing_test_")
print("test base:", base)
db = Database(base)
D = "2026-10-31"
D2 = "2026-11-01"

# TEST 1: category + salesperson (categories pre-seeded; add a new one + salesperson)
db.add_category("TEST CATEGORY")
db.add_salesperson("Rahul")
assert any(c["name"] == "TEST CATEGORY" for c in db.categories())
assert any(s["name"] == "Rahul" for s in db.salespersons())
print("TEST 1 PASS: category + salesperson created")

# TEST 2: open box 126.44
box = db.create_box("LADIES RING", "Rahul", 126.44, d=D, metal="GOLD")
assert box == "BOX-20261031-001", box
s = db.box_summary(box)
assert s["opening_weight"] == 126.44 and s["remaining"] == 126.44
print("TEST 2 PASS:", box, "opening 126.44")

# TEST 3: sale 26.44 -> remaining 100.00 (the screenshot case, and brief case)
db.add_sale(box, 26.44, "test sale", )
s = db.box_summary(box)
assert s["remaining"] == 100.00, s
print("TEST 3 PASS: 126.44 - 26.44 =", s["remaining"])

# TEST 4: another sale
db.add_sale(box, 5.00, "second sale")
db.add_sale(box, 10.00, "third sale")
s = db.box_summary(box)
assert s["remaining"] == 85.00, s
print("TEST 4 PASS: remaining after +5 +10 =", s["remaining"])

# Overweight guard
try:
    db.add_sale(box, 999.00, "too much")
    raise AssertionError("overweight sale should have raised")
except OverWeightError as e:
    print("  overweight guard PASS:", e)
# override with reason works, audited
db.add_sale(box, 90.00, "override test", override=True, override_reason="manager approved")
s = db.box_summary(box)
assert s["remaining"] == -5.00, s
print("  override PASS, remaining", s["remaining"], "(negative only with reason)")

# TEST 5/6: close + reopen same day -> all data restored
db.close()
db2 = Database(base)
s = db2.box_summary(box)
assert s["remaining"] == -5.00 and len(db2.daily_transactions(D)) == 5, (s, db2.daily_transactions(D))
print("TEST 5/6 PASS: close + reopen restores box, sales, remaining -5.00")

# Correction + void audit
txns = db2.daily_transactions(D)
sale_txn = [t for t in txns if t["type"] == "SALE"][0]
db2.correct_transaction(sale_txn["txn_id"], 26.44, "test correction keeps value")
db2.void_transaction([t for t in txns if t["type"] == "SALE"][-1]["txn_id"], "test void")
s = db2.box_summary(box)
# after voiding the 90g override sale: 126.44-26.44-5-10 = 85.00
assert s["remaining"] == 85.00, s
print("  correction + void PASS, remaining back to", s["remaining"])

# TEST 7: new day is fresh, history kept
assert db2.daily_transactions(D2) == []
assert db2.daily_totals(D2)["boxes"] == 0
assert db2.daily_totals(D)["boxes"] == 1
print("TEST 7 PASS: 01-11 fresh, 31-10 history intact")

# TEST 8: return box with actual weight -> difference
res = db2.return_box(box, 84.50, "scale shows 0.50 less")
assert res["expected"] == 85.00 and res["difference"] == -0.50, res
print("TEST 8 PASS: expected 85.00, actual 84.50, diff", res["difference"])

# TEST 9: Excel for 31-10 contains transactions + totals
status = sync_excel(db2, D)
assert status == "ok", status
path = excel_path_for(base, D)
assert os.path.exists(path), path
wb = load_workbook(path, data_only=True)
ws = wb["Daily Report"]
vals = [c.value for row in ws.iter_rows(min_row=1, max_row=60) for c in row if c.value is not None]
assert "BOX-20261031-001" in vals
assert any(v == 126.44 or v == 126.44 for v in vals)
print("TEST 9 PASS: Excel exists at", path, "| sheets:", wb.sheetnames)

# TEST 10: locked Excel -> DB transaction still saved, Excel queued
# Simulate lock by making the target a directory? Instead: hold file open is not a lock on Linux,
# so test the queue path directly: point sync at a read-only location is complex.
# Direct check: sync_excel returns 'queued' when os.replace fails — simulate by replacing
# the excel file with a directory so save fails, then verify DB write still happened.
import excel_export
orig_path_fn = excel_export.excel_path_for
locked_dir = os.path.join(base, "locked.xlsx")
os.makedirs(locked_dir, exist_ok=True)
# monkeypatch excel_path_for to return the directory path -> save will fail -> queued
excel_export.excel_path_for = lambda b, d: locked_dir
db2.add_salesperson("LockedTest")
# a new box on D2 to generate a txn, then sync (should queue, not crash, not lose DB)
box2 = db2.create_box("GENTS RING", "Rahul", 50.00, d=D2, metal="SILVER")
st = sync_excel(db2, D2)
assert st == "queued", st
assert pending_dates(base) == [D2] or D2 in pending_dates(base)
assert db2.box_summary(box2)["remaining"] == 50.00
print("TEST 10 PASS: locked Excel -> status queued, DB transaction intact, pending recorded:", pending_dates(base))
excel_export.excel_path_for = orig_path_fn
# retry after 'unlock' (restore normal path) succeeds
res2 = excel_export.retry_pending(db2)
print("  retry after unlock:", res2)
assert os.path.exists(excel_path_for(base, D2))


# TEST 11 (v1.19): 4-decimal Mettler weights, exactly as printed
box4 = db2.create_box("LADIES RING", "Rahul", 400.1234, d=D2, metal="GOLD")
db2.add_sale(box4, 100.0001, "4dp sale")
s = db2.box_summary(box4)
assert s["remaining"] == 300.1233, s
res = db2.return_box(box4, 300.1233, "")
assert res["difference"] == 0, res
print("TEST 11 PASS: 400.1234 - 100.0001 = 300.1233, return diff 0 (4 decimals kept)")

# TEST 12 (v1.19): attendance — mark, re-mark updates (no duplicate), summary
db2.mark_attendance(D2, "Rahul", "PRESENT", in_time="10:00", out_time="20:30", remarks="On time")
db2.mark_attendance(D2, "Rahul", "HALF DAY", in_time="10:00", out_time="14:00", remarks="Left early")
rows = db2.attendance_for_date(D2)
rahul = [r for r in rows if r["salesperson"] == "Rahul"][0]
assert rahul["status"] == "HALF DAY" and rahul["out_time"] == "14:00", rahul
assert len([r for r in rows if r["salesperson"] == "Rahul"]) == 1
summ = db2.attendance_summary(D2)
assert summ["half_day"] == 1 and summ["marked"] >= 1, summ
try:
    db2.mark_attendance(D2, "Rahul", "PRESENT", in_time="25:00")
    raise AssertionError("bad time should fail")
except ValidationError:
    pass
print("TEST 12 PASS: attendance mark + re-mark update + summary:", summ)

# Backup
dest = db2.backup()
assert os.path.exists(dest)
print("BACKUP PASS:", dest)
db2.close()
print("\nALL TESTS PASSED")
