"""Live MCX gold / silver rates for the Weighing Scale dashboard banner.

Source: https://mcxlive.org — its gold page (mcxlive.org/gold/) and
silver page (mcxlive.org/silver/) each carry a server-rendered
"Last Trade" table (Last Trade / Change / Change in %, plus High /
Low / Open, the contract month, the site's own "As on" time and the
last-trade time). There is NO public per-minute API on that site, so
this module fetches those two pages and parses that table.

Honest limits, so the banner never over-claims:
- The banner can only be as fresh as mcxlive.org itself. The app
  fetches every 60 seconds, and the banner updates the moment the
  site's table changes — but if the site (or its cache) only updates
  every few minutes, or the market is closed (Mon–Fri 10:00 AM to
  11:30/11:55 PM IST, closed weekends/holidays), the values will
  simply stay at the last trade. The banner always shows the site's
  own "As on" time and the last-trade time, so a stale rate is
  visible as stale, never passed off as live.
- Gold is quoted per 10 g, silver per 1 kg, exactly as MCX quotes
  them on those pages. The banner says so on every scroll.
- No internet, a blocked page, or a changed page layout must never
  crash the app: fetch_mcx_rates() returns None on any failure and
  the caller keeps showing the last good rate, marked offline.

Only the two pages above are fetched, once a minute, with a normal
browser User-Agent and a 15-second timeout. Nothing is posted, no
login is used, and no other page on the site is crawled.
"""
import gzip
import re
import urllib.request
from datetime import datetime

GOLD_URL = "https://mcxlive.org/gold/"
SILVER_URL = "https://mcxlive.org/silver/"
SOURCE = "mcxlive.org"

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                  "(KHTML, like Gecko) Chrome/124.0 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml",
    "Accept-Encoding": "gzip, deflate",
    "Accept-Language": "en-IN,en;q=0.9",
}


def _clean_num(s):
    return s.replace(",", "").strip()


def parse_mcx_page(html, metal):
    """Parse one mcxlive.org gold/silver page. Returns a dict, or None
    if the page layout has changed (so the caller can keep the old rate
    instead of showing a half-parsed number)."""
    if not html:
        return None
    try:
        contract_m = re.search(
            r'<h2 class="main-head">MCX (?:Gold|Silver)\s+([^<]+)</h2>', html)
        as_on_m = re.search(r'As on\s+([^<]+?),\s*India Time', html)
        last_trade_m = re.search(
            r'Last Trade on\s+([^<]+?)(?:,\s*Market Close|<)', html)
        # First table after the heading: Last Trade / Change / Change in %
        last_m = re.search(
            r'Last Trade</td>.*?<td class="main-change[^"]*">.*?([\d,]+)</td>'
            r'\s*<td class="main-change[^"]*">\s*(-?[\d,]+)</td>'
            r'\s*<td class="main-change[^"]*">\s*(-?[\d.]+%)</td>',
            html, re.S)
        # Second table: High / Low / Open
        hlo_m = re.search(
            r'High</td>.*?<td class="main-sub">\s*([\d,]+)</td>'
            r'\s*<td class="main-sub">\s*([\d,]+)</td>'
            r'\s*<td class="main-sub">\s*([\d,]+)</td>',
            html, re.S)
        if not last_m:
            return None
        last = float(_clean_num(last_m.group(1)))
        change = float(_clean_num(last_m.group(2)))
        pct = last_m.group(3).strip()
        out = {
            "metal": metal,
            "last": last,
            "change": change,
            "change_pct": pct,
            "contract": (contract_m.group(1).strip() if contract_m else ""),
            "as_on": (as_on_m.group(1).strip() if as_on_m else ""),
            "last_trade": (last_trade_m.group(1).strip() if last_trade_m else ""),
            "unit": "10 g" if metal == "GOLD" else "1 kg",
        }
        if hlo_m:
            out["high"] = float(_clean_num(hlo_m.group(1)))
            out["low"] = float(_clean_num(hlo_m.group(2)))
            out["open"] = float(_clean_num(hlo_m.group(3)))
        return out
    except Exception:
        return None


def _fetch_page(url, timeout=15):
    req = urllib.request.Request(url, headers=HEADERS)
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        raw = resp.read()
        if resp.headers.get("Content-Encoding") == "gzip":
            raw = gzip.decompress(raw)
        return raw.decode("utf-8", errors="ignore")


def fetch_mcx_rates(timeout=15):
    """Fetch gold + silver from mcxlive.org. Returns
    {"gold": {...}, "silver": {...}, "fetched_at": datetime} or None
    if either page could not be fetched or parsed. Callers must keep
    the previous good result on None."""
    try:
        gold = parse_mcx_page(_fetch_page(GOLD_URL, timeout), "GOLD")
        silver = parse_mcx_page(_fetch_page(SILVER_URL, timeout), "SILVER")
        if not gold or not silver:
            return None
        return {"gold": gold, "silver": silver, "fetched_at": datetime.now()}
    except Exception:
        return None


def _fmt_price(v):
    # Indian grouping: 138419 -> 1,38,419
    s = f"{int(round(v)):,}"
    # Python groups by 3; convert to Indian grouping for >= 5 digits.
    if len(s.replace(",", "")) > 3:
        digits = s.replace(",", "")
        head, tail = digits[:-3], digits[-3:]
        parts = []
        while len(head) > 2:
            parts.insert(0, head[-2:])
            head = head[:-2]
        if head:
            parts.insert(0, head)
        s = ",".join(parts + [tail])
    return s


def banner_text(rates, status=""):
    """One scrolling line for the dashboard banner — gold and silver
    only, no dates and no extra text (v1.21: contract date, last-trade
    time, site-updated time and source were removed from the scroll).
    The status (LIVE / OFFLINE) is shown in the small label at the
    right edge of the banner, not in the scrolling text, and the
    status argument is kept only so old callers still work."""
    if not rates:
        return "  Fetching live MCX rates…  "
    def _one(r):
        arrow = "▲" if r["change"] > 0 else ("▼" if r["change"] < 0 else "•")
        chg_abs = _fmt_price(abs(r["change"]))
        chg = ("+" if r["change"] > 0 else "-") + chg_abs if r["change"] else "0"
        return (f"MCX {r['metal']}  ₹{_fmt_price(r['last'])} / {r['unit']}  "
                f"{arrow} {chg} ({r['change_pct']})")
    gold, silver = rates["gold"], rates["silver"]
    return f"  {_one(gold)}    •    {_one(silver)}    "


if __name__ == "__main__":
    import sys
    r = fetch_mcx_rates()
    if not r:
        print("FETCH FAILED")
        sys.exit(1)
    print(banner_text(r, status="LIVE"))
    print(r)
