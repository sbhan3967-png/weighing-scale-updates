"""Weighing Scale - Jewellery Box Management & Daily Weighing Software.
Offline Windows desktop app: tkinter + SQLite + openpyxl.
Run:  python app.py        (after Setup.bat on Windows)
Data lives in Documents\\Weighing Scale\\  (Database / Daily Reports / Backups).
"""
import os, sys, json, subprocess, threading, tkinter as tk
from tkinter import ttk, messagebox, filedialog
from datetime import datetime, date
import db as dbmod
from db import Database, ValidationError, OverWeightError, today_str, fmt_date
from excel_export import sync_excel, retry_pending, pending_dates, excel_path_for
import updater as updater_mod
from updater import CURRENT_VERSION

# --- data location: sidecar file next to app.py, else Documents\Weighing Scale ---
APP_DIR = os.path.dirname(os.path.abspath(__file__))
SIDECAR = os.path.join(APP_DIR, "data_location.txt")

def resolve_base_dir():
    if os.path.exists(SIDECAR):
        try:
            p = open(SIDECAR).read().strip()
            if p:
                return p
        except Exception:
            pass
    return dbmod.default_base_dir()

DB = Database(resolve_base_dir())
# Rename migration: v1.0 shipped with AURUM DIAMONDS as the default showroom.
# Any existing install still on that old default follows the rename to Ramanand.
try:
    if DB.get_setting("showroom_name", "") == "AURUM DIAMONDS":
        DB.set_setting("showroom_name", "RAMANAND JEWELLERS")
except Exception:
    pass
GOLD = "#C9A227"
# CURRENT_VERSION lives in updater.py (single source of truth for the update channel)
PAYMENT_MODES = ["CASH", "UPI", "CARD", "BANK TRANSFER", "CREDIT / UDHAAR", "CHEQUE", "OTHER"]

def open_file(path):
    try:
        if sys.platform.startswith("win"):
            os.startfile(path)  # noqa
        elif sys.platform == "darwin":
            subprocess.Popen(["open", path])
        else:
            subprocess.Popen(["xdg-open", path])
    except Exception as e:
        messagebox.showerror("Cannot open", str(e))

def parse_ddmmyyyy(s):
    s = (s or "").strip()
    try:
        return datetime.strptime(s, "%d-%m-%Y").strftime("%Y-%m-%d")
    except Exception:
        raise ValidationError("Date must be DD-MM-YYYY, e.g. 31-10-2026.")

def fmt_time(dt_str=None):
    fmt = DB.get_setting("time_format", "12-hour")
    now = datetime.now()
    if dt_str:
        try:
            now = datetime.strptime(dt_str, "%Y-%m-%d %H:%M:%S")
        except Exception:
            pass
    return now.strftime("%I:%M:%S %p" if fmt == "12-hour" else "%H:%M:%S")

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Weighing Scale — Ramanand Jewellers")
        self.geometry("1180x720")
        try:
            _icon = os.path.join(APP_DIR, "icon.ico")
            if os.path.exists(_icon):
                self.iconbitmap(_icon)
        except Exception:
            pass
        self.configure(bg="#F7F3E8")
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except Exception:
            pass
        style.configure("Gold.TButton", background=GOLD, foreground="white", font=("Segoe UI", 11, "bold"), padding=8)
        style.configure("TNotebook.Tab", font=("Segoe UI", 10, "bold"), padding=(10, 6))

        # Header
        head = tk.Frame(self, bg="white")
        head.pack(fill="x", padx=10, pady=10)
        self.showroom_lbl = tk.Label(head, text=DB.get_setting("showroom_name", "RAMANAND JEWELLERS"),
                                     font=("Segoe UI", 18, "bold"), bg="white", fg="#333333")
        self.showroom_lbl.pack(side="left", padx=10)
        tk.Label(head, text="Jewellery Box Management  •  Daily Weighing", font=("Segoe UI", 10),
                 bg="white", fg="#7A5C00").pack(side="left", padx=6)
        self.clock_lbl = tk.Label(head, font=("Segoe UI", 11, "bold"), bg="white", fg="#333333")
        self.clock_lbl.pack(side="right", padx=10)
        self.pending_lbl = tk.Label(head, font=("Segoe UI", 9, "bold"), bg="white", fg="#B00000")
        self.pending_lbl.pack(side="right", padx=6)

        self.nb = ttk.Notebook(self)
        self.nb.pack(fill="both", expand=True, padx=10, pady=(0, 10))
        self.build_dashboard()
        self.build_daily()
        self.build_reports()
        self.build_salesperson()
        self.build_settings()
        self.build_backup()
        self.refresh_all()
        self.tick()
        self.protocol("WM_DELETE_WINDOW", self.on_close)
        # Auto-update check: background thread, never blocks the UI.
        # If the GitHub channel is not live yet (or there is no internet),
        # check_for_update simply returns None and the app runs normally.
        self._update_info = None
        self._update_prompted = False
        threading.Thread(target=self._bg_update_check, daemon=True).start()

    def _bg_update_check(self):
        try:
            self._update_info = updater_mod.check_for_update(CURRENT_VERSION)
        except Exception:
            self._update_info = None

    def _maybe_prompt_update(self):
        if self._update_prompted or not self._update_info:
            return
        self._update_prompted = True
        latest, url, notes = self._update_info
        msg = f"A new version of Weighing Scale is available: v{latest}.\nYou are on v{CURRENT_VERSION}."
        if notes:
            msg += f"\n\nWhat's new:\n{notes}"
        msg += "\n\nUpdate now? Your database and Excel files are NOT touched by updates."
        if messagebox.askyesno("Update available", msg):
            try:
                updater_mod.apply_update(url)
            except SystemExit:
                raise
            except Exception as e:
                messagebox.showerror("Update failed", f"Could not install the update:\n{e}\n\nYour current version keeps working. Try again later.")
                return
            messagebox.showinfo("Updated", "Update installed. Please restart the app to run the new version.")
            self.on_close()

    # ---------- clock / refresh ----------
    def tick(self):
        now = datetime.now()
        self.clock_lbl.config(text=f"{now.strftime('%d-%m-%Y')}   {fmt_time()}")
        try:
            self._maybe_prompt_update()
        except Exception:
            pass
        self.after(1000, self.tick)

    def refresh_all(self):
        self.refresh_dashboard()
        self.refresh_daily()
        self.refresh_reports()
        self.refresh_salesperson()
        self.refresh_settings_lists()
        self.refresh_backup_list()
        pend = pending_dates(DB.base_dir)
        self.pending_lbl.config(text=f"⚠ Excel pending for {len(pend)} day(s) — file was open. See Backup tab to retry." if pend else "")

    def after_save(self, d):
        status = sync_excel(DB, d)
        if status == "queued":
            messagebox.showwarning("Excel queued",
                "Saved to the database safely, but today's Excel file is open/locked.\n"
                "Nothing is lost — the Excel update is queued and will retry automatically.\n"
                "Close the Excel file, then press 'Retry Pending Excel' on the Backup tab.")
        self.refresh_all()

    def on_close(self):
        try:
            if DB.get_setting("auto_backup", "1") == "1":
                DB.backup()
            # retry any pending Excel before exit
            retry_pending(DB)
        except Exception:
            pass
        DB.close()
        self.destroy()

    # ---------- Dashboard ----------
    def build_dashboard(self):
        tab = ttk.Frame(self.nb)
        self.nb.add(tab, text="  Dashboard  ")
        cards = tk.Frame(tab, bg="#F7F3E8")
        cards.pack(fill="x", padx=10, pady=10)
        self.card_labels = {}
        for title, key in [("Today's Boxes", "boxes"), ("Total Opening Weight", "opening"),
                           ("Total Sold Weight", "sold"), ("Total Remaining Weight", "remaining")]:
            f = tk.Frame(cards, bg="white", relief="groove", bd=1)
            f.pack(side="left", fill="x", expand=True, padx=5)
            tk.Label(f, text=title, font=("Segoe UI", 9), bg="white", fg="#666666").pack(pady=(8, 0))
            lbl = tk.Label(f, text="—", font=("Segoe UI", 18, "bold"), bg="white", fg="#333333")
            lbl.pack(pady=(0, 8))
            self.card_labels[key] = lbl

        # Box Out entry
        entry = tk.LabelFrame(tab, text="  BOX OUT — Take a box out of stock  ", font=("Segoe UI", 11, "bold"), bg="white", fg="#7A5C00")
        entry.pack(fill="x", padx=10, pady=5)
        tk.Label(entry, text="Box Category:", bg="white").grid(row=0, column=0, padx=8, pady=10, sticky="e")
        self.cat_var = tk.StringVar()
        self.cat_combo = ttk.Combobox(entry, textvariable=self.cat_var, width=24, state="readonly")
        self.cat_combo.grid(row=0, column=1, padx=5, pady=10)
        tk.Label(entry, text="Salesperson:", bg="white").grid(row=0, column=2, padx=8, pady=10, sticky="e")
        self.sp_var = tk.StringVar()
        self.sp_combo = ttk.Combobox(entry, textvariable=self.sp_var, width=24, state="readonly")
        self.sp_combo.grid(row=0, column=3, padx=5, pady=10)
        tk.Label(entry, text="Opening Weight (g):", bg="white").grid(row=0, column=4, padx=8, pady=10, sticky="e")
        self.open_var = tk.StringVar()
        tk.Entry(entry, textvariable=self.open_var, width=14, font=("Segoe UI", 12, "bold")).grid(row=0, column=5, padx=5, pady=10)
        ttk.Button(entry, text="💾  SAVE BOX OUT", style="Gold.TButton", command=self.save_box_out).grid(row=0, column=6, padx=12, pady=10)
        tk.Label(entry, text="Date & time are taken automatically from this computer. Box ID is generated automatically (BOX-YYYYMMDD-001 …).",
                 bg="white", fg="#888888", font=("Segoe UI", 9)).grid(row=1, column=0, columnspan=7, padx=8, pady=(0, 8), sticky="w")

        # Active boxes
        tk.Label(tab, text="Active Boxes — today", font=("Segoe UI", 12, "bold"), bg="#F7F3E8").pack(anchor="w", padx=12, pady=(8, 2))
        cols = ("S.No.", "Box ID", "Category", "Salesperson", "Opening", "Sold", "Remaining", "Status", "Time")
        self.active_tree = ttk.Treeview(tab, columns=cols, show="headings", height=14)
        for c, w in zip(cols, [6, 18, 16, 16, 12, 12, 12, 10, 18]):
            self.active_tree.heading(c, text=c)
            self.active_tree.column(c, width=w, anchor="center")
        self.active_tree.pack(fill="both", expand=True, padx=10, pady=5)
        btns = tk.Frame(tab, bg="#F7F3E8")
        btns.pack(fill="x", padx=10, pady=5)
        for text, fn in [("➕ Add Sale", self.act_sale), ("📦 Add Stock", self.act_stock),
                         ("↩ Return Box", self.act_return), ("📜 View History", self.act_history)]:
            ttk.Button(btns, text=text, command=fn).pack(side="left", padx=5)

    def refresh_dashboard(self):
        t = DB.daily_totals(today_str())
        self.card_labels["boxes"].config(text=str(t["boxes"]))
        self.card_labels["opening"].config(text=f"{t['opening']:.2f} g")
        self.card_labels["sold"].config(text=f"{t['sold']:.2f} g")
        self.card_labels["remaining"].config(text=f"{t['remaining']:.2f} g")
        self.showroom_lbl.config(text=DB.get_setting("showroom_name", "RAMANAND JEWELLERS"))
        self.cat_combo["values"] = [c["name"] for c in DB.categories(active_only=True)]
        self.sp_combo["values"] = [s["name"] for s in DB.salespersons(active_only=True)]
        for row in self.active_tree.get_children():
            self.active_tree.delete(row)
        for i, b in enumerate(DB.active_boxes(today_str()), 1):
            self.active_tree.insert("", "end", values=(i, b["box_id"], b["category"], b["salesperson"],
                f"{b['opening_weight']:.2f}", f"{b['sold']:.2f}", f"{b['expected_remaining']:.2f}",
                b["status"], fmt_time(b["created_at"])))

    def _selected_box(self):
        sel = self.active_tree.selection()
        if not sel:
            messagebox.showwarning("Select a box", "Please select an active box from the table first.")
            return None
        return self.active_tree.item(sel[0])["values"][1]

    def save_box_out(self):
        try:
            if not self.cat_var.get():
                raise ValidationError("Please select a Box Category (add one in Settings if the list is empty).")
            if not self.sp_var.get():
                raise ValidationError("Please select a Salesperson (add one in Settings if the list is empty).")
            box_id = DB.create_box(self.cat_var.get(), self.sp_var.get(), self.open_var.get())
        except (ValidationError, Exception) as e:
            messagebox.showerror("Cannot save", str(e)); return
        self.open_var.set("")
        messagebox.showinfo("Box Out saved", f"Box {box_id} is now active.\nOpening weight saved and today's Excel file updated.")
        self.after_save(today_str())

    def _weight_dialog(self, title, prompt, default_remarks=""):
        win = tk.Toplevel(self); win.title(title); win.geometry("380x240"); win.grab_set()
        tk.Label(win, text=prompt, font=("Segoe UI", 11, "bold")).pack(pady=10)
        wv = tk.StringVar(); tk.Entry(win, textvariable=wv, font=("Segoe UI", 13, "bold"), width=16).pack(pady=5)
        tk.Label(win, text="Remarks / explanation:").pack(pady=(8, 0))
        rv = tk.StringVar(value=default_remarks); tk.Entry(win, textvariable=rv, width=44).pack(pady=5)
        result = {}
        def ok():
            result["weight"] = wv.get(); result["remarks"] = rv.get(); win.destroy()
        ttk.Button(win, text="Save", style="Gold.TButton", command=ok).pack(pady=12)
        win.wait_window()
        return result

    def _sale_dialog(self, code, remaining):
        """Sale entry: sold weight + Mode of Transaction (dropdown) + Amount (Rs) + Bill No.
        Amount and Bill No are typed by the user; they may be left blank and
        filled in later from the bill, but Mode defaults to CASH (as on the
        old manual sheet) so a fast sale still needs only the weight."""
        win = tk.Toplevel(self); win.title("Add Sale"); win.geometry("420x380"); win.grab_set()
        tk.Label(win, text=f"{code} — Remaining: {remaining:.2f} g", font=("Segoe UI", 11, "bold")).pack(pady=10)
        tk.Label(win, text="Sold weight (g):").pack(anchor="w", padx=20)
        wv = tk.StringVar(); tk.Entry(win, textvariable=wv, font=("Segoe UI", 13, "bold"), width=20).pack(padx=20, pady=3, anchor="w")
        tk.Label(win, text="Mode of Transaction:").pack(anchor="w", padx=20, pady=(8, 0))
        mv = tk.StringVar(value="CASH")
        ttk.Combobox(win, textvariable=mv, values=PAYMENT_MODES, width=22, state="readonly").pack(padx=20, pady=3, anchor="w")
        tk.Label(win, text="Amount (Rs):").pack(anchor="w", padx=20, pady=(8, 0))
        av = tk.StringVar(); tk.Entry(win, textvariable=av, font=("Segoe UI", 12), width=20).pack(padx=20, pady=3, anchor="w")
        tk.Label(win, text="Bill No. (BN):").pack(anchor="w", padx=20, pady=(8, 0))
        bv = tk.StringVar(); tk.Entry(win, textvariable=bv, width=20).pack(padx=20, pady=3, anchor="w")
        tk.Label(win, text="Remarks:").pack(anchor="w", padx=20, pady=(8, 0))
        rv = tk.StringVar(); tk.Entry(win, textvariable=rv, width=44).pack(padx=20, pady=3, anchor="w")
        result = {}
        def ok():
            result.update(weight=wv.get(), remarks=rv.get(), payment_mode=mv.get(),
                          amount=av.get(), bill_no=bv.get())
            win.destroy()
        ttk.Button(win, text="Save Sale", style="Gold.TButton", command=ok).pack(pady=14)
        win.wait_window()
        return result

    def act_sale(self):
        code = self._selected_box()
        if not code: return
        s = DB.box_summary(code)
        d = self._sale_dialog(code, s['remaining'])
        if not d.get("weight"): return
        try:
            DB.add_sale(code, d["weight"], d["remarks"], payment_mode=d["payment_mode"],
                        amount=d["amount"], bill_no=d["bill_no"])
        except OverWeightError as e:
            if messagebox.askyesno("Overweight — override?",
                    f"Sold weight {e.requested:.2f} g exceeds remaining {e.remaining:.2f} g.\n"
                    "This will make the remaining weight negative.\n\nDo you want to override with a reason?"):
                reason = d["remarks"] or "Override confirmed by user"
                try:
                    DB.add_sale(code, d["weight"], d["remarks"], override=True, override_reason=reason,
                                payment_mode=d["payment_mode"], amount=d["amount"], bill_no=d["bill_no"])
                except Exception as ex:
                    messagebox.showerror("Cannot save", str(ex)); return
            else:
                return
        except Exception as e:
            messagebox.showerror("Cannot save", str(e)); return
        messagebox.showinfo("Sale saved", f"Sale saved for {code}.\nNew remaining: {DB.box_summary(code)['remaining']:.2f} g")
        self.after_save(today_str())

    def act_stock(self):
        code = self._selected_box()
        if not code: return
        d = self._weight_dialog("Add Stock", f"{code}\nEnter additional stock added (g):")
        if not d.get("weight"): return
        try:
            DB.add_stock(code, d["weight"], d["remarks"])
        except Exception as e:
            messagebox.showerror("Cannot save", str(e)); return
        messagebox.showinfo("Stock added", f"New remaining: {DB.box_summary(code)['remaining']:.2f} g")
        self.after_save(today_str())

    def act_return(self):
        code = self._selected_box()
        if not code: return
        s = DB.box_summary(code)
        d = self._weight_dialog("Return Box", f"{code}\nExpected remaining: {s['expected_remaining']:.2f} g\nEnter actual returned weight (g):")
        if not d.get("weight"): return
        try:
            res = DB.return_box(code, d["weight"], d["remarks"])
        except Exception as e:
            messagebox.showerror("Cannot return", str(e)); return
        msg = (f"Box {code} returned.\nOpening: {s['opening_weight']:.2f} g  •  Sold: {s['sold']:.2f} g\n"
               f"Expected: {res['expected']:.2f} g  •  Actual: {res['actual']:.2f} g  •  Difference: {res['difference']:+.2f} g")
        if abs(res["difference"]) >= 0.01:
            messagebox.showwarning("Weight difference", msg + "\n\nDifference noted in the report.")
        else:
            messagebox.showinfo("Box returned", msg)
        self.after_save(today_str())

    def act_history(self):
        code = self._selected_box()
        if not code: return
        s = DB.box_summary(code)
        win = tk.Toplevel(self); win.title(f"History — {code}"); win.geometry("720x420")
        info = (f"{code}  •  {s['category']}  •  {s['salesperson']}  •  Opening {s['opening_weight']:.2f} g  •  "
                f"Sold {s['sold']:.2f} g  •  Added {s['added']:.2f} g  •  Expected {s['expected_remaining']:.2f} g  •  {s['status']}")
        tk.Label(win, text=info, font=("Segoe UI", 10, "bold"), wraplength=700).pack(pady=8)
        cols = ("Txn ID", "Type", "Weight", "Mode", "Amount (Rs)", "Bill No.", "Time", "Remarks")
        tree = ttk.Treeview(win, columns=cols, show="headings")
        for c in cols:
            tree.heading(c, text=c); tree.column(c, width=110, anchor="center")
        tree.pack(fill="both", expand=True, padx=10, pady=5)
        for t in DB.box_history(code):
            mark = " (VOIDED)" if t["voided"] else ""
            tree.insert("", "end", values=(t["txn_id"], t["type"] + mark, f"{t['weight']:.2f}", t.get("payment_mode") or "",
                (f"{t['amount']:.2f}" if t.get("amount") is not None else ""), t.get("bill_no") or "", t["created_at"], t["remarks"] or ""))
        tk.Label(win, text="Audit trail (corrections / voids):", font=("Segoe UI", 10, "bold")).pack(anchor="w", padx=10)
        audit = tk.Text(win, height=6); audit.pack(fill="x", padx=10, pady=5)
        for a in DB.audit_for_box(code):
            audit.insert("end", f"{a['created_at']}  {a['action']}  {a['old_value']} → {a['new_value']}  {a['reason']}\n")
        audit.config(state="disabled")

    # ---------- Daily Entries ----------
    def build_daily(self):
        tab = ttk.Frame(self.nb); self.nb.add(tab, text="  Daily Entries  ")
        top = tk.Frame(tab); top.pack(fill="x", padx=10, pady=8)
        tk.Label(top, text="Date (DD-MM-YYYY):").pack(side="left")
        self.daily_date = tk.StringVar(value=datetime.now().strftime("%d-%m-%Y"))
        tk.Entry(top, textvariable=self.daily_date, width=12).pack(side="left", padx=5)
        tk.Label(top, text="Search Box ID:").pack(side="left", padx=(10, 0))
        self.daily_search = tk.StringVar(); tk.Entry(top, textvariable=self.daily_search, width=18).pack(side="left", padx=5)
        ttk.Button(top, text="Load", command=self.refresh_daily).pack(side="left", padx=8)
        cols = ("Txn ID", "Box ID", "Category", "Salesperson", "Type", "Weight", "Mode", "Amount (Rs)", "Bill No.", "Time", "Remarks")
        self.daily_tree = ttk.Treeview(tab, columns=cols, show="headings", height=22)
        for c, w in zip(cols, [20, 18, 16, 16, 12, 12, 14, 13, 12, 18, 26]):
            self.daily_tree.heading(c, text=c); self.daily_tree.column(c, width=w, anchor="center")
        self.daily_tree.pack(fill="both", expand=True, padx=10, pady=5)
        btns = tk.Frame(tab); btns.pack(fill="x", padx=10, pady=5)
        ttk.Button(btns, text="✏️ Correct Entry (with reason)", command=self.correct_entry).pack(side="left", padx=5)
        ttk.Button(btns, text="🚫 Void Entry (with reason)", command=self.void_entry).pack(side="left", padx=5)
        ttk.Button(btns, text="📊 Export This Date to Excel", command=self.export_daily).pack(side="left", padx=5)

    def refresh_daily(self):
        try:
            d = parse_ddmmyyyy(self.daily_date.get())
        except Exception as e:
            messagebox.showerror("Date", str(e)); return
        for row in self.daily_tree.get_children():
            self.daily_tree.delete(row)
        for t in DB.daily_transactions(d, box_search=self.daily_search.get().strip() or None):
            self.daily_tree.insert("", "end", values=(t["txn_id"], t["box_code"], t["category"], t["salesperson"],
                t["type"], f"{t['weight']:.2f}", t.get("payment_mode") or "",
                (f"{t['amount']:.2f}" if t.get("amount") is not None else ""), t.get("bill_no") or "",
                t["created_at"], t["remarks"] or ""))

    def _selected_txn(self):
        sel = self.daily_tree.selection()
        if not sel:
            messagebox.showwarning("Select entry", "Please select an entry from the table first."); return None
        return self.daily_tree.item(sel[0])["values"][0]

    def correct_entry(self):
        txn = self._selected_txn()
        if not txn: return
        win = tk.Toplevel(self); win.title("Correct Entry"); win.geometry("380x220"); win.grab_set()
        tk.Label(win, text=f"Correct {txn}", font=("Segoe UI", 11, "bold")).pack(pady=8)
        tk.Label(win, text="New weight (g):").pack(); wv = tk.StringVar(); tk.Entry(win, textvariable=wv, font=("Segoe UI", 12, "bold")).pack()
        tk.Label(win, text="Reason (required — saved in audit trail):").pack(pady=(8, 0)); rv = tk.StringVar(); tk.Entry(win, textvariable=rv, width=44).pack()
        def ok():
            try:
                DB.correct_transaction(txn, wv.get(), rv.get())
            except Exception as e:
                messagebox.showerror("Cannot correct", str(e)); return
            win.destroy(); messagebox.showinfo("Corrected", "Entry corrected. Old value is kept in the audit trail.")
            self.after_save(parse_ddmmyyyy(self.daily_date.get()))
        ttk.Button(win, text="Save Correction", style="Gold.TButton", command=ok).pack(pady=12)

    def void_entry(self):
        txn = self._selected_txn()
        if not txn: return
        win = tk.Toplevel(self); win.title("Void Entry"); win.geometry("380x180"); win.grab_set()
        tk.Label(win, text=f"Void {txn}?", font=("Segoe UI", 11, "bold")).pack(pady=8)
        tk.Label(win, text="Reason (required):").pack(); rv = tk.StringVar(); tk.Entry(win, textvariable=rv, width=44).pack()
        def ok():
            try:
                DB.void_transaction(txn, rv.get())
            except Exception as e:
                messagebox.showerror("Cannot void", str(e)); return
            win.destroy(); messagebox.showinfo("Voided", "Entry voided. It no longer counts in totals, but stays in the audit trail.")
            self.after_save(parse_ddmmyyyy(self.daily_date.get()))
        ttk.Button(win, text="Void Entry", style="Gold.TButton", command=ok).pack(pady=12)

    def export_daily(self):
        try:
            d = parse_ddmmyyyy(self.daily_date.get())
        except Exception as e:
            messagebox.showerror("Date", str(e)); return
        status = sync_excel(DB, d)
        path = excel_path_for(DB.base_dir, d)
        if status == "queued":
            messagebox.showwarning("Queued", "Excel file is open/locked. Update queued — close Excel and retry from the Backup tab.")
        else:
            messagebox.showinfo("Excel exported", f"Saved:\n{path}")
            if messagebox.askyesno("Open Excel?", "Open the Excel file now?"):
                open_file(path)

    # ---------- Reports & History ----------
    def build_reports(self):
        tab = ttk.Frame(self.nb); self.nb.add(tab, text="  Reports & History  ")
        top = tk.Frame(tab); top.pack(fill="x", padx=10, pady=8)
        tk.Label(top, text="Date:").pack(side="left")
        self.rep_date = tk.StringVar(value=datetime.now().strftime("%d-%m-%Y"))
        tk.Entry(top, textvariable=self.rep_date, width=12).pack(side="left", padx=5)
        tk.Label(top, text="Category:").pack(side="left", padx=(10, 0))
        self.rep_cat = tk.StringVar(); self.rep_cat_combo = ttk.Combobox(top, textvariable=self.rep_cat, width=16, state="readonly"); self.rep_cat_combo.pack(side="left", padx=5)
        tk.Label(top, text="Salesperson:").pack(side="left", padx=(10, 0))
        self.rep_sp = tk.StringVar(); self.rep_sp_combo = ttk.Combobox(top, textvariable=self.rep_sp, width=16, state="readonly"); self.rep_sp_combo.pack(side="left", padx=5)
        tk.Label(top, text="Type:").pack(side="left", padx=(10, 0))
        self.rep_type = tk.StringVar(); ttk.Combobox(top, textvariable=self.rep_type, values=["", "BOX_OUT", "SALE", "ADD_STOCK", "RETURN"], width=12, state="readonly").pack(side="left", padx=5)
        ttk.Button(top, text="Load", command=self.refresh_reports).pack(side="left", padx=8)
        self.rep_summary = tk.Label(tab, font=("Segoe UI", 10, "bold"), fg="#7A5C00")
        self.rep_summary.pack(anchor="w", padx=12)
        cols = ("Txn ID", "Box ID", "Category", "Salesperson", "Type", "Weight", "Mode", "Amount (Rs)", "Bill No.", "Time", "Remarks")
        self.rep_tree = ttk.Treeview(tab, columns=cols, show="headings", height=20)
        for c, w in zip(cols, [20, 18, 16, 16, 12, 12, 14, 13, 12, 18, 26]):
            self.rep_tree.heading(c, text=c); self.rep_tree.column(c, width=w, anchor="center")
        self.rep_tree.pack(fill="both", expand=True, padx=10, pady=5)
        btns = tk.Frame(tab); btns.pack(fill="x", padx=10, pady=5)
        ttk.Button(btns, text="📊 Re-export This Date to Excel", command=self.export_reports_date).pack(side="left", padx=5)
        ttk.Button(btns, text="📂 Open Excel File", command=self.open_reports_excel).pack(side="left", padx=5)
        ttk.Button(btns, text="🖨️ Print (opens Excel for printing)", command=self.open_reports_excel).pack(side="left", padx=5)

    def refresh_reports(self):
        try:
            d = parse_ddmmyyyy(self.rep_date.get())
        except Exception as e:
            messagebox.showerror("Date", str(e)); return
        self.rep_cat_combo["values"] = [""] + [c["name"] for c in DB.categories()]
        self.rep_sp_combo["values"] = [""] + [s["name"] for s in DB.salespersons()]
        t = DB.daily_totals(d)
        self.rep_summary.config(text=f"{fmt_date(d)}  •  Boxes: {t['boxes']}  •  Active: {t['active']}  •  Returned: {t['returned_count']}  •  "
            f"Opening: {t['opening']:.2f} g  •  Sold: {t['sold']:.2f} g  •  Added: {t['added']:.2f} g  •  Remaining (active): {t['remaining']:.2f} g")
        for row in self.rep_tree.get_children():
            self.rep_tree.delete(row)
        for txn in DB.daily_transactions(d, category=self.rep_cat.get() or None, salesperson=self.rep_sp.get() or None, txn_type=self.rep_type.get() or None):
            self.rep_tree.insert("", "end", values=(txn["txn_id"], txn["box_code"], txn["category"], txn["salesperson"],
                txn["type"], f"{txn['weight']:.2f}", txn.get("payment_mode") or "",
                (f"{txn['amount']:.2f}" if txn.get("amount") is not None else ""), txn.get("bill_no") or "",
                txn["created_at"], txn["remarks"] or ""))

    def export_reports_date(self):
        try:
            d = parse_ddmmyyyy(self.rep_date.get())
        except Exception as e:
            messagebox.showerror("Date", str(e)); return
        status = sync_excel(DB, d)
        messagebox.showinfo("Excel", "Excel re-exported." if status == "ok" else "Excel queued — file is open/locked.")

    def open_reports_excel(self):
        try:
            d = parse_ddmmyyyy(self.rep_date.get())
        except Exception as e:
            messagebox.showerror("Date", str(e)); return
        path = excel_path_for(DB.base_dir, d)
        if not os.path.exists(path):
            sync_excel(DB, d)
        if os.path.exists(path):
            open_file(path)
        else:
            messagebox.showwarning("Not found", "Excel file could not be created. It may be open/locked.")

    # ---------- Salesperson Reports ----------
    def build_salesperson(self):
        tab = ttk.Frame(self.nb); self.nb.add(tab, text="  Salesperson Reports  ")
        top = tk.Frame(tab); top.pack(fill="x", padx=10, pady=8)
        tk.Label(top, text="Date:").pack(side="left")
        self.sp_date = tk.StringVar(value=datetime.now().strftime("%d-%m-%Y"))
        tk.Entry(top, textvariable=self.sp_date, width=12).pack(side="left", padx=5)
        ttk.Button(top, text="Load", command=self.refresh_salesperson).pack(side="left", padx=8)
        cols = ("Salesperson", "Boxes", "Categories", "Opening", "Sold", "Added", "Returned", "Returned Count", "Active", "Remaining")
        self.sp_tree = ttk.Treeview(tab, columns=cols, show="headings", height=20)
        for c, w in zip(cols, [16, 8, 26, 12, 12, 12, 12, 13, 8, 12]):
            self.sp_tree.heading(c, text=c); self.sp_tree.column(c, width=w, anchor="center")
        self.sp_tree.pack(fill="both", expand=True, padx=10, pady=5)

    def refresh_salesperson(self):
        try:
            d = parse_ddmmyyyy(self.sp_date.get())
        except Exception as e:
            messagebox.showerror("Date", str(e)); return
        for row in self.sp_tree.get_children():
            self.sp_tree.delete(row)
        for sp in DB.salesperson_report(d):
            self.sp_tree.insert("", "end", values=(sp["salesperson"], sp["boxes"], sp["categories"], f"{sp['opening']:.2f}",
                f"{sp['sold']:.2f}", f"{sp['added']:.2f}", f"{sp['returned']:.2f}", sp["returned_count"], sp["active"], f"{sp['remaining']:.2f}"))

    # ---------- Settings ----------
    def build_settings(self):
        tab = ttk.Frame(self.nb); self.nb.add(tab, text="  Settings  ")
        gen = tk.LabelFrame(tab, text="  General Settings  ", font=("Segoe UI", 11, "bold"), bg="white", fg="#7A5C00")
        gen.pack(fill="x", padx=10, pady=8)
        tk.Label(gen, text="Showroom Name:", bg="white").grid(row=0, column=0, padx=8, pady=6, sticky="e")
        self.showroom_var = tk.StringVar(value=DB.get_setting("showroom_name", "RAMANAND JEWELLERS"))
        tk.Entry(gen, textvariable=self.showroom_var, width=36).grid(row=0, column=1, padx=5, pady=6)
        tk.Label(gen, text="Time Format:", bg="white").grid(row=0, column=2, padx=8, pady=6, sticky="e")
        self.timefmt_var = tk.StringVar(value=DB.get_setting("time_format", "12-hour"))
        ttk.Combobox(gen, textvariable=self.timefmt_var, values=["12-hour", "24-hour"], width=12, state="readonly").grid(row=0, column=3, padx=5, pady=6)
        tk.Label(gen, text="Weight Unit: Grams (fixed)  •  Date Format: DD-MM-YYYY (fixed)", bg="white", fg="#888888").grid(row=1, column=0, columnspan=4, padx=8, pady=2, sticky="w")
        tk.Label(gen, text="Data Folder:", bg="white").grid(row=2, column=0, padx=8, pady=6, sticky="e")
        tk.Label(gen, text=DB.base_dir, bg="white", fg="#333333", wraplength=500).grid(row=2, column=1, columnspan=2, padx=5, pady=6, sticky="w")
        ttk.Button(gen, text="Change Folder…", command=self.change_folder).grid(row=2, column=3, padx=5, pady=6)
        ttk.Button(gen, text="💾 Save General Settings", style="Gold.TButton", command=self.save_general).grid(row=3, column=0, columnspan=4, pady=8)

        mid = tk.Frame(tab); mid.pack(fill="both", expand=True, padx=10, pady=5)
        # Categories
        cf = tk.LabelFrame(mid, text="  Box Categories  ", font=("Segoe UI", 11, "bold"))
        cf.pack(side="left", fill="both", expand=True, padx=5)
        self.cat_list = tk.Listbox(cf, height=14); self.cat_list.pack(fill="both", expand=True, padx=8, pady=5)
        row = tk.Frame(cf); row.pack(fill="x", padx=8, pady=5)
        self.new_cat = tk.StringVar(); tk.Entry(row, textvariable=self.new_cat, width=22).pack(side="left")
        ttk.Button(row, text="Add", command=self.add_cat).pack(side="left", padx=4)
        row2 = tk.Frame(cf); row2.pack(fill="x", padx=8, pady=5)
        ttk.Button(row2, text="Rename", command=lambda: self.rename_list("cat")).pack(side="left", padx=2)
        ttk.Button(row2, text="Deactivate", command=lambda: self.toggle_list("cat", False)).pack(side="left", padx=2)
        ttk.Button(row2, text="Activate", command=lambda: self.toggle_list("cat", True)).pack(side="left", padx=2)
        ttk.Button(row2, text="Delete", command=lambda: self.delete_list("cat")).pack(side="left", padx=2)
        # Salespersons
        sf = tk.LabelFrame(mid, text="  Salespersons  ", font=("Segoe UI", 11, "bold"))
        sf.pack(side="left", fill="both", expand=True, padx=5)
        self.sp_list = tk.Listbox(sf, height=14); self.sp_list.pack(fill="both", expand=True, padx=8, pady=5)
        row = tk.Frame(sf); row.pack(fill="x", padx=8, pady=5)
        self.new_sp = tk.StringVar(); tk.Entry(row, textvariable=self.new_sp, width=22).pack(side="left")
        ttk.Button(row, text="Add", command=self.add_sp).pack(side="left", padx=4)
        row2 = tk.Frame(sf); row2.pack(fill="x", padx=8, pady=5)
        ttk.Button(row2, text="Rename", command=lambda: self.rename_list("sp")).pack(side="left", padx=2)
        ttk.Button(row2, text="Deactivate", command=lambda: self.toggle_list("sp", False)).pack(side="left", padx=2)
        ttk.Button(row2, text="Activate", command=lambda: self.toggle_list("sp", True)).pack(side="left", padx=2)
        ttk.Button(row2, text="Delete", command=lambda: self.delete_list("sp")).pack(side="left", padx=2)
        tk.Label(tab, text="Delete works only for categories / salespersons never used in a box. Used ones can be deactivated instead — their old records stay intact.",
                 fg="#888888", wraplength=1000).pack(padx=10, pady=5)

    def refresh_settings_lists(self):
        self.cat_list.delete(0, "end")
        for c in DB.categories():
            self.cat_list.insert("end", f"{c['name']}  {'(inactive)' if not c['is_active'] else ''}  [id {c['id']}]")
        self.sp_list.delete(0, "end")
        for s in DB.salespersons():
            self.sp_list.insert("end", f"{s['name']}  {'(inactive)' if not s['is_active'] else ''}  [id {s['id']}]")

    def _list_id(self, lst):
        sel = lst.curselection()
        if not sel:
            messagebox.showwarning("Select", "Please select an item from the list first."); return None
        text = lst.get(sel[0])
        try:
            return int(text.rsplit("[id ", 1)[1].rstrip("]"))
        except Exception:
            return None

    def add_cat(self):
        try:
            DB.add_category(self.new_cat.get())
        except Exception as e:
            messagebox.showerror("Cannot add", str(e)); return
        self.new_cat.set(""); self.refresh_all()

    def add_sp(self):
        try:
            DB.add_salesperson(self.new_sp.get())
        except Exception as e:
            messagebox.showerror("Cannot add", str(e)); return
        self.new_sp.set(""); self.refresh_all()

    def rename_list(self, kind):
        lst = self.cat_list if kind == "cat" else self.sp_list
        rid = self._list_id(lst)
        if rid is None: return
        win = tk.Toplevel(self); win.title("Rename"); win.geometry("320x140"); win.grab_set()
        tk.Label(win, text="New name:").pack(pady=8); v = tk.StringVar(); tk.Entry(win, textvariable=v, width=32).pack()
        def ok():
            try:
                if kind == "cat": DB.rename_category(rid, v.get())
                else: DB.rename_salesperson(rid, v.get())
            except Exception as e:
                messagebox.showerror("Cannot rename", str(e)); return
            win.destroy(); self.refresh_all()
        ttk.Button(win, text="Save", style="Gold.TButton", command=ok).pack(pady=10)

    def toggle_list(self, kind, active):
        lst = self.cat_list if kind == "cat" else self.sp_list
        rid = self._list_id(lst)
        if rid is None: return
        if kind == "cat": DB.set_category_active(rid, active)
        else: DB.set_salesperson_active(rid, active)
        self.refresh_all()

    def delete_list(self, kind):
        lst = self.cat_list if kind == "cat" else self.sp_list
        rid = self._list_id(lst)
        if rid is None: return
        if not messagebox.askyesno("Confirm delete", "Delete this item? This cannot be undone."):
            return
        try:
            if kind == "cat": DB.delete_category(rid)
            else: DB.delete_salesperson(rid)
        except Exception as e:
            messagebox.showerror("Cannot delete", str(e)); return
        self.refresh_all()

    def save_general(self):
        DB.set_setting("showroom_name", self.showroom_var.get().strip() or "RAMANAND JEWELLERS")
        DB.set_setting("time_format", self.timefmt_var.get())
        messagebox.showinfo("Saved", "General settings saved.")
        self.refresh_all()

    def change_folder(self):
        folder = filedialog.askdirectory(title="Choose a new Weighing Scale data folder")
        if not folder: return
        new_base = os.path.join(folder, "Weighing Scale") if os.path.basename(folder) != "Weighing Scale" else folder
        try:
            os.makedirs(os.path.join(new_base, "Database"), exist_ok=True)
            import shutil
            if DB.db_path != os.path.join(new_base, "Database", "weighing_scale.db"):
                DB.conn.commit()
                shutil.copy2(DB.db_path, os.path.join(new_base, "Database", "weighing_scale.db"))
            with open(SIDECAR, "w") as f:
                f.write(new_base)
        except Exception as e:
            messagebox.showerror("Cannot change folder", str(e)); return
        messagebox.showinfo("Folder changed", f"Data folder set to:\n{new_base}\n\nPlease restart the app to use the new folder. Your current database was copied there.")

    # ---------- Backup & Restore ----------
    def build_backup(self):
        tab = ttk.Frame(self.nb); self.nb.add(tab, text="  Backup & Restore  ")
        tk.Label(tab, text="Automatic backup runs every time the app closes. The database is the source of truth — Excel is regenerated from it.",
                 wraplength=1000, fg="#666666").pack(padx=12, pady=10, anchor="w")
        btns = tk.Frame(tab); btns.pack(fill="x", padx=10, pady=5)
        ttk.Button(btns, text="💾 Backup Database Now", style="Gold.TButton", command=self.do_backup).pack(side="left", padx=5)
        ttk.Button(btns, text="↩ Restore from Backup…", command=self.do_restore).pack(side="left", padx=5)
        ttk.Button(btns, text="🔄 Retry Pending Excel", command=self.do_retry).pack(side="left", padx=5)
        ttk.Button(btns, text="📂 Open Data Folder", command=lambda: open_file(DB.base_dir)).pack(side="left", padx=5)
        ttk.Button(btns, text="⬆ Check for Updates", command=self.do_manual_update_check).pack(side="left", padx=5)
        tk.Label(tab, text="Database backups:", font=("Segoe UI", 11, "bold")).pack(anchor="w", padx=12, pady=(12, 2))
        self.backup_list = tk.Listbox(tab, height=18); self.backup_list.pack(fill="both", expand=True, padx=10, pady=5)
        tk.Label(tab, text="Restore replaces the current database with the backup file. A safety copy of the current database is made first.",
                 fg="#B00000", wraplength=1000).pack(padx=12, pady=5, anchor="w")

    def refresh_backup_list(self):
        self.backup_list.delete(0, "end")
        try:
            files = sorted(os.listdir(DB.paths["backups"]), reverse=True)
        except Exception:
            files = []
        for f in files:
            self.backup_list.insert("end", f)

    def do_backup(self):
        try:
            dest = DB.backup()
        except Exception as e:
            messagebox.showerror("Backup failed", str(e)); return
        messagebox.showinfo("Backup done", f"Saved:\n{dest}")
        self.refresh_backup_list()

    def do_restore(self):
        path = filedialog.askopenfilename(title="Choose a database backup", filetypes=[("SQLite database", "*.db"), ("All files", "*.*")])
        if not path: return
        if not messagebox.askyesno("Confirm restore", "Restore will replace the current database.\nA safety backup of the current database will be made first.\n\nContinue?"):
            return
        try:
            safety = DB.backup()
            DB.close()
            import shutil
            shutil.copy2(path, DB.db_path)
            # remove WAL so the restored DB opens clean
            for suffix in ("-wal", "-shm"):
                try: os.remove(DB.db_path + suffix)
                except Exception: pass
        except Exception as e:
            messagebox.showerror("Restore failed", str(e)); return
        messagebox.showinfo("Restored", f"Database restored from:\n{path}\n\nSafety backup: {safety}\n\nPlease restart the app.")
        self.destroy()

    def do_manual_update_check(self):
        info = updater_mod.check_for_update(CURRENT_VERSION)
        if not info:
            messagebox.showinfo("Up to date", f"You are on the latest version (v{CURRENT_VERSION}).\n\nIf the update channel has not been set up yet, this check simply finds nothing — the app keeps working normally.")
            return
        self._update_info = info
        self._update_prompted = False
        self._maybe_prompt_update()

    def do_retry(self):
        results = retry_pending(DB)
        if not results:
            messagebox.showinfo("Nothing pending", "No Excel updates are pending.")
        else:
            messagebox.showinfo("Retry result", "\n".join(f"{d}: {s}" for d, s in results.items()))
        self.refresh_all()

if __name__ == "__main__":
    # Startup: sync today's Excel (queued safely if locked), never erase history
    try:
        sync_excel(DB, today_str())
    except Exception:
        pass
    App().mainloop()
