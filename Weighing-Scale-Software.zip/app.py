"""Weighing Scale - Jewellery Box Management & Daily Weighing Software.
Offline Windows desktop app: tkinter + SQLite + openpyxl.
Run:  python app.py        (after Setup.bat on Windows)
Data lives in Documents\\Weighing Scale\\  (Database / Daily Reports / Backups).
"""
import os, sys, json, queue, subprocess, threading, time, tkinter as tk
from tkinter import ttk, messagebox, filedialog
from datetime import datetime, date
import db as dbmod
from db import Database, ValidationError, OverWeightError, today_str, fmt_date
from excel_export import sync_excel, retry_pending, pending_dates, excel_path_for, _read_pending, _write_pending
import updater as updater_mod
from updater import CURRENT_VERSION
try:
    from live_rates import fetch_mcx_rates, banner_text as _rates_banner_text
except Exception:
    fetch_mcx_rates = None
    _rates_banner_text = None

# --- data location: sidecar file next to app.py, else Documents\Weighing Scale ---
APP_DIR = os.path.dirname(os.path.abspath(__file__))
SIDECAR = os.path.join(APP_DIR, "data_location.txt")

def resolve_base_dir():
    if os.path.exists(SIDECAR):
        try:
            p = open(SIDECAR).read().strip()
            if p:
                return p
        except Exception:
            pass
    return dbmod.default_base_dir()

DB = Database(resolve_base_dir())
# Rename migration: v1.0 shipped with AURUM DIAMONDS as the default showroom.
# Any existing install still on that old default follows the rename to Ramanand.
try:
    if DB.get_setting("showroom_name", "") == "AURUM DIAMONDS":
        DB.set_setting("showroom_name", "RAMANAND JEWELLERS")
except Exception:
    pass
GOLD = "#C9A227"
SAFE_MODE = "--safe" in sys.argv

def write_crash_log(exc_text):
    """Write the startup crash to a file the user can send us, even when
    pythonw hides the console. Returns the log path."""
    import traceback
    path = os.path.join(APP_DIR, "crash_log.txt")
    try:
        with open(path, "w", encoding="utf-8") as f:
            f.write(f"Weighing Scale v{CURRENT_VERSION} crash\n")
            f.write(f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write(f"Safe mode: {SAFE_MODE}\n")
            f.write(f"Database: {DB.db_path}\n\n")
            f.write(exc_text)
        return path
    except Exception:
        return path
# CURRENT_VERSION lives in updater.py (single source of truth for the update channel)
PAYMENT_MODES = ["CASH", "UPI", "CARD", "BANK TRANSFER", "CREDIT / UDHAAR", "CHEQUE", "OTHER"]

def open_file(path):
    try:
        if sys.platform.startswith("win"):
            os.startfile(path)  # noqa
        elif sys.platform == "darwin":
            subprocess.Popen(["open", path])
        else:
            subprocess.Popen(["xdg-open", path])
    except Exception as e:
        messagebox.showerror("Cannot open", str(e))

def parse_ddmmyyyy(s):
    s = (s or "").strip()
    try:
        return datetime.strptime(s, "%d-%m-%Y").strftime("%Y-%m-%d")
    except Exception:
        raise ValidationError("Date must be DD-MM-YYYY, e.g. 31-10-2026.")

def fmt_time(dt_str=None):
    fmt = DB.get_setting("time_format", "12-hour")
    now = datetime.now()
    if dt_str:
        try:
            now = datetime.strptime(dt_str, "%Y-%m-%d %H:%M:%S")
        except Exception:
            pass
    return now.strftime("%I:%M:%S %p" if fmt == "12-hour" else "%H:%M:%S")

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f"Weighing Scale v{CURRENT_VERSION} — Ramanand Jewellers")
        self.geometry("1180x720")
        try:
            _icon = os.path.join(APP_DIR, "icon.ico")
            if os.path.exists(_icon):
                self.iconbitmap(_icon)
        except Exception:
            pass
        self.configure(bg="#F7F3E8")
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except Exception:
            pass
        style.configure("Gold.TButton", background=GOLD, foreground="white", font=("Segoe UI", 11, "bold"), padding=8)
        # "Where am I" colour: the selected row in any table is gold, not
        # the plain system selection colour, so it stands out at a glance.
        style.map("Treeview", background=[("selected", "#FFD966")], foreground=[("selected", "black")])
        style.configure("TNotebook.Tab", font=("Segoe UI", 10, "bold"), padding=(10, 6))

        # Header
        head = tk.Frame(self, bg="white")
        head.pack(fill="x", padx=10, pady=10)
        self.showroom_lbl = tk.Label(head, text=DB.get_setting("showroom_name", "RAMANAND JEWELLERS"),
                                     font=("Segoe UI", 18, "bold"), bg="white", fg="#333333")
        self.showroom_lbl.pack(side="left", padx=10)
        tk.Label(head, text="Jewellery Box Management  •  Daily Weighing", font=("Segoe UI", 10),
                 bg="white", fg="#7A5C00").pack(side="left", padx=6)
        # Always-visible version, so "which version am I on?" never needs
        # a Backup-tab check to answer. (refresh_all only touches
        # pending_lbl, never this label, so it cannot be cleared away.)
        self.version_lbl = tk.Label(head, text=f"Version v{CURRENT_VERSION}", font=("Segoe UI", 11, "bold"),
                                    bg="white", fg="#7A5C00")
        self.version_lbl.pack(side="left", padx=12)
        self.clock_lbl = tk.Label(head, font=("Segoe UI", 11, "bold"), bg="white", fg="#333333")
        self.clock_lbl.pack(side="right", padx=10)
        self.pending_lbl = tk.Label(head, font=("Segoe UI", 9, "bold"), bg="white", fg="#B00000")
        self.pending_lbl.pack(side="right", padx=6)

        self.nb = ttk.Notebook(self)
        self.nb.pack(fill="both", expand=True, padx=10, pady=(0, 10))
        self.build_dashboard()
        self.build_daily()
        self.build_reports()
        self.build_salesperson()
        self.build_settings()
        self.build_backup()
        self.build_attendance()
        self.refresh_all()
        self.tick()
        self.protocol("WM_DELETE_WINDOW", self.on_close)
        # Auto-update check: background thread, never blocks the UI.
        # If the GitHub channel is not live yet (or there is no internet),
        # check_for_update simply returns None and the app runs normally.
        self._update_info = None
        self._update_prompted = False
        if not SAFE_MODE:
            threading.Thread(target=self._bg_update_check, daemon=True).start()
        # Alt+1..Alt+7 switch tabs without the mouse (notebook order).
        for _i in range(min(8, len(self.nb.tabs()))):
            self.bind(f"<Alt-Key-{_i + 1}>", lambda e, _i=_i: self.nb.select(_i))
        try:
            self.after(100, lambda: self.cat_combo.focus_set())
        except Exception:
            pass

    def _bg_update_check(self):
        try:
            self._update_info = updater_mod.check_for_update(CURRENT_VERSION)
        except Exception:
            self._update_info = None

    def _maybe_prompt_update(self):
        if self._update_prompted or not self._update_info:
            return
        self._update_prompted = True
        latest, url, notes = self._update_info
        msg = f"A new version of Weighing Scale is available: v{latest}.\nYou are on v{CURRENT_VERSION}."
        if notes:
            msg += f"\n\nWhat's new:\n{notes}"
        msg += "\n\nUpdate now? Your database and Excel files are NOT touched by updates."
        if messagebox.askyesno("Update available", msg):
            try:
                updater_mod.apply_update(url)
            except SystemExit:
                raise
            except Exception as e:
                messagebox.showerror("Update failed", f"Could not install the update:\n{e}\n\nYour current version keeps working. Try again later.")
                return
            messagebox.showinfo("Updated", "Update installed. Please restart the app to run the new version.")
            self.on_close()

    # ---------- clock / refresh ----------
    def tick(self):
        now = datetime.now()
        self.clock_lbl.config(text=f"{now.strftime('%d-%m-%Y')}   {fmt_time()}")
        # No auto update prompt here (v1.8): see _maybe_prompt_update note.
        # If an update is available, show it quietly in the header instead.
        try:
            if self._update_info and not self._update_prompted:
                latest = self._update_info[0]
                self.pending_lbl.config(text=f"⬆ Update v{latest} available — open Backup tab → Check for Updates")
        except Exception:
            pass
        self.after(1000, self.tick)

    def refresh_all(self):
        # Guarded: a failure in one tab (bad row, locked file, whatever)
        # must not close the app. It is logged and the other tabs still load.
        for _fn in (self.refresh_dashboard, self.refresh_daily, self.refresh_reports,
                    self.refresh_salesperson, self.refresh_settings_lists, self.refresh_backup_list, self.refresh_attendance):
            try:
                _fn()
            except Exception as e:
                try:
                    write_crash_log(f"refresh failed in {_fn.__name__}: {e}\n")
                except Exception:
                    pass
        try:
            pend = pending_dates(DB.base_dir)
            self.pending_lbl.config(text=f"⚠ Excel pending for {len(pend)} day(s) — file was open. See Backup tab to retry." if pend else "")
        except Exception:
            pass

    def after_save(self, d):
        status = sync_excel(DB, d)
        if status == "queued":
            messagebox.showwarning("Excel queued",
                "Saved to the database safely, but today's Excel file is open/locked.\n"
                "Nothing is lost — the Excel update is queued and will retry automatically.\n"
                "Close the Excel file, then press 'Retry Pending Excel' on the Backup tab.")
        self.refresh_all()

    def on_close(self):
        self._rates_stop = True
        try:
            if DB.get_setting("auto_backup", "1") == "1":
                DB.backup()
            # retry any pending Excel before exit
            retry_pending(DB)
        except Exception:
            pass
        DB.close()
        self.destroy()

    # ---------- Dashboard ----------
    def build_dashboard(self):
        tab = ttk.Frame(self.nb)
        self.nb.add(tab, text="  Dashboard  ")
        # Scrollable Dashboard (v1.25): the whole Dashboard page
        # (banner, cards, Box Out, table, buttons, shortcuts help)
        # used to be packed straight into the tab, so when its total
        # height exceeded the window the bottom widgets — including
        # the keyboard-shortcuts help — were squeezed to 1 px and
        # could not be scrolled to read. Now the page lives in a
        # Canvas with a vertical scrollbar: scroll (mouse wheel
        # anywhere on the page, or drag the scrollbar) to read the
        # bottom. Wheel over the table scrolls the table itself,
        # wheel over the shortcuts box scrolls that box — the page
        # only scrolls for wheel events elsewhere.
        _dash_outer = tab
        self._dash_canvas = tk.Canvas(_dash_outer, bg="#F7F3E8", highlightthickness=0)
        self._dash_scroll = tk.Scrollbar(_dash_outer, orient="vertical", command=self._dash_canvas.yview)
        self._dash_canvas.configure(yscrollcommand=self._dash_scroll.set)
        self._dash_scroll.pack(side="right", fill="y")
        self._dash_canvas.pack(side="left", fill="both", expand=True)
        tab = tk.Frame(self._dash_canvas, bg="#F7F3E8")
        self._dash_canvas.create_window((0, 0), window=tab, anchor="nw", tags="dash_inner")
        tab.bind("<Configure>", lambda e: self._dash_canvas.configure(scrollregion=self._dash_canvas.bbox("all")))
        self._dash_canvas.bind("<Configure>", lambda e: self._dash_canvas.itemconfig("dash_inner", width=e.width))
        def _dash_wheel_all(event):
            try:
                if self.nb.index("current") != 0:
                    return None
                if event.widget.winfo_toplevel() is not self:
                    return None
                if event.widget in (getattr(self, "active_tree", None), getattr(self, "help_text", None)):
                    return None
                if getattr(event, "delta", 0):
                    self._dash_canvas.yview_scroll(-1 if event.delta > 0 else 1, "units")
                elif getattr(event, "num", 0) == 4:
                    self._dash_canvas.yview_scroll(-1, "units")
                elif getattr(event, "num", 0) == 5:
                    self._dash_canvas.yview_scroll(1, "units")
                else:
                    return None
            except Exception:
                return None
            return "break"
        self._dash_wheel_all = _dash_wheel_all
        self.bind_all("<MouseWheel>", _dash_wheel_all, add="+")
        self.bind_all("<Button-4>", _dash_wheel_all, add="+")
        self.bind_all("<Button-5>", _dash_wheel_all, add="+")
        # Live MCX banner (v1.20, simplified v1.21): gold + silver
        # from mcxlive.org, auto-scrolling across the top of the
        # Dashboard, refreshed every 60 seconds in a background
        # thread (never blocks the UI). No buttons on the banner
        # (v1.21: Refresh and Pause removed) — the small LIVE /
        # OFFLINE label at the right edge is the only extra word.
        # If the site or the internet is down, the last good rate
        # stays up, marked OFFLINE — never a crash, never a blank.
        self._rates_stop = False
        self._rates_data = None
        self._rates_queue = queue.Queue()
        banner = tk.Frame(tab, bg="#1A1A1A")
        banner.pack(fill="x", padx=10, pady=(8, 0))
        self._rates_canvas = tk.Canvas(banner, bg="#1A1A1A", highlightthickness=0, height=28)
        self._rates_canvas.pack(side="left", fill="x", expand=True)
        self._rates_text_id = self._rates_canvas.create_text(
            0, 14, text="  Fetching live MCX rates from mcxlive.org…  ",
            fill="#FFD966", font=("Segoe UI", 11, "bold"), anchor="w")
        self._rates_status_lbl = tk.Label(banner, text="FETCHING", bg="#1A1A1A", fg="#FFD966",
                                          font=("Segoe UI", 9, "bold"))
        self._rates_status_lbl.pack(side="right", padx=6)
        threading.Thread(target=self._rates_fetch_loop, daemon=True).start()
        self.after(100, self._rates_scroll)
        cards = tk.Frame(tab, bg="#F7F3E8")
        cards.pack(fill="x", padx=10, pady=10)
        self.card_labels = {}
        for title, key in [("Today's Boxes", "boxes"), ("Total Opening Weight", "opening"),
                           ("Total Sold Weight", "sold"), ("Total Remaining Weight", "remaining")]:
            f = tk.Frame(cards, bg="white", relief="groove", bd=1)
            f.pack(side="left", fill="x", expand=True, padx=5)
            tk.Label(f, text=title, font=("Segoe UI", 9), bg="white", fg="#666666").pack(pady=(8, 0))
            lbl = tk.Label(f, text="—", font=("Segoe UI", 18, "bold"), bg="white", fg="#333333")
            lbl.pack(pady=(0, 8))
            self.card_labels[key] = lbl

        # Box Out entry — horizontally scrollable (v1.18): the row
        # (Category + Salesperson + Metal + Opening + Save) is wider
        # than the 1180 px window, so the Save button used to fall off
        # the right edge with no way to reach it. Now the row sits in
        # a Canvas with a horizontal scrollbar underneath it, and
        # focusing any field (Tab, or clicking it) scrolls that field
        # into view automatically.
        entry = tk.LabelFrame(tab, text="  BOX OUT — Take a box out of stock  ", font=("Segoe UI", 11, "bold"), bg="white", fg="#7A5C00")
        entry.pack(fill="x", padx=10, pady=5)
        self._boxout_canvas = tk.Canvas(entry, bg="white", highlightthickness=0, height=62)
        self._boxout_canvas.pack(fill="x", padx=2, pady=2)
        _boxout_hbar = ttk.Scrollbar(entry, orient="horizontal", command=self._boxout_canvas.xview)
        _boxout_hbar.pack(fill="x", padx=2, pady=(0, 2))
        self._boxout_canvas.configure(xscrollcommand=_boxout_hbar.set)
        entry = tk.Frame(self._boxout_canvas, bg="white")
        self._boxout_canvas.create_window((0, 0), window=entry, anchor="nw")
        def _boxout_scrollregion(event=None):
            self._boxout_canvas.configure(scrollregion=self._boxout_canvas.bbox("all"))
        entry.bind("<Configure>", _boxout_scrollregion)
        def _boxout_ensure_visible(widget):
            # Scroll the canvas just enough that the focused field (or
            # the Save button) is fully visible.
            try:
                self._boxout_canvas.update_idletasks()
                total = self._boxout_canvas.bbox("all")[2]
                visible = self._boxout_canvas.winfo_width()
                if total <= visible:
                    return
                left_px = self._boxout_canvas.xview()[0] * total
                wx, ww = widget.winfo_x(), widget.winfo_width()
                if wx < left_px:
                    self._boxout_canvas.xview_moveto(max(0.0, wx / total))
                elif wx + ww > left_px + visible:
                    self._boxout_canvas.xview_moveto(min(1.0, (wx + ww - visible) / total))
            except Exception:
                pass
        self._boxout_ensure_visible = _boxout_ensure_visible
        tk.Label(entry, text="Box Category:", bg="white").grid(row=0, column=0, padx=8, pady=10, sticky="e")
        self.cat_var = tk.StringVar()
        self.cat_combo = ttk.Combobox(entry, textvariable=self.cat_var, width=24)
        self._autocomplete(self.cat_combo, self.cat_var, lambda: [c["name"] for c in DB.categories(active_only=True)])
        self.cat_combo.grid(row=0, column=1, padx=5, pady=10)
        tk.Label(entry, text="Salesperson:", bg="white").grid(row=0, column=2, padx=8, pady=10, sticky="e")
        self.sp_var = tk.StringVar()
        self.sp_combo = ttk.Combobox(entry, textvariable=self.sp_var, width=24)
        self._autocomplete(self.sp_combo, self.sp_var, lambda: [s["name"] for s in DB.salespersons(active_only=True)])
        self.sp_combo.grid(row=0, column=3, padx=5, pady=10)
        tk.Label(entry, text="Metal:", bg="white").grid(row=0, column=4, padx=8, pady=10, sticky="e")
        self.metal_var = tk.StringVar(value="GOLD")
        self.metal_combo = ttk.Combobox(entry, textvariable=self.metal_var, values=["GOLD", "SILVER"], width=10, state="readonly")
        self.metal_combo.grid(row=0, column=5, padx=5, pady=10)
        tk.Label(entry, text="Opening Weight (g):", bg="white").grid(row=0, column=6, padx=8, pady=10, sticky="e")
        self.open_var = tk.StringVar()
        self.open_entry = tk.Entry(entry, textvariable=self.open_var, width=14, font=("Segoe UI", 12, "bold"))
        self._numeric_entry(self.open_entry)
        self._glow(self.open_entry)
        self.open_entry.grid(row=0, column=7, padx=5, pady=10)
        # Keyboard-first Box Out: Tab moves Category -> Salesperson -> Metal ->
        # Opening Weight -> Save; Enter in any of these fields saves the box.
        for _w in (self.cat_combo, self.sp_combo, self.metal_combo, self.open_entry):
            _w.bind("<Return>", lambda e: self.save_box_out())
        self.boxout_save_btn = ttk.Button(entry, text="💾  SAVE BOX OUT", style="Gold.TButton", command=self.save_box_out)
        self.boxout_save_btn.grid(row=0, column=8, padx=12, pady=10)
        for _w in (self.cat_combo, self.sp_combo, self.metal_combo, self.open_entry, self.boxout_save_btn):
            _w.bind("<FocusIn>", lambda e, _w=_w: self._boxout_ensure_visible(_w))
        # Box Out -> table by Space (v1.19 conditional, v1.24
        # UNCONDITIONAL at the user's request): Space in a Box Out
        # field ALWAYS jumps straight to the table (last box
        # selected) — not Enter (Enter saves the box). Whenever he
        # wants the table, Space gets him there, no matter what is
        # in the field. Shift+Space still types a real space, for
        # the rare case a name itself needs one (picking from the
        # dropdown is the normal way to get "LADIES RING" etc.).
        for _w in (self.cat_combo, self.sp_combo, self.metal_combo, self.open_entry):
            _w.bind("<space>", self._boxout_space_jump)
            _w.bind("<Shift-space>", self._boxout_space_insert)

        # Active boxes
        tk.Label(tab, text="Today's Boxes — active and returned", font=("Segoe UI", 12, "bold"), bg="#F7F3E8").pack(anchor="w", padx=12, pady=(8, 2))
        # Customer preference (v1.6, like their manual sheet): NO Box ID column
        # (the box id is the tree item id, still used internally), NO Remaining
        # column — in its place is Return (actual returned weight, blank while
        # the box is still out), then Sell Amount and Bill No.
        cols = ("S.No.", "Category", "Metal", "Salesperson", "Opening", "Sold", "Added", "Return", "Sell Amount", "Bill No.", "Status", "Time")
        self.active_cols = cols
        self.active_cell_col = 0  # cell cursor column index (Left/Right move this)
        self.active_tree = ttk.Treeview(tab, columns=cols, show="headings", height=14)
        for c, w in zip(cols, [6, 16, 10, 16, 12, 12, 12, 12, 13, 20, 10, 18]):
            self.active_tree.heading(c, text=("Bill No./Rokar/Book" if c == "Bill No." else c))
            self.active_tree.column(c, width=w, anchor="center")
        self.active_tree.pack(fill="both", expand=True, padx=10, pady=5)
        btns = tk.Frame(tab, bg="#F7F3E8")
        btns.pack(fill="x", padx=10, pady=5)
        for text, fn in [("➕ Add Sale", self.act_sale), ("📦 Add Stock", self.act_stock),
                         ("↩ Return Box", self.act_return), ("📜 View History", self.act_history),
                         ("🔄 Reset Today", lambda: self.do_reset_day(today_str()))]:
            ttk.Button(btns, text=text, command=fn).pack(side="left", padx=5)
        # Keyboard shortcuts help (v1.25, scrollable): the old three
        # long one-line Labels ran off the right edge of the window
        # and could not be scrolled to read. Now every shortcut is
        # one line in a small Text box with its own vertical
        # scrollbar — scroll inside the box (mouse wheel works) to
        # read them all. Text wraps at the box width, so no line is
        # ever cut off at the edge.
        tk.Label(tab, text="⌨  KEYBOARD SHORTCUTS — scroll inside the box below to read them all:",
                 bg="#F7F3E8", fg="#7A5C00", font=("Segoe UI", 9, "bold")).pack(anchor="w", padx=12, pady=(2, 0))
        _help_frame = tk.Frame(tab, bg="#F7F3E8")
        _help_frame.pack(fill="x", padx=12, pady=(0, 2))
        _help_scroll = tk.Scrollbar(_help_frame, orient="vertical")
        _help_scroll.pack(side="right", fill="y")
        self.help_text = tk.Text(_help_frame, height=4, wrap="word", bg="white", fg="#333333",
                                 font=("Segoe UI", 9), yscrollcommand=_help_scroll.set)
        self.help_text.pack(side="left", fill="x", expand=True)
        _help_scroll.config(command=self.help_text.yview)
        for _line in (
            "Tab = move to next field  •  ↑ ↓ = move row  •  ← → = move COLUMN  •  Home / End = first / last column",
            "MANUAL ENTRY: arrow to Sold / Added / Return / Sell Amount / Bill No./Rokar/Book, press Enter or F2 (or just type a number) to type directly in that cell, Enter saves, Esc cancels",
            "S = Sale  •  A = Stock  •  R = Return  •  H = History  •  Esc = close a window  •  Alt+1…7 = switch tabs",
            "Returned boxes stay on today's list; S / A / R work only on ACTIVE boxes",
            "B (in table) = Box Category",
            "Space (in Box Out) = jump to table, every time (NOT Enter — Enter saves)",
            "Shift+Space (in Box Out) = type a space",
            "Sale panel: Enter goes Sold → Amount (Mode stays CASH unless you Tab to it)",
            "Alt+7 = Attendance",
            "SOLD COLOUR: the Sold column entry turns GREEN only when that box has actually sold weight — if Opening weight = Returned weight, it is NOT highlighted green (it stays the normal gold selection)",
            "WEIGHT: weight fields take numbers only (digits and one decimal point); letters are blocked as you type",
        ):
            self.help_text.insert("end", _line + "\n")
        self.help_text.config(state="disabled")
        # Mouse wheel over the help box scrolls the help box itself.
        self.help_text.bind("<MouseWheel>", lambda e: (self.help_text.yview_scroll(-1 if e.delta > 0 else 1, "units"), "break")[1])
        self.help_text.bind("<Button-4>", lambda e: (self.help_text.yview_scroll(-1, "units"), "break")[1])
        self.help_text.bind("<Button-5>", lambda e: (self.help_text.yview_scroll(1, "units"), "break")[1])
        # Cell navigation (v1.10): the table has a CELL cursor, not just a
        # row cursor. Up/Down move the row, Left/Right move the COLUMN,
        # Home/End jump to first/last column. The current cell is shown
        # in the label under the table (tkinter cannot colour one cell
        # of a row, so the label is the cell indicator). Enter acts on
        # the column you are on: Return column -> Return Box, Sold /
        # Sell Amount / Bill No. -> Add Sale, anything else -> History.
        # S / A / R / H still work on the selected row from any column.
        self.cell_lbl = tk.Label(tab, text="Selected cell: —", bg="#F7F3E8", fg="#7A5C00",
                                 font=("Segoe UI", 10, "bold"))
        self.cell_lbl.pack(anchor="w", padx=12, pady=(0, 2))
        def _tree_key(event):
            # Typing a number on an editable column starts editing that cell
            # directly (like Excel) — no dialog, no mouse.
            col = self.active_cols[self.active_cell_col]
            if col in ("Return", "Sold", "Added", "Sell Amount", "Bill No.") and getattr(event, "char", "") and (event.char.isdigit() or event.char == "."):
                self._start_cell_edit(first_char=event.char)
                return "break"
            key = (event.keysym or "").lower()
            if key == "s":
                self.act_sale()
            elif key == "a":
                self.act_stock()
            elif key == "r":
                self.act_return()
            elif key == "h":
                self.act_history()
            elif key == "b":
                # B = Box Category: jump from the table to the Box Out
                # panel and open the Category list (Down also opens it).
                self.cat_combo.focus_set()
                try:
                    self.cat_combo.event_generate("<Alt-Down>")
                except Exception:
                    pass
        self.active_tree.bind("<Key>", _tree_key)
        self.active_tree.bind("<Up>", lambda e: self._cell_move_row(-1))
        self.active_tree.bind("<Down>", lambda e: self._cell_move_row(1))
        self.active_tree.bind("<Left>", lambda e: self._cell_move_col(-1))
        self.active_tree.bind("<Right>", lambda e: self._cell_move_col(1))
        self.active_tree.bind("<Home>", lambda e: self._cell_move_col(-999))
        self.active_tree.bind("<End>", lambda e: self._cell_move_col(999))
        self.active_tree.bind("<Return>", lambda e: self._cell_enter())
        self.active_tree.bind("<F2>", lambda e: self._cell_enter())
        self.active_tree.bind("<<TreeviewSelect>>", lambda e: self._update_cell_label())
        # Gold cell overlay: a label placed over the current cell, so the
        # exact column you are on is coloured, not just the row.
        self._cell_highlight = tk.Label(self.active_tree, bg="#FFD966", fg="black",
                                        font=("Segoe UI", 10, "bold"), anchor="center")
        # Reposition after a mouse-wheel scroll moves the rows under it.
        for _ev in ("<MouseWheel>", "<Button-4>", "<Button-5>"):
            self.active_tree.bind(_ev, lambda e: self.after(50, self._after_tree_scroll))
        # Window resize moves the columns, so the green Sold labels
        # must be repositioned too (debounced, so a drag does not
        # rebuild them on every pixel).
        self.active_tree.bind("<Configure>", lambda e: self._schedule_sold_refresh())

    # ---------- Live MCX rates banner (v1.20) ----------
    def _rates_set_text(self, text, status):
        try:
            if not self.winfo_exists():
                return
            self._rates_canvas.itemconfig(self._rates_text_id, text=text)
            try:
                self._rates_canvas.coords(self._rates_text_id, self._rates_canvas.winfo_width(), 14)
            except Exception:
                pass
            self._rates_status_lbl.config(text=status,
                fg="#7ED957" if status == "LIVE" else ("#FF6B6B" if status == "OFFLINE" else "#FFD966"))
        except Exception:
            pass

    def _rates_do_fetch(self):
        """One fetch (worker thread only). Tk widgets are NEVER touched
        from this thread — the result is put on a queue, and the
        main-thread scroll loop (via after) applies it. Calling Tk
        methods from a worker thread silently deadlocks under Xvfb
        and is unsafe on Windows too, so the queue is the whole
        contract between the fetch thread and the UI."""
        if fetch_mcx_rates is None:
            self._rates_queue.put(("OFFLINE",
                "  Live MCX rates unavailable in this build.  "))
            return
        data = fetch_mcx_rates()
        if data:
            self._rates_data = data
            self._rates_queue.put(("LIVE", _rates_banner_text(data, status="LIVE")))
        elif self._rates_data is not None:
            self._rates_queue.put(("OFFLINE",
                _rates_banner_text(self._rates_data, status="OFFLINE — last rate")))
        else:
            self._rates_queue.put(("OFFLINE",
                "  Live MCX rates unavailable — check internet, will retry in 1 minute.  "))

    def _rates_fetch_loop(self):
        # Every 60 seconds, in 1-second slices so stopping is prompt.
        while not self._rates_stop:
            self._rates_do_fetch()
            for _ in range(60):
                if self._rates_stop:
                    break
                time.sleep(1)

    def _rates_scroll(self):
        if self._rates_stop:
            return
        # Drain any fetched rates first — this runs on the main
        # thread, so it is the only place that touches the banner.
        try:
            while True:
                _status, _txt = self._rates_queue.get_nowait()
                self._rates_set_text(_txt, _status)
        except queue.Empty:
            pass
        except Exception:
            pass
        try:
            if self.winfo_exists():
                c = self._rates_canvas
                c.move(self._rates_text_id, -2, 0)
                bbox = c.bbox(self._rates_text_id)
                if bbox and bbox[2] < 0:
                    c.coords(self._rates_text_id, c.winfo_width(), 14)
        except Exception:
            pass
        try:
            self.after(30, self._rates_scroll)
        except Exception:
            pass

    def refresh_dashboard(self):
        t = DB.daily_totals(today_str())
        self.card_labels["boxes"].config(text=str(t["boxes"]))
        self.card_labels["opening"].config(text=f"{t['opening']:.4f} g")
        self.card_labels["sold"].config(text=f"{t['sold']:.4f} g")
        self.card_labels["remaining"].config(text=f"{t['remaining']:.4f} g")
        self.showroom_lbl.config(text=DB.get_setting("showroom_name", "RAMANAND JEWELLERS"))
        self.cat_combo["values"] = [c["name"] for c in DB.categories(active_only=True)]
        self.sp_combo["values"] = [s["name"] for s in DB.salespersons(active_only=True)]
        if getattr(self, "_cell_highlight", None):
            self._cell_highlight.place_forget()
        for row in self.active_tree.get_children():
            self.active_tree.delete(row)
        for i, b in enumerate(DB.boxes_for_date(today_str()), 1):
            # NOTE: Treeview.insert(parent, index, iid=...) — index must be
            # the 2nd positional argument. v1.6 wrongly passed end="end" as
            # a keyword, which threw TypeError, emptied this table, and
            # (before v1.8's guard) closed the app on startup.
            self.active_tree.insert("", "end", iid=b["box_id"], values=(i, b["category"], b.get("metal") or "", b["salesperson"],
                f"{b['opening_weight']:.4f}", f"{b['sold']:.4f}", f"{b.get('added', 0):.4f}",
                (f"{b['return_weight']:.4f}" if b.get("return_weight") is not None else ""),
                (f"{b.get('sale_amount', 0):.2f}" if b.get("sale_amount") else ""),
                b.get("bill_nos") or "",
                ("RETURNED" if b["status"] == "CLOSED" else b["status"]), fmt_time(b["created_at"])))
        # Sold-green labels need real bboxes, so place them after the
        # tree has laid out (next idle cycle).
        try:
            self.after_idle(self._refresh_sold_highlights)
        except Exception:
            pass

    def _sold_is_green(self, vals):
        """Sold-green rule (v1.22): Sold > 0, AND NOT (Returned weight
        is set and equals Opening weight). vals are the Dashboard row
        values: Opening at index 4, Sold at 5, Return at 7."""
        try:
            if len(vals) <= 7:
                return False
            sold = float(str(vals[5]).replace(",", ""))
            if sold <= 0:
                return False
            opening = float(str(vals[4]).replace(",", ""))
            ret_raw = vals[7]
            if ret_raw not in ("", None):
                ret = float(str(ret_raw).replace(",", ""))
                if abs(ret - opening) < 0.00005:
                    return False
            return True
        except Exception:
            return False

    def _sold_label_click(self, row):
        """Clicking a green Sold label selects that row and moves the
        cell cursor onto Sold (labels swallow clicks, so the tree
        would not select the row on its own)."""
        try:
            self.active_tree.selection_set(row)
            self.active_tree.see(row)
            self.active_tree.focus(row)
            self.active_tree.focus_set()
            self.active_cell_col = self.active_cols.index("Sold")
            self._update_cell_label()
        except Exception:
            pass
        return "break"

    def _schedule_sold_refresh(self):
        if getattr(self, "_sold_refresh_pending", False):
            return
        self._sold_refresh_pending = True
        def _go():
            self._sold_refresh_pending = False
            self._refresh_sold_highlights()
        try:
            self.after(50, _go)
        except Exception:
            self._sold_refresh_pending = False

    def _after_tree_scroll(self):
        self._update_cell_label()
        self._refresh_sold_highlights()

    def _refresh_sold_highlights(self):
        """Persistent green labels over the Sold cell of every sold
        box in the Dashboard table (not just the selected one).
        Treeview cannot colour a single cell, so a label is placed
        over each qualifying Sold cell; clicking a label selects
        that row on Sold (see _sold_label_click). Labels are rebuilt
        on every refresh/scroll/resize, so they never go stale."""
        try:
            for lbl in getattr(self, "_sold_highlight_labels", []):
                try:
                    lbl.destroy()
                except Exception:
                    pass
            self._sold_highlight_labels = []
            tree = self.active_tree
            for row in tree.get_children():
                vals = tree.item(row)["values"]
                if not self._sold_is_green(vals):
                    continue
                bbox = tree.bbox(row, "Sold")
                if not bbox:
                    continue
                x, y, w, h = bbox
                lbl = tk.Label(tree, text=str(vals[5]), bg="#90EE90", fg="black",
                               font=("Segoe UI", 10, "bold"), anchor="center")
                lbl.place(x=x, y=y, width=w, height=h)
                lbl.bind("<Button-1>", lambda e, row=row: self._sold_label_click(row))
                self._sold_highlight_labels.append(lbl)
        except Exception:
            pass

    def _selected_box(self):
        sel = self.active_tree.selection()
        if not sel:
            messagebox.showwarning("Select a box", "Please select an active box from the table first.")
            return None
        return sel[0]  # tree item id IS the box id (Box ID column is hidden)

    def _update_cell_label(self):
        try:
            sel = self.active_tree.selection()
            hl = getattr(self, "_cell_highlight", None)
            if not sel:
                self.cell_lbl.config(text="Selected cell: —")
                if hl:
                    hl.place_forget()
                return
            vals = self.active_tree.item(sel[0])["values"]
            col = self.active_cols[self.active_cell_col]
            val = vals[self.active_cell_col] if self.active_cell_col < len(vals) else ""
            col_disp = "Bill No./Rokar/Book" if col == "Bill No." else col
            self.cell_lbl.config(text=f"Selected cell:  Row {sel[0]}  •  Column: {col_disp}  •  Value: {val}")
            # Cell overlay: gold for every column, EXCEPT the Sold
            # column, which is GREEN only when that box has actually
            # sold weight — and NOT green when Opening = Returned
            # (a box returned whole, even if stock was added and sold
            # in equal amounts, is not a sold box by that rule).
            # Treeview cannot colour one cell, so this overlay label
            # (plus the persistent green labels in
            # _refresh_sold_highlights) is how a single cell is coloured.
            if hl and not getattr(self, "_cell_edit_entry", None):
                bbox = self.active_tree.bbox(sel[0], col)
                if bbox:
                    x, y, w, h = bbox
                    if col == "Sold" and self._sold_is_green(vals):
                        hl.config(text=str(val), bg="#90EE90", fg="black")
                    else:
                        hl.config(text=str(val), bg="#FFD966", fg="black")
                    hl.place(x=x, y=y, width=w, height=h)
                else:
                    hl.place_forget()
        except Exception:
            pass

    def _cell_move_row(self, step):
        rows = self.active_tree.get_children()
        if not rows:
            return "break"
        sel = self.active_tree.selection()
        idx = rows.index(sel[0]) if sel and sel[0] in rows else (-1 if step > 0 else 0)
        nxt = max(0, min(len(rows) - 1, idx + step))
        self.active_tree.selection_set(rows[nxt])
        self.active_tree.see(rows[nxt])
        self.active_tree.focus(rows[nxt])
        self._update_cell_label()
        return "break"

    def _cell_move_col(self, step):
        n = len(self.active_cols)
        if step <= -999:
            self.active_cell_col = 0
        elif step >= 999:
            self.active_cell_col = n - 1
        else:
            self.active_cell_col = max(0, min(n - 1, self.active_cell_col + step))
        self._update_cell_label()
        return "break"

    def _cell_enter(self):
        col = self.active_cols[self.active_cell_col]
        if col in ("Return", "Sold", "Added", "Sell Amount", "Bill No."):
            self._start_cell_edit()
        else:
            self.act_history()
        return "break"

    def _start_cell_edit(self, first_char=""):
        # Inline cell editing, like the manual Excel sheet: an Entry is
        # placed over the selected cell, so the weight / amount / bill
        # number is typed IN the column, not in a separate window.
        if getattr(self, "_cell_edit_entry", None):
            return "break"
        sel = self.active_tree.selection()
        if not sel:
            return "break"
        iid = sel[0]
        col = self.active_cols[self.active_cell_col]
        try:
            box = DB.box_summary(iid)
        except Exception as e:
            messagebox.showerror("Cannot edit", str(e)); return "break"
        if col in ("Return", "Added") and box["status"] != "ACTIVE":
            messagebox.showwarning("Already returned", "This box is already returned — its Return / Added value cannot be changed here.")
            return "break"
        if col in ("Sell Amount", "Bill No.") and not DB.latest_sale(iid):
            messagebox.showwarning("No sale yet", "Enter a Sold weight for this box first, then its Amount / Bill No./Rokar/Book")
            return "break"
        # Prefill: Sell Amount / Bill No. show the latest sale's values so
        # they can be corrected; Sold / Added / Return start blank (a NEW entry).
        prefill = ""
        if col == "Sell Amount":
            sale = DB.latest_sale(iid)
            prefill = f"{sale['amount']:.2f}" if sale and sale.get("amount") is not None else ""
        elif col == "Bill No.":
            sale = DB.latest_sale(iid)
            prefill = sale.get("bill_no") or "" if sale else ""
        if first_char:
            prefill = first_char
        self.active_tree.see(iid)
        bbox = self.active_tree.bbox(iid, col)
        if not bbox:
            return "break"
        x, y, w, h = bbox
        entry = tk.Entry(self.active_tree, font=("Segoe UI", 11, "bold"), background="#FFF2CC")
        if col in ("Sold", "Added", "Return", "Sell Amount"):
            # Weight / amount columns take numbers only (v1.25);
            # Bill No./Rokar/Book is left alone on purpose — bill
            # numbers can contain letters, so it must stay free text.
            self._numeric_entry(entry)
        entry.place(x=x, y=y, width=w, height=h)
        entry.insert(0, prefill)
        if not first_char:
            entry.select_range(0, "end")
        entry.focus_set()
        self._cell_edit_entry = entry
        self._cell_edit_box = iid
        self._cell_edit_col = col
        entry.bind("<Return>", lambda e: self._commit_cell_edit())
        entry.bind("<Escape>", lambda e: self._cancel_cell_edit())
        entry.bind("<FocusOut>", lambda e: self._cancel_cell_edit())
        return "break"

    def _cancel_cell_edit(self):
        entry = getattr(self, "_cell_edit_entry", None)
        if entry:
            try:
                entry.destroy()
            except Exception:
                pass
        self._cell_edit_entry = None
        try:
            self.active_tree.focus_set()
        except Exception:
            pass
        self._update_cell_label()
        return "break"

    def _commit_cell_edit(self):
        entry = getattr(self, "_cell_edit_entry", None)
        if not entry:
            return "break"
        value = entry.get().strip()
        iid, col = self._cell_edit_box, self._cell_edit_col
        # Destroy first so a follow-up dialog (remarks) does not fight the entry.
        try:
            entry.destroy()
        except Exception:
            pass
        self._cell_edit_entry = None
        if not value:
            self.refresh_dashboard(); return "break"
        try:
            if col == "Sold":
                # A NEW sale of this weight (Mode CASH by default; Amount and
                # Bill No. are then typed in their own columns).
                DB.add_sale(iid, value, "Manual cell entry", payment_mode="CASH")
            elif col == "Added":
                # NEW stock added to the box — this is what was invisible
                # before: it now shows in the Added column on this table.
                DB.add_stock(iid, value, "Manual cell entry")
            elif col == "Sell Amount":
                DB.update_latest_sale(iid, amount=value)
            elif col == "Bill No.":
                DB.update_latest_sale(iid, bill_no=value)
            elif col == "Return":
                try:
                    DB.return_box(iid, value, "")
                except ValidationError as e:
                    if "difference" in str(e).lower():
                        remarks = self._remarks_dialog("Return weight differs", "Returned weight differs from expected.\nEnter a short reason (required):")
                        if remarks is None:
                            self.refresh_dashboard(); return "break"
                        DB.return_box(iid, value, remarks)
                    else:
                        raise
        except OverWeightError as e:
            messagebox.showerror("Overweight", f"Sold weight {e.requested:.4f} g exceeds remaining {e.remaining:.4f} g.\nUse Add Sale (S) with an override reason instead.")
        except Exception as e:
            messagebox.showerror("Cannot save", str(e))
        self.refresh_all()
        # Move to the next column, so Sold -> Added -> Return -> Sell Amount
        # -> Bill No. can be filled in one left-to-right pass.
        self._cell_move_col(1)
        try:
            self.active_tree.focus_set()
        except Exception:
            pass
        return "break"

    def _remarks_dialog(self, title, prompt):
        win = tk.Toplevel(self); win.title(title); win.geometry("380x150"); win.grab_set()
        tk.Label(win, text=prompt, font=("Segoe UI", 10)).pack(pady=10, padx=10)
        rv = tk.StringVar(); _e = tk.Entry(win, textvariable=rv, width=44); _e.pack(padx=10); _e.focus_set()
        result = {}
        def ok():
            result["v"] = rv.get().strip(); win.destroy()
        win.bind("<Return>", lambda e: ok()); win.bind("<Escape>", lambda e: win.destroy())
        ttk.Button(win, text="Save", style="Gold.TButton", command=ok).pack(pady=10)
        self.wait_window(win)
        return result.get("v") if result.get("v") else None

    def save_box_out(self):
        try:
            if not self.cat_var.get():
                raise ValidationError("Please select a Box Category (add one in Settings if the list is empty).")
            if not self.sp_var.get():
                raise ValidationError("Please select a Salesperson (add one in Settings if the list is empty).")
            if self.metal_var.get() not in ("GOLD", "SILVER"):
                raise ValidationError("Please select the box metal: GOLD or SILVER.")
            box_id = DB.create_box(self.cat_var.get(), self.sp_var.get(), self.open_var.get(), metal=self.metal_var.get())
        except (ValidationError, Exception) as e:
            messagebox.showerror("Cannot save", str(e)); return
        self.open_var.set("")
        messagebox.showinfo("Box Out saved", f"Box {box_id} is now active.\nOpening weight saved and today's Excel file updated.")
        try:
            self.cat_combo.focus_set()
        except Exception:
            pass
        self.after_save(today_str())

    def _weight_dialog(self, title, prompt, default_remarks=""):
        win = tk.Toplevel(self); win.title(title); win.geometry("380x260"); win.grab_set()
        tk.Label(win, text=prompt, font=("Segoe UI", 11, "bold")).pack(pady=10)
        wv = tk.StringVar(); _we = tk.Entry(win, textvariable=wv, font=("Segoe UI", 13, "bold"), width=16); self._numeric_entry(_we); _we.pack(pady=5); _we.focus_set()
        tk.Label(win, text="Remarks / explanation:").pack(pady=(8, 0))
        rv = tk.StringVar(value=default_remarks); _re = tk.Entry(win, textvariable=rv, width=44); _re.pack(pady=5)
        self._glow(_we); self._glow(_re)
        result = {}
        def ok():
            result["weight"] = wv.get(); result["remarks"] = rv.get(); win.destroy()
        # Keyboard flow: Enter moves Weight -> Remarks -> Save (it used to
        # save straight from Weight, before Remarks could be typed).
        _we.bind("<Return>", lambda e: _re.focus_set())
        _re.bind("<Return>", lambda e: ok())
        win.bind("<Control-Return>", lambda e: ok())
        win.bind("<Escape>", lambda e: win.destroy())
        tk.Label(win, text="Enter = next field  •  Ctrl+Enter = Save  •  Esc = Cancel",
                 font=("Segoe UI", 9), fg="#666666").pack(pady=(4, 0))
        ttk.Button(win, text="Save", style="Gold.TButton", command=ok).pack(pady=12)
        win.wait_window()
        return result

    def _sale_dialog(self, code, remaining, default_weight=""):
        """Sale entry, HORIZONTAL like an Excel row (v1.12): one row of
        columns — Sold (g) | Mode | Amount (Rs) | Bill No. | Remarks —
        with the column names as a header row on top, instead of the old
        vertical stack of label-over-field. Tab / Enter move left to
        right across the row, exactly like moving across Excel columns.
        Returns the same dict as before, so act_sale is unchanged.
        default_weight (v1.16): when the dialog is opened from Return
        because weight is missing, the Sold field is prefilled with the
        difference, so the user only fills Amount / Bill No. (v1.19:
        the panel opens on Amount, and Enter from Sold skips Mode)."""
        win = tk.Toplevel(self); win.title("Add Sale"); win.geometry("1020x215"); win.grab_set()
        tk.Label(win, text=f"{code} — Remaining: {remaining:.4f} g", font=("Segoe UI", 11, "bold")).pack(pady=(10, 6), anchor="w", padx=12)
        row = tk.Frame(win); row.pack(fill="x", padx=12)
        headers = ["Sold (g)", "Mode", "Amount (Rs)", "Bill No./Rokar/Book", "Remarks"]
        widths = [14, 20, 16, 20, 30]
        header_lbls = []
        for i, h in enumerate(headers):
            lbl = tk.Label(row, text=h, font=("Segoe UI", 10, "bold"), bg="#F7F3E8",
                           relief="solid", borderwidth=1, width=widths[i])
            lbl.grid(row=0, column=i, sticky="ew", padx=1, pady=1)
            header_lbls.append(lbl)
        _entries = []
        def _mark_col(idx):
            # Colour where you are: the header above the field you are
            # typing in turns gold, the rest stay light; the field
            # itself turns pale yellow (Entry widgets only — the Mode
            # dropdown is a Combobox, so its header is its indicator).
            for j, lbl in enumerate(header_lbls):
                lbl.configure(bg="#FFD966" if j == idx else "#F7F3E8")
            for j, ent in enumerate(_entries):
                try:
                    ent.configure(background="#FFF2CC" if j == idx else "white")
                except Exception:
                    pass
        wv = tk.StringVar(value=default_weight or ""); _we = tk.Entry(row, textvariable=wv, font=("Segoe UI", 13, "bold"), width=widths[0]); self._numeric_entry(_we)
        _we.grid(row=1, column=0, padx=1, pady=1, sticky="ew"); _we.focus_set()
        mv = tk.StringVar(value="CASH")
        _mode = ttk.Combobox(row, textvariable=mv, values=PAYMENT_MODES, width=widths[1], state="readonly")
        _mode.grid(row=1, column=1, padx=1, pady=1, sticky="ew")
        def _mode_key(event):
            # Keyboard-only Mode pick: digit 1-7 selects directly; a letter
            # cycles through modes starting with it (C: CASH -> CARD ->
            # CREDIT/UDHAAR -> CHEQUE). Return "break" so the readonly box
            # does not swallow the key.
            ch = getattr(event, "char", "")
            if ch.isdigit() and 1 <= int(ch) <= len(PAYMENT_MODES):
                mv.set(PAYMENT_MODES[int(ch) - 1]); return "break"
            if ch.isalpha():
                cands = [m for m in PAYMENT_MODES if m.lower().startswith(ch.lower())]
                if cands:
                    cur = mv.get()
                    nxt = cands[(cands.index(cur) + 1) % len(cands)] if cur in cands else cands[0]
                    mv.set(nxt)
                return "break"
        _mode.bind("<Key>", _mode_key)
        av = tk.StringVar(); _ae = tk.Entry(row, textvariable=av, font=("Segoe UI", 12), width=widths[2]); self._numeric_entry(_ae)
        _ae.grid(row=1, column=2, padx=1, pady=1, sticky="ew")
        bv = tk.StringVar(); _be = tk.Entry(row, textvariable=bv, width=widths[3])
        _be.grid(row=1, column=3, padx=1, pady=1, sticky="ew")
        rv = tk.StringVar(); _re = tk.Entry(row, textvariable=rv, width=widths[4])
        _re.grid(row=1, column=4, padx=1, pady=1, sticky="ew")
        _entries.extend([_we, _mode, _ae, _be, _re])
        for _i, _w in enumerate(_entries):
            _w.bind("<FocusIn>", lambda e, _i=_i: _mark_col(_i))
        if default_weight:
            # Prefilled (Return flow): weight is already written and
            # Mode defaults to CASH, so the panel opens on Amount.
            _mark_col(2)
            try: win.focus_force()
            except Exception: pass
            _ae.focus_set()
            try: _ae.focus_force()
            except Exception: pass
        else:
            _mark_col(0)
        result = {}
        def ok():
            result.update(weight=wv.get(), remarks=rv.get(), payment_mode=mv.get(),
                          amount=av.get(), bill_no=bv.get())
            win.destroy()
        # Keyboard flow (v1.19): Enter goes Sold -> Amount -> Bill
        # No. -> Remarks -> Save, skipping Mode, because Mode defaults
        # to CASH and is rarely changed. Tab still goes Sold -> Mode
        # -> Amount, so Mode is reached by Tab, by clicking it, or by
        # Shift+Tab from Amount. Ctrl+Enter saves from any field.
        _we.bind("<Return>", lambda e: (_ae.focus_set(), _mark_col(2)))
        _mode.bind("<Return>", lambda e: (_ae.focus_set(), _mark_col(2)))
        _ae.bind("<Return>", lambda e: (_be.focus_set(), _mark_col(3)))
        _be.bind("<Return>", lambda e: (_re.focus_set(), _mark_col(4)))
        _re.bind("<Return>", lambda e: ok())
        win.bind("<Control-Return>", lambda e: ok())
        win.bind("<Alt-s>", lambda e: ok())
        win.bind("<Escape>", lambda e: win.destroy())
        tk.Label(win, text="Enter = Sold → Amount → Bill No./Rokar/Book → Remarks → Save  •  Tab = Sold → Mode → Amount (Mode defaults CASH)  •  Ctrl+Enter = Save Sale  •  Esc = Cancel",
                 font=("Segoe UI", 9), fg="#666666").pack(pady=(10, 0))
        tk.Label(win, text="Mode: 1=CASH  2=UPI  3=CARD  4=BANK TRANSFER  5=CREDIT / UDHAAR  6=CHEQUE  7=OTHER, or ↓ to open list",
                 font=("Segoe UI", 9), fg="#666666").pack()
        ttk.Button(win, text="Save Sale", style="Gold.TButton", command=ok).pack(pady=10)
        win.wait_window()
        return result

    @staticmethod
    def _autocomplete(combo, var, full_values):
        """Type the first letter(s) and the box fills with the first
        matching item — e.g. type L in Category and it shows LADIES
        RING, type P and it shows PAYAL. The dropdown arrow still works
        (click it, or press Down) and then shows only the matching
        items; clearing the box restores the full list. Typing a name
        that is not in the list is left as-is, and Save will say it is
        not found (add it in Settings first)."""
        def _on_key(event):
            if (event.keysym or "") in ("Up", "Down", "Left", "Right", "Tab", "Return",
                                        "Escape", "Shift_L", "Shift_R", "Control_L", "Control_R",
                                        "Alt_L", "Alt_R", "Caps_Lock"):
                return
            text = var.get()
            if not text:
                combo["values"] = full_values()
                return
            matches = [v for v in full_values() if v.lower().startswith(text.lower())]
            combo["values"] = matches if matches else full_values()
            if matches and (event.keysym or "") not in ("BackSpace", "Delete"):
                var.set(matches[0])
                try:
                    combo.icursor(len(text))
                    combo.selection_range(len(text), "end")
                except Exception:
                    pass
        def _restore(event=None):
            combo["values"] = full_values()
        combo.bind("<KeyRelease>", _on_key)
        combo._autocomplete_handler = _on_key  # for testing / direct calls
        combo.bind("<FocusOut>", _restore)
        combo.bind("<<ComboboxSelected>>", _restore)

    def _validate_number(self, proposed):
        """Numbers only (v1.25): digits and at most one decimal point.
        Empty is allowed (clearing the field); a lone "." is allowed
        as a typing step toward ".5". Letters, spaces, minus signs
        and a second "." are rejected, so they never enter the field."""
        if proposed == "" or proposed == ".":
            return True
        if proposed.count(".") > 1:
            return False
        return proposed.replace(".", "", 1).isdigit()

    def _numeric_entry(self, entry):
        """Attach numbers-only typing validation to an Entry widget."""
        try:
            vcmd = (entry.register(self._validate_number), "%P")
            entry.configure(validate="key", validatecommand=vcmd)
        except Exception:
            pass

    @staticmethod
    def _glow(entry):
        """Colour where you are: the field being typed in turns pale
        yellow, and back to white when you leave it."""
        entry.bind("<FocusIn>", lambda e: entry.configure(background="#FFF2CC"))
        entry.bind("<FocusOut>", lambda e: entry.configure(background="white"))

    def _boxout_space_insert(self, event):
        """Shift+Space in a Box Out field = type a real space (v1.24
        escape hatch, since plain Space now always jumps)."""
        w = event.widget
        try:
            try:
                w.delete("sel.first", "sel.last")
            except Exception:
                pass
            w.insert("insert", " ")
        except Exception:
            pass
        return "break"

    def _boxout_space_jump(self, event):
        """Space in a Box Out field = jump to the table, ALWAYS
        (v1.24, at the user's request — the v1.19 complete-value
        condition is removed). Not Enter: Enter in these fields
        saves the box. Returns "break" so the space is swallowed,
        never typed into the field."""
        try:
            rows = self.active_tree.get_children()
            if rows:
                self.active_tree.selection_set(rows[-1])
                self.active_tree.see(rows[-1])
                self.active_tree.focus(rows[-1])
                self.active_cell_col = 0
                self._update_cell_label()
            self.active_tree.focus_set()
        except Exception:
            pass
        return "break"

    def _focus_dashboard_box(self, code):
        try:
            if code in self.active_tree.get_children():
                self.active_tree.selection_set(code)
                self.active_tree.see(code)
                self.active_tree.focus(code)
                self.active_tree.focus_set()
        except Exception:
            pass

    def do_reset_day(self, d):
        """Reset ONE day: delete every entry for that date + that day's
        Excel file. Other days are untouched. A safety backup is made
        first, so a mistaken reset can be restored from the Backup tab."""
        try:
            boxes = DB.boxes_for_date(d)
        except Exception as e:
            messagebox.showerror("Reset", str(e)); return
        excel = excel_path_for(DB.base_dir, d)
        excel_exists = os.path.exists(excel)
        if not boxes and not excel_exists:
            messagebox.showinfo("Nothing to reset", f"There are no entries and no Excel file for {fmt_date(d)}.")
            return
        if not messagebox.askyesno("Reset — confirm",
                f"Reset {fmt_date(d)}?\n\nThis will DELETE:\n"
                f"• {len(boxes)} box(es) and ALL their sales, stock adds and returns for this date\n"
                f"• That day's Excel file: {excel if excel_exists else '(no Excel file yet)'}\n\n"
                "Other days are NOT touched.\n"
                "A safety backup of the whole database is made first, so you can restore "
                "from the Backup tab if this was a mistake.\n\nAre you sure?"):
            return
        # Safety backup first, then Excel, then database — in that order,
        # so a locked Excel file aborts the reset BEFORE any entry is deleted.
        backup = DB.backup()
        excel_deleted = False
        if excel_exists:
            try:
                os.remove(excel); excel_deleted = True
            except PermissionError:
                messagebox.showerror("Excel is open",
                    "Close that day's Excel file first, then press Reset again.\nNothing was deleted.")
                return
            except Exception as e:
                messagebox.showerror("Reset", f"Could not delete the Excel file:\n{e}\nNothing was deleted.")
                return
        boxes_n, txn_n = DB.reset_day(d)
        try:
            pend = [x for x in _read_pending(DB.base_dir) if x != d]
            _write_pending(DB.base_dir, pend)
        except Exception:
            pass
        self.refresh_all()
        messagebox.showinfo("Reset done",
            f"Deleted for {fmt_date(d)}:\n• {boxes_n} box(es)\n• {txn_n} transaction(s)\n"
            f"• Excel file: {'deleted' if excel_deleted else 'was not present'}\n\n"
            f"Safety backup: {backup}\n(Backup tab → Restore can bring it back if needed.)")

    def act_sale(self):
        code = self._selected_box()
        if not code: return
        s = DB.box_summary(code)
        d = self._sale_dialog(code, s['remaining'])
        if not d.get("weight"):
            messagebox.showwarning("Sold weight missing", "Enter the sold weight first, then Amount / Bill No./Rokar/Book")
            return
        try:
            DB.add_sale(code, d["weight"], d["remarks"], payment_mode=d["payment_mode"],
                        amount=d["amount"], bill_no=d["bill_no"])
        except OverWeightError as e:
            if messagebox.askyesno("Overweight — override?",
                    f"Sold weight {e.requested:.4f} g exceeds remaining {e.remaining:.4f} g.\n"
                    "This will make the remaining weight negative.\n\nDo you want to override with a reason?"):
                reason = d["remarks"] or "Override confirmed by user"
                try:
                    DB.add_sale(code, d["weight"], d["remarks"], override=True, override_reason=reason,
                                payment_mode=d["payment_mode"], amount=d["amount"], bill_no=d["bill_no"])
                except Exception as ex:
                    messagebox.showerror("Cannot save", str(ex)); return
            else:
                return
        except Exception as e:
            messagebox.showerror("Cannot save", str(e)); return
        messagebox.showinfo("Sale saved", f"Sale saved for {code}.\nNew remaining: {DB.box_summary(code)['remaining']:.4f} g")
        self.after_save(today_str())
        self._focus_dashboard_box(code)

    def act_stock(self):
        code = self._selected_box()
        if not code: return
        d = self._weight_dialog("Add Stock", f"{code}\nEnter additional stock added (g):")
        if not d.get("weight"): return
        try:
            DB.add_stock(code, d["weight"], d["remarks"])
        except Exception as e:
            messagebox.showerror("Cannot save", str(e)); return
        messagebox.showinfo("Stock added", f"New remaining: {DB.box_summary(code)['remaining']:.4f} g")
        self.after_save(today_str())
        self._focus_dashboard_box(code)

    def _ask_go_to_sell(self, missing, opening, expected, actual):
        """Notification between Return and Sell (v1.17): tells the user
        the exact weight difference and asks whether to go to the Sell
        panel. Enter = Yes (go to Sell panel), Esc = No (return with a
        reason instead). A custom dialog, not a plain messagebox, so
        Enter is guaranteed to mean Yes on every platform."""
        win = tk.Toplevel(self); win.title("Weight difference"); win.geometry("460x220"); win.grab_set()
        tk.Label(win, text=f"⚠  Weight difference: {missing:.4f} g",
                 font=("Segoe UI", 13, "bold"), fg="#B00000").pack(pady=(14, 4))
        tk.Label(win, text=f"Opening: {opening:.4f} g  •  Expected: {expected:.4f} g  •  Returned: {actual:.4f} g",
                 font=("Segoe UI", 11)).pack(pady=2)
        tk.Label(win, text=f"Do you want to go to the Sell panel to record this {missing:.4f} g as a sale?",
                 font=("Segoe UI", 11), wraplength=420).pack(pady=(8, 4))
        tk.Label(win, text="Enter = Yes, go to Sell panel  •  Esc = No, return with a reason",
                 font=("Segoe UI", 9), fg="#666666").pack(pady=(2, 8))
        result = {"go": False}
        def yes():
            result["go"] = True; win.destroy()
        def no():
            win.destroy()
        btns = tk.Frame(win); btns.pack(pady=6)
        _yes = ttk.Button(btns, text="Yes — Go to Sell panel", style="Gold.TButton", command=yes)
        _yes.pack(side="left", padx=8); _yes.focus_set()
        ttk.Button(btns, text="No — Return with reason", command=no).pack(side="left", padx=8)
        win.bind("<Return>", lambda e: yes())
        win.bind("<Escape>", lambda e: no())
        win.wait_window()
        return result["go"]

    def act_return(self):
        """Return FIRST, then Sell (v1.16, notification added v1.17):
        enter the weighing-scale print weight. If the box comes back
        LIGHTER than expected, the missing weight is (almost always) a
        sale that was never recorded, so first a notification asks
        "100.00 g difference — go to Sell panel?" (Enter = Yes), and on
        Yes the Sale panel opens with that difference
        already written in Sold — e.g. opening 400 g, return 300 g, so
        Sold opens at 100.00 g and the user only fills Mode / Amount /
        Bill No. The sale is saved BEFORE the box is closed, so after it
        the expected weight matches the returned weight exactly and the
        box closes with difference 0. If the user cancels the Sale panel,
        the old flow applies: the box returns with the difference noted
        (a reason is required, as before). A box that comes back HEAVIER
        than expected never opens the Sale panel — extra weight is not
        a sale — it returns with a reason, as before."""
        code = self._selected_box()
        if not code: return
        s = DB.box_summary(code)
        d = self._weight_dialog("Return Box", f"{code}\nEnter weighing-scale print weight (g):")
        if not d.get("weight"): return
        sale_note = ""
        try:
            actual = float(d["weight"])
        except Exception:
            actual = None
        if actual is not None:
            diff = round(actual - s["expected_remaining"], 4)
            if diff < -0.00005:
                # Missing weight: opening 400, return 300 -> missing 100.
                # First a notification (v1.17): "100.00 g difference, go
                # to Sell panel?" — Enter = Yes, Esc = No. Only on Yes
                # does the Sale panel open, prefilled with the difference.
                missing = round(-diff, 4)
                if not self._ask_go_to_sell(missing, s["opening_weight"], s["expected_remaining"], actual):
                    sale = {}
                else:
                    sale = self._sale_dialog(code, s["expected_remaining"], default_weight=f"{missing:.4f}")
                if sale.get("weight"):
                    try:
                        DB.add_sale(code, sale["weight"], sale["remarks"], payment_mode=sale["payment_mode"],
                                    amount=sale["amount"], bill_no=sale["bill_no"])
                    except OverWeightError as e:
                        if messagebox.askyesno("Overweight — override?",
                                f"Sold weight {e.requested:.4f} g exceeds remaining {e.remaining:.4f} g.\n"
                                "This will make the remaining weight negative.\n\nDo you want to override with a reason?"):
                            try:
                                DB.add_sale(code, sale["weight"], sale["remarks"], override=True,
                                            override_reason=sale["remarks"] or "Override confirmed by user",
                                            payment_mode=sale["payment_mode"], amount=sale["amount"], bill_no=sale["bill_no"])
                            except Exception as ex:
                                messagebox.showerror("Cannot save sale", str(ex)); return
                        else:
                            return  # sale not saved, box stays open
                    except Exception as e:
                        messagebox.showerror("Cannot save sale", str(e)); return
                    sale_note = f"\nSale recorded first: {float(sale['weight']):.4f} g (the missing weight)."
                    s = DB.box_summary(code)  # sold / expected now include the sale
        try:
            res = DB.return_box(code, d["weight"], d["remarks"])
        except Exception as e:
            messagebox.showerror("Cannot return", str(e)); return
        msg = (f"Box {code} returned.{sale_note}\nOpening: {s['opening_weight']:.4f} g  •  Sold: {s['sold']:.4f} g\n"
               f"Expected: {res['expected']:.4f} g  •  Actual: {res['actual']:.4f} g  •  Difference: {res['difference']:+.4f} g")
        if abs(res["difference"]) >= 0.0001:
            messagebox.showwarning("Weight difference", msg + "\n\nDifference noted in the report.")
        else:
            messagebox.showinfo("Box returned", msg)
        self.after_save(today_str())
        self._focus_dashboard_box(code)

    def act_history(self):
        code = self._selected_box()
        if not code: return
        s = DB.box_summary(code)
        win = tk.Toplevel(self); win.title(f"History — {code}"); win.geometry("720x420")
        info = (f"{code}  •  {s.get('metal') or '?'}  •  {s['category']}  •  {s['salesperson']}  •  Opening {s['opening_weight']:.4f} g  •  "
                f"Sold {s['sold']:.4f} g  •  Added {s['added']:.4f} g  •  Expected {s['expected_remaining']:.4f} g  •  {s['status']}")
        tk.Label(win, text=info, font=("Segoe UI", 10, "bold"), wraplength=700).pack(pady=8)
        cols = ("Txn ID", "Type", "Weight", "Mode", "Amount (Rs)", "Bill No.", "Time", "Remarks")
        tree = ttk.Treeview(win, columns=cols, show="headings")
        for c in cols:
            tree.heading(c, text=("Bill No./Rokar/Book" if c == "Bill No." else c)); tree.column(c, width=(170 if c == "Bill No." else 110), anchor="center")
        tree.pack(fill="both", expand=True, padx=10, pady=5)
        for t in DB.box_history(code):
            mark = " (VOIDED)" if t["voided"] else ""
            tree.insert("", "end", values=(t["txn_id"], t["type"] + mark, f"{t['weight']:.4f}", t.get("payment_mode") or "",
                (f"{t['amount']:.2f}" if t.get("amount") is not None else ""), t.get("bill_no") or "", t["created_at"], t["remarks"] or ""))
        tk.Label(win, text="Audit trail (corrections / voids):", font=("Segoe UI", 10, "bold")).pack(anchor="w", padx=10)
        audit = tk.Text(win, height=6); audit.pack(fill="x", padx=10, pady=5)
        for a in DB.audit_for_box(code):
            audit.insert("end", f"{a['created_at']}  {a['action']}  {a['old_value']} → {a['new_value']}  {a['reason']}\n")
        audit.config(state="disabled")

    # ---------- Daily Entries ----------
    def build_daily(self):
        tab = ttk.Frame(self.nb); self.nb.add(tab, text="  Daily Entries  ")
        top = tk.Frame(tab); top.pack(fill="x", padx=10, pady=8)
        tk.Label(top, text="Date (DD-MM-YYYY):").pack(side="left")
        self.daily_date = tk.StringVar(value=datetime.now().strftime("%d-%m-%Y"))
        _dd = tk.Entry(top, textvariable=self.daily_date, width=12); _dd.pack(side="left", padx=5); _dd.bind("<Return>", lambda e: self.refresh_daily()); self._glow(_dd)
        tk.Label(top, text="Search Box ID:").pack(side="left", padx=(10, 0))
        self.daily_search = tk.StringVar(); _ds = tk.Entry(top, textvariable=self.daily_search, width=18); _ds.pack(side="left", padx=5); _ds.bind("<Return>", lambda e: self.refresh_daily()); self._glow(_ds)
        ttk.Button(top, text="Load", command=self.refresh_daily).pack(side="left", padx=8)
        cols = ("Txn ID", "Box ID", "Category", "Metal", "Salesperson", "Type", "Weight", "Mode", "Amount (Rs)", "Bill No.", "Time", "Remarks")
        self.daily_tree = ttk.Treeview(tab, columns=cols, show="headings", height=22)
        for c, w in zip(cols, [20, 18, 16, 10, 16, 12, 12, 14, 13, 20, 18, 26]):
            self.daily_tree.heading(c, text=("Bill No./Rokar/Book" if c == "Bill No." else c)); self.daily_tree.column(c, width=w, anchor="center")
        self.daily_tree.pack(fill="both", expand=True, padx=10, pady=5)
        btns = tk.Frame(tab); btns.pack(fill="x", padx=10, pady=5)
        ttk.Button(btns, text="✏️ Correct Entry (with reason)", command=self.correct_entry).pack(side="left", padx=5)
        ttk.Button(btns, text="🚫 Void Entry (with reason)", command=self.void_entry).pack(side="left", padx=5)
        ttk.Button(btns, text="📊 Export This Date to Excel", command=self.export_daily).pack(side="left", padx=5)
        ttk.Button(btns, text="🔄 Reset This Date", command=lambda: self._reset_daily_date()).pack(side="left", padx=5)
        tk.Label(tab, text="Keyboard:  ↑ ↓ = pick an entry  •  Enter or C = Correct  •  V = Void  •  Enter in Date / Search = Load",
                 fg="#666666", font=("Segoe UI", 9)).pack(anchor="w", padx=12, pady=(2, 4))
        def _daily_key(event):
            key = (event.keysym or "").lower()
            if key in ("c", "return"):
                self.correct_entry()
            elif key == "v":
                self.void_entry()
        self.daily_tree.bind("<Key>", _daily_key)

    def _reset_daily_date(self):
        try:
            d = parse_ddmmyyyy(self.daily_date.get())
        except Exception as e:
            messagebox.showerror("Date", str(e)); return
        self.do_reset_day(d)

    def refresh_daily(self):
        try:
            d = parse_ddmmyyyy(self.daily_date.get())
        except Exception as e:
            messagebox.showerror("Date", str(e)); return
        for row in self.daily_tree.get_children():
            self.daily_tree.delete(row)
        for t in DB.daily_transactions(d, box_search=self.daily_search.get().strip() or None):
            self.daily_tree.insert("", "end", values=(t["txn_id"], t["box_code"], t["category"], t.get("metal") or "", t["salesperson"],
                t["type"], f"{t['weight']:.4f}", t.get("payment_mode") or "",
                (f"{t['amount']:.2f}" if t.get("amount") is not None else ""), t.get("bill_no") or "",
                t["created_at"], t["remarks"] or ""))

    def _selected_txn(self):
        sel = self.daily_tree.selection()
        if not sel:
            messagebox.showwarning("Select entry", "Please select an entry from the table first."); return None
        return self.daily_tree.item(sel[0])["values"][0]

    def correct_entry(self):
        txn = self._selected_txn()
        if not txn: return
        win = tk.Toplevel(self); win.title("Correct Entry"); win.geometry("380x220"); win.grab_set()
        tk.Label(win, text=f"Correct {txn}", font=("Segoe UI", 11, "bold")).pack(pady=8)
        tk.Label(win, text="New weight (g):").pack(); wv = tk.StringVar(); _we = tk.Entry(win, textvariable=wv, font=("Segoe UI", 12, "bold")); self._numeric_entry(_we); _we.pack(); _we.focus_set()
        tk.Label(win, text="Reason (required — saved in audit trail):").pack(pady=(8, 0)); rv = tk.StringVar(); _re = tk.Entry(win, textvariable=rv, width=44); _re.pack()
        self._glow(_we); self._glow(_re)
        def ok():
            try:
                DB.correct_transaction(txn, wv.get(), rv.get())
            except Exception as e:
                messagebox.showerror("Cannot correct", str(e)); return
            win.destroy(); messagebox.showinfo("Corrected", "Entry corrected. Old value is kept in the audit trail.")
            self.after_save(parse_ddmmyyyy(self.daily_date.get()))
        _we.bind("<Return>", lambda e: _re.focus_set()); _re.bind("<Return>", lambda e: ok())
        win.bind("<Control-Return>", lambda e: ok()); win.bind("<Escape>", lambda e: win.destroy())
        tk.Label(win, text="Enter = next field  •  Ctrl+Enter = Save  •  Esc = Cancel", font=("Segoe UI", 9), fg="#666666").pack(pady=(4, 0))
        ttk.Button(win, text="Save Correction", style="Gold.TButton", command=ok).pack(pady=12)

    def void_entry(self):
        txn = self._selected_txn()
        if not txn: return
        win = tk.Toplevel(self); win.title("Void Entry"); win.geometry("380x180"); win.grab_set()
        tk.Label(win, text=f"Void {txn}?", font=("Segoe UI", 11, "bold")).pack(pady=8)
        tk.Label(win, text="Reason (required):").pack(); rv = tk.StringVar(); _re = tk.Entry(win, textvariable=rv, width=44); _re.pack(); _re.focus_set(); self._glow(_re)
        def ok():
            try:
                DB.void_transaction(txn, rv.get())
            except Exception as e:
                messagebox.showerror("Cannot void", str(e)); return
            win.destroy(); messagebox.showinfo("Voided", "Entry voided. It no longer counts in totals, but stays in the audit trail.")
            self.after_save(parse_ddmmyyyy(self.daily_date.get()))
        win.bind("<Return>", lambda e: ok()); win.bind("<Control-Return>", lambda e: ok()); win.bind("<Escape>", lambda e: win.destroy())
        ttk.Button(win, text="Void Entry", style="Gold.TButton", command=ok).pack(pady=12)

    def export_daily(self):
        try:
            d = parse_ddmmyyyy(self.daily_date.get())
        except Exception as e:
            messagebox.showerror("Date", str(e)); return
        status = sync_excel(DB, d)
        path = excel_path_for(DB.base_dir, d)
        if status == "queued":
            messagebox.showwarning("Queued", "Excel file is open/locked. Update queued — close Excel and retry from the Backup tab.")
        else:
            messagebox.showinfo("Excel exported", f"Saved:\n{path}")
            if messagebox.askyesno("Open Excel?", "Open the Excel file now?"):
                open_file(path)

    # ---------- Reports & History ----------
    def build_reports(self):
        tab = ttk.Frame(self.nb); self.nb.add(tab, text="  Reports & History  ")
        top = tk.Frame(tab); top.pack(fill="x", padx=10, pady=8)
        tk.Label(top, text="Date:").pack(side="left")
        self.rep_date = tk.StringVar(value=datetime.now().strftime("%d-%m-%Y"))
        tk.Entry(top, textvariable=self.rep_date, width=12).pack(side="left", padx=5)
        tk.Label(top, text="Category:").pack(side="left", padx=(10, 0))
        self.rep_cat = tk.StringVar(); self.rep_cat_combo = ttk.Combobox(top, textvariable=self.rep_cat, width=16, state="readonly"); self.rep_cat_combo.pack(side="left", padx=5)
        tk.Label(top, text="Salesperson:").pack(side="left", padx=(10, 0))
        self.rep_sp = tk.StringVar(); self.rep_sp_combo = ttk.Combobox(top, textvariable=self.rep_sp, width=16, state="readonly"); self.rep_sp_combo.pack(side="left", padx=5)
        tk.Label(top, text="Type:").pack(side="left", padx=(10, 0))
        self.rep_type = tk.StringVar(); ttk.Combobox(top, textvariable=self.rep_type, values=["", "BOX_OUT", "SALE", "ADD_STOCK", "RETURN"], width=12, state="readonly").pack(side="left", padx=5)
        tk.Label(top, text="Metal:").pack(side="left", padx=(10, 0))
        self.rep_metal = tk.StringVar(); ttk.Combobox(top, textvariable=self.rep_metal, values=["", "GOLD", "SILVER"], width=9, state="readonly").pack(side="left", padx=5)
        ttk.Button(top, text="Load", command=self.refresh_reports).pack(side="left", padx=8)
        self.rep_summary = tk.Label(tab, font=("Segoe UI", 10, "bold"), fg="#7A5C00")
        self.rep_summary.pack(anchor="w", padx=12)
        cols = ("Txn ID", "Box ID", "Category", "Metal", "Salesperson", "Type", "Weight", "Mode", "Amount (Rs)", "Bill No.", "Time", "Remarks")
        self.rep_tree = ttk.Treeview(tab, columns=cols, show="headings", height=20)
        for c, w in zip(cols, [20, 18, 16, 10, 16, 12, 12, 14, 13, 20, 18, 26]):
            self.rep_tree.heading(c, text=("Bill No./Rokar/Book" if c == "Bill No." else c)); self.rep_tree.column(c, width=w, anchor="center")
        self.rep_tree.pack(fill="both", expand=True, padx=10, pady=5)
        btns = tk.Frame(tab); btns.pack(fill="x", padx=10, pady=5)
        ttk.Button(btns, text="📊 Re-export This Date to Excel", command=self.export_reports_date).pack(side="left", padx=5)
        ttk.Button(btns, text="📂 Open Excel File", command=self.open_reports_excel).pack(side="left", padx=5)
        ttk.Button(btns, text="🖨️ Print (opens Excel for printing)", command=self.open_reports_excel).pack(side="left", padx=5)

    def refresh_reports(self):
        try:
            d = parse_ddmmyyyy(self.rep_date.get())
        except Exception as e:
            messagebox.showerror("Date", str(e)); return
        self.rep_cat_combo["values"] = [""] + [c["name"] for c in DB.categories()]
        self.rep_sp_combo["values"] = [""] + [s["name"] for s in DB.salespersons()]
        t = DB.daily_totals(d)
        self.rep_summary.config(text=f"{fmt_date(d)}  •  Boxes: {t['boxes']}  •  Active: {t['active']}  •  Returned: {t['returned_count']}  •  "
            f"Opening: {t['opening']:.4f} g  •  Sold: {t['sold']:.4f} g  •  Added: {t['added']:.4f} g  •  Remaining (active): {t['remaining']:.4f} g")
        for row in self.rep_tree.get_children():
            self.rep_tree.delete(row)
        for txn in DB.daily_transactions(d, category=self.rep_cat.get() or None, salesperson=self.rep_sp.get() or None, txn_type=self.rep_type.get() or None, metal=self.rep_metal.get() or None):
            self.rep_tree.insert("", "end", values=(txn["txn_id"], txn["box_code"], txn["category"], txn.get("metal") or "", txn["salesperson"],
                txn["type"], f"{txn['weight']:.4f}", txn.get("payment_mode") or "",
                (f"{txn['amount']:.2f}" if txn.get("amount") is not None else ""), txn.get("bill_no") or "",
                txn["created_at"], txn["remarks"] or ""))

    def export_reports_date(self):
        try:
            d = parse_ddmmyyyy(self.rep_date.get())
        except Exception as e:
            messagebox.showerror("Date", str(e)); return
        status = sync_excel(DB, d)
        messagebox.showinfo("Excel", "Excel re-exported." if status == "ok" else "Excel queued — file is open/locked.")

    def open_reports_excel(self):
        try:
            d = parse_ddmmyyyy(self.rep_date.get())
        except Exception as e:
            messagebox.showerror("Date", str(e)); return
        path = excel_path_for(DB.base_dir, d)
        if not os.path.exists(path):
            sync_excel(DB, d)
        if os.path.exists(path):
            open_file(path)
        else:
            messagebox.showwarning("Not found", "Excel file could not be created. It may be open/locked.")

    # ---------- Salesperson Reports ----------
    def build_salesperson(self):
        tab = ttk.Frame(self.nb); self.nb.add(tab, text="  Salesperson Reports  ")
        top = tk.Frame(tab); top.pack(fill="x", padx=10, pady=8)
        tk.Label(top, text="Date:").pack(side="left")
        self.sp_date = tk.StringVar(value=datetime.now().strftime("%d-%m-%Y"))
        tk.Entry(top, textvariable=self.sp_date, width=12).pack(side="left", padx=5)
        ttk.Button(top, text="Load", command=self.refresh_salesperson).pack(side="left", padx=8)
        cols = ("Salesperson", "Boxes", "Categories", "Opening", "Sold", "Added", "Returned", "Returned Count", "Active", "Remaining")
        self.sp_tree = ttk.Treeview(tab, columns=cols, show="headings", height=20)
        for c, w in zip(cols, [16, 8, 26, 12, 12, 12, 12, 13, 8, 12]):
            self.sp_tree.heading(c, text=c); self.sp_tree.column(c, width=w, anchor="center")
        self.sp_tree.pack(fill="both", expand=True, padx=10, pady=5)

    def refresh_salesperson(self):
        try:
            d = parse_ddmmyyyy(self.sp_date.get())
        except Exception as e:
            messagebox.showerror("Date", str(e)); return
        for row in self.sp_tree.get_children():
            self.sp_tree.delete(row)
        for sp in DB.salesperson_report(d):
            self.sp_tree.insert("", "end", values=(sp["salesperson"], sp["boxes"], sp["categories"], f"{sp['opening']:.4f}",
                f"{sp['sold']:.4f}", f"{sp['added']:.4f}", f"{sp['returned']:.4f}", sp["returned_count"], sp["active"], f"{sp['remaining']:.4f}"))

    # ---------- Settings ----------
    def build_settings(self):
        tab = ttk.Frame(self.nb); self.nb.add(tab, text="  Settings  ")
        gen = tk.LabelFrame(tab, text="  General Settings  ", font=("Segoe UI", 11, "bold"), bg="white", fg="#7A5C00")
        gen.pack(fill="x", padx=10, pady=8)
        tk.Label(gen, text="Showroom Name:", bg="white").grid(row=0, column=0, padx=8, pady=6, sticky="e")
        self.showroom_var = tk.StringVar(value=DB.get_setting("showroom_name", "RAMANAND JEWELLERS"))
        tk.Entry(gen, textvariable=self.showroom_var, width=36).grid(row=0, column=1, padx=5, pady=6)
        tk.Label(gen, text="Time Format:", bg="white").grid(row=0, column=2, padx=8, pady=6, sticky="e")
        self.timefmt_var = tk.StringVar(value=DB.get_setting("time_format", "12-hour"))
        ttk.Combobox(gen, textvariable=self.timefmt_var, values=["12-hour", "24-hour"], width=12, state="readonly").grid(row=0, column=3, padx=5, pady=6)
        tk.Label(gen, text="Weight Unit: Grams (fixed)  •  Date Format: DD-MM-YYYY (fixed)", bg="white", fg="#888888").grid(row=1, column=0, columnspan=4, padx=8, pady=2, sticky="w")
        tk.Label(gen, text="Data Folder:", bg="white").grid(row=2, column=0, padx=8, pady=6, sticky="e")
        tk.Label(gen, text=DB.base_dir, bg="white", fg="#333333", wraplength=500).grid(row=2, column=1, columnspan=2, padx=5, pady=6, sticky="w")
        ttk.Button(gen, text="Change Folder…", command=self.change_folder).grid(row=2, column=3, padx=5, pady=6)
        ttk.Button(gen, text="💾 Save General Settings", style="Gold.TButton", command=self.save_general).grid(row=3, column=0, columnspan=4, pady=8)

        mid = tk.Frame(tab); mid.pack(fill="both", expand=True, padx=10, pady=5)
        # Categories
        cf = tk.LabelFrame(mid, text="  Box Categories  ", font=("Segoe UI", 11, "bold"))
        cf.pack(side="left", fill="both", expand=True, padx=5)
        self.cat_list = tk.Listbox(cf, height=14); self.cat_list.pack(fill="both", expand=True, padx=8, pady=5)
        row = tk.Frame(cf); row.pack(fill="x", padx=8, pady=5)
        self.new_cat = tk.StringVar(); tk.Entry(row, textvariable=self.new_cat, width=22).pack(side="left")
        ttk.Button(row, text="Add", command=self.add_cat).pack(side="left", padx=4)
        row2 = tk.Frame(cf); row2.pack(fill="x", padx=8, pady=5)
        ttk.Button(row2, text="Rename", command=lambda: self.rename_list("cat")).pack(side="left", padx=2)
        ttk.Button(row2, text="Deactivate", command=lambda: self.toggle_list("cat", False)).pack(side="left", padx=2)
        ttk.Button(row2, text="Activate", command=lambda: self.toggle_list("cat", True)).pack(side="left", padx=2)
        ttk.Button(row2, text="Delete", command=lambda: self.delete_list("cat")).pack(side="left", padx=2)
        # Salespersons
        sf = tk.LabelFrame(mid, text="  Salespersons  ", font=("Segoe UI", 11, "bold"))
        sf.pack(side="left", fill="both", expand=True, padx=5)
        self.sp_list = tk.Listbox(sf, height=14); self.sp_list.pack(fill="both", expand=True, padx=8, pady=5)
        row = tk.Frame(sf); row.pack(fill="x", padx=8, pady=5)
        self.new_sp = tk.StringVar(); tk.Entry(row, textvariable=self.new_sp, width=22).pack(side="left")
        ttk.Button(row, text="Add", command=self.add_sp).pack(side="left", padx=4)
        row2 = tk.Frame(sf); row2.pack(fill="x", padx=8, pady=5)
        ttk.Button(row2, text="Rename", command=lambda: self.rename_list("sp")).pack(side="left", padx=2)
        ttk.Button(row2, text="Deactivate", command=lambda: self.toggle_list("sp", False)).pack(side="left", padx=2)
        ttk.Button(row2, text="Activate", command=lambda: self.toggle_list("sp", True)).pack(side="left", padx=2)
        ttk.Button(row2, text="Delete", command=lambda: self.delete_list("sp")).pack(side="left", padx=2)
        tk.Label(tab, text="Delete works only for categories / salespersons never used in a box. Used ones can be deactivated instead — their old records stay intact.",
                 fg="#888888", wraplength=1000).pack(padx=10, pady=5)

    def refresh_settings_lists(self):
        self.cat_list.delete(0, "end")
        for c in DB.categories():
            self.cat_list.insert("end", f"{c['name']}  {'(inactive)' if not c['is_active'] else ''}  [id {c['id']}]")
        self.sp_list.delete(0, "end")
        for s in DB.salespersons():
            self.sp_list.insert("end", f"{s['name']}  {'(inactive)' if not s['is_active'] else ''}  [id {s['id']}]")

    def _list_id(self, lst):
        sel = lst.curselection()
        if not sel:
            messagebox.showwarning("Select", "Please select an item from the list first."); return None
        text = lst.get(sel[0])
        try:
            return int(text.rsplit("[id ", 1)[1].rstrip("]"))
        except Exception:
            return None

    def add_cat(self):
        try:
            DB.add_category(self.new_cat.get())
        except Exception as e:
            messagebox.showerror("Cannot add", str(e)); return
        self.new_cat.set(""); self.refresh_all()

    def add_sp(self):
        try:
            DB.add_salesperson(self.new_sp.get())
        except Exception as e:
            messagebox.showerror("Cannot add", str(e)); return
        self.new_sp.set(""); self.refresh_all()

    def rename_list(self, kind):
        lst = self.cat_list if kind == "cat" else self.sp_list
        rid = self._list_id(lst)
        if rid is None: return
        win = tk.Toplevel(self); win.title("Rename"); win.geometry("320x140"); win.grab_set()
        tk.Label(win, text="New name:").pack(pady=8); v = tk.StringVar(); tk.Entry(win, textvariable=v, width=32).pack()
        def ok():
            try:
                if kind == "cat": DB.rename_category(rid, v.get())
                else: DB.rename_salesperson(rid, v.get())
            except Exception as e:
                messagebox.showerror("Cannot rename", str(e)); return
            win.destroy(); self.refresh_all()
        ttk.Button(win, text="Save", style="Gold.TButton", command=ok).pack(pady=10)

    def toggle_list(self, kind, active):
        lst = self.cat_list if kind == "cat" else self.sp_list
        rid = self._list_id(lst)
        if rid is None: return
        if kind == "cat": DB.set_category_active(rid, active)
        else: DB.set_salesperson_active(rid, active)
        self.refresh_all()

    def delete_list(self, kind):
        lst = self.cat_list if kind == "cat" else self.sp_list
        rid = self._list_id(lst)
        if rid is None: return
        if not messagebox.askyesno("Confirm delete", "Delete this item? This cannot be undone."):
            return
        try:
            if kind == "cat": DB.delete_category(rid)
            else: DB.delete_salesperson(rid)
        except Exception as e:
            messagebox.showerror("Cannot delete", str(e)); return
        self.refresh_all()

    def save_general(self):
        DB.set_setting("showroom_name", self.showroom_var.get().strip() or "RAMANAND JEWELLERS")
        DB.set_setting("time_format", self.timefmt_var.get())
        messagebox.showinfo("Saved", "General settings saved.")
        self.refresh_all()

    def change_folder(self):
        folder = filedialog.askdirectory(title="Choose a new Weighing Scale data folder")
        if not folder: return
        new_base = os.path.join(folder, "Weighing Scale") if os.path.basename(folder) != "Weighing Scale" else folder
        try:
            os.makedirs(os.path.join(new_base, "Database"), exist_ok=True)
            import shutil
            if DB.db_path != os.path.join(new_base, "Database", "weighing_scale.db"):
                DB.conn.commit()
                shutil.copy2(DB.db_path, os.path.join(new_base, "Database", "weighing_scale.db"))
            with open(SIDECAR, "w") as f:
                f.write(new_base)
        except Exception as e:
            messagebox.showerror("Cannot change folder", str(e)); return
        messagebox.showinfo("Folder changed", f"Data folder set to:\n{new_base}\n\nPlease restart the app to use the new folder. Your current database was copied there.")

    # ---------- Backup & Restore ----------
    def build_backup(self):
        tab = ttk.Frame(self.nb); self.nb.add(tab, text="  Backup & Restore  ")
        tk.Label(tab, text="Automatic backup runs every time the app closes. The database is the source of truth — Excel is regenerated from it.",
                 wraplength=1000, fg="#666666").pack(padx=12, pady=10, anchor="w")
        btns = tk.Frame(tab); btns.pack(fill="x", padx=10, pady=5)
        ttk.Button(btns, text="💾 Backup Database Now", style="Gold.TButton", command=self.do_backup).pack(side="left", padx=5)
        ttk.Button(btns, text="↩ Restore from Backup…", command=self.do_restore).pack(side="left", padx=5)
        ttk.Button(btns, text="🔄 Retry Pending Excel", command=self.do_retry).pack(side="left", padx=5)
        ttk.Button(btns, text="📂 Open Data Folder", command=lambda: open_file(DB.base_dir)).pack(side="left", padx=5)
        ttk.Button(btns, text="⬆ Check for Updates", command=self.do_manual_update_check).pack(side="left", padx=5)
        tk.Label(tab, text="Database backups:", font=("Segoe UI", 11, "bold")).pack(anchor="w", padx=12, pady=(12, 2))
        self.backup_list = tk.Listbox(tab, height=18); self.backup_list.pack(fill="both", expand=True, padx=10, pady=5)
        tk.Label(tab, text="Restore replaces the current database with the backup file. A safety copy of the current database is made first.",
                 fg="#B00000", wraplength=1000).pack(padx=12, pady=5, anchor="w")

    def refresh_backup_list(self):
        self.backup_list.delete(0, "end")
        try:
            files = sorted(os.listdir(DB.paths["backups"]), reverse=True)
        except Exception:
            files = []
        for f in files:
            self.backup_list.insert("end", f)

    def do_backup(self):
        try:
            dest = DB.backup()
        except Exception as e:
            messagebox.showerror("Backup failed", str(e)); return
        messagebox.showinfo("Backup done", f"Saved:\n{dest}")
        self.refresh_backup_list()

    def do_restore(self):
        path = filedialog.askopenfilename(title="Choose a database backup", filetypes=[("SQLite database", "*.db"), ("All files", "*.*")])
        if not path: return
        if not messagebox.askyesno("Confirm restore", "Restore will replace the current database.\nA safety backup of the current database will be made first.\n\nContinue?"):
            return
        try:
            safety = DB.backup()
            DB.close()
            import shutil
            shutil.copy2(path, DB.db_path)
            # remove WAL so the restored DB opens clean
            for suffix in ("-wal", "-shm"):
                try: os.remove(DB.db_path + suffix)
                except Exception: pass
        except Exception as e:
            messagebox.showerror("Restore failed", str(e)); return
        messagebox.showinfo("Restored", f"Database restored from:\n{path}\n\nSafety backup: {safety}\n\nPlease restart the app.")
        self.destroy()

    def do_manual_update_check(self):
        info = updater_mod.check_for_update(CURRENT_VERSION)
        if not info:
            messagebox.showinfo("Up to date", f"You are on the latest version (v{CURRENT_VERSION}).\n\nIf the update channel has not been set up yet, this check simply finds nothing — the app keeps working normally.")
            return
        self._update_info = info
        self._update_prompted = False
        self._maybe_prompt_update()

    def do_retry(self):
        results = retry_pending(DB)
        if not results:
            messagebox.showinfo("Nothing pending", "No Excel updates are pending.")
        else:
            messagebox.showinfo("Retry result", "\n".join(f"{d}: {s}" for d, s in results.items()))
        self.refresh_all()


    # ---------- Attendance (v1.19, separate panel) ----------
    def build_attendance(self):
        tab = ttk.Frame(self.nb); self.nb.add(tab, text="  Attendance  ")
        top = tk.Frame(tab); top.pack(fill="x", padx=10, pady=8)
        tk.Label(top, text="Date:").pack(side="left")
        self.att_date = tk.StringVar(value=datetime.now().strftime("%d-%m-%Y"))
        tk.Entry(top, textvariable=self.att_date, width=12).pack(side="left", padx=5)
        ttk.Button(top, text="Load", command=self.refresh_attendance).pack(side="left", padx=8)
        self.att_summary = tk.Label(tab, font=("Segoe UI", 10, "bold"), fg="#7A5C00")
        self.att_summary.pack(anchor="w", padx=12)
        # Mark form: Salesperson -> Status -> In -> Out -> Remarks -> Save.
        form = tk.LabelFrame(tab, text="  MARK ATTENDANCE  ", font=("Segoe UI", 11, "bold"), bg="white", fg="#7A5C00")
        form.pack(fill="x", padx=10, pady=5)
        tk.Label(form, text="Salesperson:", bg="white").grid(row=0, column=0, padx=8, pady=10, sticky="e")
        self.att_sp_var = tk.StringVar()
        self.att_sp_combo = ttk.Combobox(form, textvariable=self.att_sp_var, width=24)
        self._autocomplete(self.att_sp_combo, self.att_sp_var, lambda: [s["name"] for s in DB.salespersons(active_only=True)])
        self.att_sp_combo.grid(row=0, column=1, padx=5, pady=10)
        tk.Label(form, text="Status:", bg="white").grid(row=0, column=2, padx=8, pady=10, sticky="e")
        self.att_status_var = tk.StringVar(value="PRESENT")
        self.att_status_combo = ttk.Combobox(form, textvariable=self.att_status_var, values=list(DB.ATTENDANCE_STATUSES), width=12, state="readonly")
        self.att_status_combo.grid(row=0, column=3, padx=5, pady=10)
        tk.Label(form, text="In Time:", bg="white").grid(row=0, column=4, padx=8, pady=10, sticky="e")
        self.att_in_var = tk.StringVar()
        self.att_in_entry = tk.Entry(form, textvariable=self.att_in_var, width=8)
        self._glow(self.att_in_entry)
        self.att_in_entry.grid(row=0, column=5, padx=5, pady=10)
        tk.Label(form, text="Out Time:", bg="white").grid(row=0, column=6, padx=8, pady=10, sticky="e")
        self.att_out_var = tk.StringVar()
        self.att_out_entry = tk.Entry(form, textvariable=self.att_out_var, width=8)
        self._glow(self.att_out_entry)
        self.att_out_entry.grid(row=0, column=7, padx=5, pady=10)
        tk.Label(form, text="Remarks:", bg="white").grid(row=0, column=8, padx=8, pady=10, sticky="e")
        self.att_rem_var = tk.StringVar()
        self.att_rem_entry = tk.Entry(form, textvariable=self.att_rem_var, width=26)
        self._glow(self.att_rem_entry)
        self.att_rem_entry.grid(row=0, column=9, padx=5, pady=10)
        ttk.Button(form, text="💾  SAVE ATTENDANCE", style="Gold.TButton", command=self.save_attendance).grid(row=0, column=10, padx=12, pady=10)
        for _w in (self.att_sp_combo, self.att_status_combo, self.att_in_entry, self.att_out_entry, self.att_rem_entry):
            _w.bind("<Return>", lambda e: self.save_attendance())
        tk.Label(tab, text="In / Out times are HH:MM, e.g. 10:00 — leave them blank if you only want the status.  Click a row below to load it into the form and correct it; saving again updates that day, it never duplicates.",
                 bg="#F7F3E8", fg="#666666", font=("Segoe UI", 9)).pack(anchor="w", padx=12, pady=(2, 4))
        cols = ("Salesperson", "Status", "In Time", "Out Time", "Remarks")
        self.att_tree = ttk.Treeview(tab, columns=cols, show="headings", height=20)
        for c, w in zip(cols, [24, 14, 12, 12, 40]):
            self.att_tree.heading(c, text=c); self.att_tree.column(c, width=w, anchor="center")
        self.att_tree.pack(fill="both", expand=True, padx=10, pady=5)
        self.att_tree.tag_configure("PRESENT", background="#E2EFDA")
        self.att_tree.tag_configure("ABSENT", background="#FCE4E4")
        self.att_tree.tag_configure("LEAVE", background="#FFF2CC")
        self.att_tree.tag_configure("HALF DAY", background="#DDEBF7")
        self.att_tree.bind("<<TreeviewSelect>>", lambda e: self._att_row_to_form())

    def _att_row_to_form(self):
        sel = self.att_tree.selection()
        if not sel:
            return
        vals = self.att_tree.item(sel[0])["values"]
        if len(vals) >= 5:
            self.att_sp_var.set(vals[0])
            self.att_status_var.set(vals[1] or "PRESENT")
            self.att_in_var.set(vals[2] or "")
            self.att_out_var.set(vals[3] or "")
            self.att_rem_var.set(vals[4] or "")

    def refresh_attendance(self):
        try:
            d = parse_ddmmyyyy(self.att_date.get())
        except Exception as e:
            messagebox.showerror("Date", str(e)); return
        self.att_sp_combo["values"] = [s["name"] for s in DB.salespersons(active_only=True)]
        for row in self.att_tree.get_children():
            self.att_tree.delete(row)
        for r in DB.attendance_for_date(d):
            tag = r["status"] if r["status"] in ("PRESENT", "ABSENT", "LEAVE", "HALF DAY") else ""
            self.att_tree.insert("", "end", values=(r["salesperson"], r["status"], r["in_time"], r["out_time"], r["remarks"]), tags=(tag,) if tag else ())
        s = DB.attendance_summary(d)
        self.att_summary.config(text=f"{fmt_date(d)}: {s['total']} salesperson(s), {s['marked']} marked — Present {s['present']}, Absent {s['absent']}, Leave {s['leave']}, Half Day {s['half_day']}, Unmarked {s['unmarked']}")

    def save_attendance(self):
        try:
            d = parse_ddmmyyyy(self.att_date.get())
            DB.mark_attendance(d, self.att_sp_var.get(), self.att_status_var.get(),
                               self.att_in_var.get(), self.att_out_var.get(), self.att_rem_var.get())
        except Exception as e:
            messagebox.showerror("Cannot save", str(e)); return
        messagebox.showinfo("Attendance saved", f"{self.att_sp_var.get()} — {self.att_status_var.get()} for {fmt_date(d)}.")
        self.refresh_attendance()
        # Next unmarked salesperson, so marking a whole day is one
        # Save after another without re-picking names.
        nxt = next((r["salesperson"] for r in DB.attendance_for_date(d) if not r["status"]), "")
        self.att_sp_var.set(nxt)
        self.att_in_var.set(""); self.att_out_var.set(""); self.att_rem_var.set("")
        self.att_status_var.set("PRESENT")
        try:
            self.att_sp_combo.focus_set()
        except Exception:
            pass

if __name__ == "__main__":
    # Self-test used by Setup.bat on a client PC: verifies imports, database
    # and version without opening the GUI. Usage: python app.py --check
    if "--check" in sys.argv:
        import openpyxl  # noqa: F401  (this is the check itself)
        print(f"Weighing Scale v{CURRENT_VERSION} OK")
        print(f"Showroom: {DB.get_setting('showroom_name', '')}")
        print(f"Database: {DB.db_path}")
        print("tkinter + sqlite3 + openpyxl: OK")
        sys.exit(0)
    # Startup: sync today's Excel (queued safely if locked), never erase history.
    # In safe mode (--safe) even this is skipped, to rule out Excel/lock issues.
    if not SAFE_MODE:
        try:
            sync_excel(DB, today_str())
        except Exception:
            pass
    try:
        App().mainloop()
    except Exception:
        import traceback
        _log = write_crash_log(traceback.format_exc())
        try:
            _root = tk.Tk(); _root.withdraw()
            messagebox.showerror("Weighing Scale could not start",
                f"The app could not start. The error has been saved to:\n{_log}\n\n"
                "Please send that file (or a photo of it) so the exact cause can be fixed.\n"
                "Your data in Documents\\Weighing Scale is NOT deleted by this error.")
            _root.destroy()
        except Exception:
            pass
        raise
