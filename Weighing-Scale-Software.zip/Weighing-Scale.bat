@echo off
REM Weighing Scale launcher - no console window stays open.
REM python.exe is a console program, so the old launcher left its cmd
REM window open for as long as the app ran (and closing it killed the app).
REM pythonw.exe is the windowless Python: it runs the same app.py with
REM no console at all, so this batch file exits immediately.
cd /d "%~dp0"
set PYW=
for %%P in (
    "%LOCALAPPDATA%\Programs\Python\Python312\pythonw.exe"
    "%LOCALAPPDATA%\Programs\Python\Python313\pythonw.exe"
    "%LOCALAPPDATA%\Programs\Python\Python314\pythonw.exe"
    "%LOCALAPPDATA%\Programs\Python\Python315\pythonw.exe"
    "%ProgramFiles%\Python312\pythonw.exe"
    "%ProgramFiles%\Python313\pythonw.exe"
    "%ProgramFiles%\Python314\pythonw.exe"
    "%ProgramFiles%\Python315\pythonw.exe"
    "%ProgramFiles(x86)%\Python312\pythonw.exe"
    "%ProgramFiles(x86)%\Python315\pythonw.exe"
    "C:\Python312\pythonw.exe"
    "C:\Python313\pythonw.exe"
    "C:\Python314\pythonw.exe"
    "C:\Python315\pythonw.exe"
) do (
    if not defined PYW if exist %%P set PYW="%%P"
)
if not defined PYW (
    py -3w --version >nul 2>nul
    if %errorlevel%==0 set PYW=py -3w
)
if not defined PYW set PYW=pythonw
start "" %PYW% app.py
exit
