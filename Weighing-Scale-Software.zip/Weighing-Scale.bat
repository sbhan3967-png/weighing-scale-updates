@echo off
REM Weighing Scale launcher - no console window stays open.
REM pythonw.exe is the windowless Python: it runs the same app.py with
REM no console at all, so this batch file exits immediately.
REM v1.29 version-agnostic: Setup writes the exact Python it used
REM into python_used.txt, and this launcher uses THAT interpreter
REM first. Any Python 3.8+ works, because Setup already installed
REM openpyxl for it — and a later Python install cannot silently
REM switch the icon to a fresh interpreter with no openpyxl. If
REM the locked Python was uninstalled, fall through to the search.
cd /d "%~dp0"
if not exist python_used.txt goto :search
set /p PYEXE=<python_used.txt
if not defined PYEXE goto :search
set PYW="%PYEXE:python.exe=pythonw.exe%"
if not exist %PYW% goto :search
goto :run
:search
set PYW=
for %%P in (
    "%LOCALAPPDATA%\Programs\Python\Python312\pythonw.exe"
    "%LOCALAPPDATA%\Programs\Python\Python313\pythonw.exe"
    "%LOCALAPPDATA%\Programs\Python\Python314\pythonw.exe"
    "%LOCALAPPDATA%\Programs\Python\Python315\pythonw.exe"
    "%ProgramFiles%\Python312\pythonw.exe"
    "%ProgramFiles%\Python313\pythonw.exe"
    "%ProgramFiles%\Python314\pythonw.exe"
    "%ProgramFiles%\Python315\pythonw.exe"
    "%ProgramFiles(x86)%\Python312\pythonw.exe"
    "%ProgramFiles(x86)%\Python315\pythonw.exe"
    "C:\Python312\pythonw.exe"
    "C:\Python313\pythonw.exe"
    "C:\Python314\pythonw.exe"
    "C:\Python315\pythonw.exe"
) do (
    if not defined PYW if exist %%P set PYW="%%P"
)
if not defined PYW (
    py -3w --version >nul 2>nul
    if %errorlevel%==0 set PYW=py -3w
)
if not defined PYW set PYW=pythonw
:run
start "" %PYW% app.py
exit
