@echo off
cd /d "%~dp0"
set PY=
for %%P in (
    "%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
    "%LOCALAPPDATA%\Programs\Python\Python313\python.exe"
    "%LOCALAPPDATA%\Programs\Python\Python314\python.exe"
    "%ProgramFiles%\Python312\python.exe"
    "%ProgramFiles%\Python313\python.exe"
) do (
    if not defined PY if exist %%P set PY="%%P"
)
if not defined PY (
    py -3 --version >nul 2>nul
    if %errorlevel%==0 set PY=py -3
)
if not defined PY set PY=python
%PY% app.py
if errorlevel 1 pause
