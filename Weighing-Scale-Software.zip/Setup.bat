@echo off
setlocal
title Weighing Scale - Setup
echo ============================================
echo   Weighing Scale - one-time setup
echo   Jewellery Box Management Software
echo ============================================
echo.
cd /d "%~dp0"
if not exist app.py (
    echo ERROR: app.py not found. Please extract the FULL zip before running Setup.
    pause
    exit /b 1
)
set PY=
for %%P in (
    "%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
    "%LOCALAPPDATA%\Programs\Python\Python313\python.exe"
    "%LOCALAPPDATA%\Programs\Python\Python314\python.exe"
    "%ProgramFiles%\Python312\python.exe"
    "%ProgramFiles%\Python313\python.exe"
    "%ProgramFiles(x86)%\Python312\python.exe"
    "C:\Python312\python.exe"
    "C:\Python313\python.exe"
) do (
    if not defined PY if exist %%P set PY="%%P"
)
if not defined PY (
    py -3 --version >nul 2>nul
    if %errorlevel%==0 set PY=py -3
)
if not defined PY (
    python --version >nul 2>nul
    if %errorlevel%==0 set PY=python
)
if not defined PY (
    echo Python not found - installing Python 3.12 ^(needs internet^)...
    winget install -e --id Python.Python.3.12 --silent --accept-package-agreements --accept-source-agreements
    if errorlevel 1 goto :trypyorg
    goto :findpy
)
goto :pyok
:trypyorg
echo Winget failed - downloading Python directly from python.org...
powershell -NoProfile -ExecutionPolicy Bypass -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri 'https://www.python.org/ftp/python/3.12.7/python-3.12.7-amd64.exe' -OutFile '%TEMP%\weighing-python-setup.exe'"
if errorlevel 1 goto :nopython
"%TEMP%\weighing-python-setup.exe" /quiet InstallAllUsers=0 PrependPath=1 Include_test=0
del "%TEMP%\weighing-python-setup.exe" >nul 2>&1
goto :findpy
:findpy
for %%P in ("%LOCALAPPDATA%\Programs\Python\Python312\python.exe" "C:\Program Files\Python312\python.exe") do (
    if not defined PY if exist %%P set PY="%%P"
)
if not defined PY (
    py -3 --version >nul 2>nul
    if %errorlevel%==0 set PY=py -3
)
if not defined PY (
    echo.
    echo Python was installed but this window cannot see it yet.
    echo Please CLOSE this window, open the folder again and run Setup.bat once more.
    pause
    exit /b 1
)
:pyok
%PY% --version
if errorlevel 1 goto :nopython
echo.
echo [1/2] Installing required package ^(one-time, needs internet^)...
%PY% -m pip install --upgrade pip >nul 2>&1
%PY% -m pip install openpyxl
if errorlevel 1 (
    echo.
    echo ERROR: package install failed. Check internet and run Setup again.
    pause
    exit /b 1
)
echo.
echo [2/2] Creating desktop shortcut...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ws = New-Object -ComObject WScript.Shell; $sc = $ws.CreateShortcut([IO.Path]::Combine($ws.SpecialFolders('Desktop'), 'Weighing Scale.lnk')); $sc.TargetPath = '%~dp0Weighing-Scale.bat'; $sc.WorkingDirectory = '%~dp0'; $sc.IconLocation = '%~dp0icon.ico'; $sc.Save()"
echo.
echo ============================================
echo   Setup complete! Double-click the
echo   "Weighing Scale" icon on your desktop.
echo   Data will live in Documents\Weighing Scale
echo ============================================
pause
exit /b 0
:nopython
echo.
echo ERROR: Python could not be installed automatically.
echo Please install Python 3.10 or newer from https://www.python.org/downloads/
echo ^(tick "Add python.exe to PATH" during install^), then run Setup again.
pause
exit /b 1
