@echo off
setlocal
title Weighing Scale - Setup (installs everything needed)
echo ============================================
echo   Weighing Scale - one-time setup
echo   Jewellery Box Management Software
echo   This setup installs ALL prerequisites:
echo     Any Python 3.8+ + tkinter check (launcher locks to the one Setup finds)
echo     + all Python packages (from the wheels folder,
echo       so packages install even without internet)
echo     + desktop shortcut (hidden launcher, no cmd window)
echo   No admin rights needed. No manual package install.
echo ============================================
echo.
cd /d "%~dp0"
if not exist app.py (
    echo ERROR: app.py not found. Please extract the FULL zip before running Setup.
    pause
    exit /b 1
)
if not exist requirements.txt (
    echo WARNING: requirements.txt not found - package list will use openpyxl directly.
)

rem ---------- Find a REAL Python (not the Microsoft Store stub) ----------
set PY=
for %%P in (
    "%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
    "%LOCALAPPDATA%\Programs\Python\Python313\python.exe"
    "%LOCALAPPDATA%\Programs\Python\Python314\python.exe"
    "%LOCALAPPDATA%\Programs\Python\Python315\python.exe"
    "%ProgramFiles%\Python312\python.exe"
    "%ProgramFiles%\Python313\python.exe"
    "%ProgramFiles%\Python314\python.exe"
    "%ProgramFiles%\Python315\python.exe"
    "%ProgramFiles(x86)%\Python312\python.exe"
    "%ProgramFiles(x86)%\Python315\python.exe"
    "C:\Python312\python.exe"
    "C:\Python313\python.exe"
    "C:\Python314\python.exe"
    "C:\Python315\python.exe"
) do (
    if not defined PY if exist %%P set PY="%%P"
)
if not defined PY (
    py -3 --version >nul 2>nul
    if %errorlevel%==0 set PY=py -3
)
if not defined PY (
    python --version >nul 2>nul
    if %errorlevel%==0 set PY=python
)
if not defined PY (
    echo Python not found - installing Python 3.12 ^(needs internet for this step only^)...
    echo.
    winget install -e --id Python.Python.3.12 --silent --accept-package-agreements --accept-source-agreements
    if errorlevel 1 goto :trypyorg
    goto :findpy
)
goto :pyok
:trypyorg
echo Winget failed - downloading Python directly from python.org...
powershell -NoProfile -ExecutionPolicy Bypass -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri 'https://www.python.org/ftp/python/3.12.7/python-3.12.7-amd64.exe' -OutFile '%TEMP%\weighing-python-setup.exe'"
if errorlevel 1 goto :nopython
echo Installing Python 3.12 silently ^(no admin needed, includes tkinter^)...
"%TEMP%\weighing-python-setup.exe" /quiet InstallAllUsers=0 PrependPath=1 Include_test=0
del "%TEMP%\weighing-python-setup.exe" >nul 2>&1
goto :findpy
:findpy
for %%P in ("%LOCALAPPDATA%\Programs\Python\Python312\python.exe" "C:\Program Files\Python312\python.exe") do (
    if not defined PY if exist %%P set PY="%%P"
)
if not defined PY (
    py -3 --version >nul 2>nul
    if %errorlevel%==0 set PY=py -3
)
if not defined PY (
    echo.
    echo Python was installed but this window cannot see it yet.
    echo Please CLOSE this window, open the folder again and run Setup.bat once more.
    pause
    exit /b 1
)
:pyok
echo [1/5] Python found:
%PY% --version
if errorlevel 1 goto :nopython
echo.
echo [2/5] Checking built-in parts (tkinter for the window, sqlite3 for the database)...
%PY% -c "import tkinter, sqlite3; print('tkinter + sqlite3: OK')"
if errorlevel 1 (
    echo.
    echo ERROR: tkinter is missing from this Python install.
    echo Please reinstall Python from https://www.python.org/downloads/
    echo ^(during install, keep "tcl/tk and IDLE" ticked - it is ticked by default^),
    echo then run Setup.bat again.
    pause
    exit /b 1
)
rem ---------- Lock this Python for the launcher (v1.29, version-agnostic) ----------
rem A new Python installed later must NOT silently change which
rem interpreter the desktop icon uses. So Setup writes the exact
rem interpreter it found into python_used.txt, and the launcher /
rem Debug / Safe bats use that file first. Re-running Setup after
rem installing a different Python re-locks to the new one. If this
rem resolution fails, Setup simply continues without a lock (old
rem behaviour) instead of stopping.
set PYEXE=
for /f "delims=" %%E in ('%PY% -c "import sys; print(sys.executable)"') do set PYEXE=%%E
if defined PYEXE (
    echo %PYEXE% > python_used.txt
    echo Launcher locked to this Python: %PYEXE%
)
echo.
echo [3/5] Installing Python packages (openpyxl for Excel files)...
%PY% -m pip install --upgrade pip >nul 2>&1
if exist wheels\openpyxl-*.whl (
    echo Using the packages bundled in the wheels folder ^(works offline^)...
    %PY% -m pip install --no-index --find-links wheels -r requirements.txt
    if errorlevel 1 (
        echo Bundled install failed - trying online install instead...
        %PY% -m pip install -r requirements.txt
    )
) else (
    %PY% -m pip install -r requirements.txt
    if errorlevel 1 %PY% -m pip install openpyxl
)
if errorlevel 1 (
    echo.
    echo ERROR: package install failed. Check internet and run Setup again.
    echo If this PC has no internet, make sure the wheels folder from the zip
    echo is present next to Setup.bat, then run Setup again.
    pause
    exit /b 1
)
echo.
echo [4/5] Verifying the whole app (imports + database + version)...
%PY% app.py --check
if errorlevel 1 (
    echo.
    echo ERROR: app self-check failed. Run Weighing-Scale-Debug.bat and note the error,
    echo then run Setup.bat again.
    pause
    exit /b 1
)
echo.
echo [5/5] Creating data folders and desktop shortcut...
if exist "%USERPROFILE%\Documents" (
    mkdir "%USERPROFILE%\Documents\Weighing Scale\Database" >nul 2>&1
    mkdir "%USERPROFILE%\Documents\Weighing Scale\Daily Reports" >nul 2>&1
    mkdir "%USERPROFILE%\Documents\Weighing Scale\Backups\Database Backups" >nul 2>&1
)
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ws = New-Object -ComObject WScript.Shell; $sc = $ws.CreateShortcut([IO.Path]::Combine($ws.SpecialFolders('Desktop'), 'Weighing Scale.lnk')); $sc.TargetPath = '%~dp0Weighing-Scale.vbs'; $sc.WorkingDirectory = '%~dp0'; $sc.IconLocation = '%~dp0icon.ico'; $sc.Save()"
echo.
echo ============================================
echo   Setup complete! Everything needed is installed.
echo   Double-click the "Weighing Scale" icon
echo   on your desktop. No cmd window will open.
echo   Data will live in Documents\Weighing Scale
echo   (created above, if Documents exists).
echo ============================================
pause
exit /b 0
:nopython
echo.
echo ERROR: Python could not be installed automatically.
echo Please install Python 3.10 or newer from https://www.python.org/downloads/
echo ^(tick "Add python.exe to PATH" during install^), then run Setup again.
pause
exit /b 1
