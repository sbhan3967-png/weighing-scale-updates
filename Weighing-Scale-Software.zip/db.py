"""Weighing Scale - SQLite data layer. Database is the source of truth.
Excel is always regenerated from this database, never the other way round.
All weights are stored as REAL grams, displayed to 3 decimals (v1.35: every weight figure is 3 decimals).
Dates are stored YYYY-MM-DD, display format DD-MM-YYYY is applied in UI/Excel.
"""
import os, sqlite3, shutil
from datetime import datetime, date

DEFAULT_CATEGORIES = [
    "LADIES RING", "GENTS RING", "LADIES CHAIN", "GENTS CHAIN",
    "NECKLACE", "EARRINGS", "BANGLES", "BRACELET", "PENDANT",
    "PAYAL", "NOSE PIN", "MANGALSUTRA", "OTHER",
]

class ValidationError(Exception):
    pass

class OverWeightError(Exception):
    """Sold weight exceeds remaining weight."""
    def __init__(self, remaining, requested):
        self.remaining = remaining
        self.requested = requested
        super().__init__(f"Sold weight {requested:.3f} g exceeds remaining {remaining:.3f} g")

def fmt_date(d):
    """YYYY-MM-DD -> DD-MM-YYYY"""
    if not d:
        return ""
    try:
        return datetime.strptime(d, "%Y-%m-%d").strftime("%d-%m-%Y")
    except Exception:
        return d

def today_str():
    return date.today().isoformat()

def default_base_dir():
    # Windows: Documents\Weighing Scale ; elsewhere: ~/Weighing Scale
    docs = os.path.join(os.path.expanduser("~"), "Documents")
    if os.path.isdir(docs):
        return os.path.join(docs, "Weighing Scale")
    return os.path.join(os.path.expanduser("~"), "Weighing Scale")

def paths_for(base_dir):
    return {
        "base": base_dir,
        "db_dir": os.path.join(base_dir, "Database"),
        "db": os.path.join(base_dir, "Database", "weighing_scale.db"),
        "reports": os.path.join(base_dir, "Daily Reports"),
        "backups": os.path.join(base_dir, "Backups", "Database Backups"),
        "pending": os.path.join(base_dir, "pending_excel.json"),
    }

def ensure_dirs(base_dir):
    p = paths_for(base_dir)
    for k in ("db_dir", "reports", "backups"):
        os.makedirs(p[k], exist_ok=True)
    return p

SCHEMA = """
CREATE TABLE IF NOT EXISTS box_categories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    is_active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS salespersons (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    is_active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS boxes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    box_id TEXT NOT NULL UNIQUE,
    date TEXT NOT NULL,
    category_id INTEGER NOT NULL REFERENCES box_categories(id),
    salesperson_id INTEGER NOT NULL REFERENCES salespersons(id),
    opening_weight REAL NOT NULL,
    metal TEXT DEFAULT '',
    status TEXT NOT NULL DEFAULT 'ACTIVE',
    returned_weight REAL,
    difference REAL,
    return_remarks TEXT DEFAULT '',
    created_at TEXT NOT NULL,
    closed_at TEXT
);
CREATE TABLE IF NOT EXISTS transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    txn_id TEXT NOT NULL UNIQUE,
    box_id INTEGER NOT NULL REFERENCES boxes(id),
    date TEXT NOT NULL,
    type TEXT NOT NULL,
    weight REAL NOT NULL,
    remarks TEXT DEFAULT '',
    created_at TEXT NOT NULL,
    voided INTEGER NOT NULL DEFAULT 0,
    payment_mode TEXT DEFAULT '',
    amount REAL,
    bill_no TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS payment_splits (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    txn_id TEXT NOT NULL,
    mode TEXT NOT NULL,
    amount REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS audit_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    txn_id TEXT,
    box_id INTEGER,
    action TEXT NOT NULL,
    old_value TEXT DEFAULT '',
    new_value TEXT DEFAULT '',
    reason TEXT DEFAULT '',
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS attendance (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    date TEXT NOT NULL,
    salesperson_id INTEGER NOT NULL REFERENCES salespersons(id),
    status TEXT NOT NULL,
    in_time TEXT DEFAULT '',
    out_time TEXT DEFAULT '',
    remarks TEXT DEFAULT '',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    UNIQUE(date, salesperson_id)
);
CREATE INDEX IF NOT EXISTS idx_attendance_date ON attendance(date);
CREATE TABLE IF NOT EXISTS application_settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_boxes_date ON boxes(date);
CREATE INDEX IF NOT EXISTS idx_boxes_status ON boxes(status);
CREATE INDEX IF NOT EXISTS idx_txn_date ON transactions(date);
CREATE INDEX IF NOT EXISTS idx_txn_box ON transactions(box_id);
"""

class Database:
    def __init__(self, base_dir=None):
        self.base_dir = base_dir or default_base_dir()
        self.paths = ensure_dirs(self.base_dir)
        self.db_path = self.paths["db"]
        self.conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA foreign_keys = ON")
        self.conn.execute("PRAGMA journal_mode = WAL")
        self.conn.executescript(SCHEMA)
        # Migration for databases created before v1.3 (sale payment fields).
        # Existing rows keep working; the new columns simply start empty.
        _bcols = [r[1] for r in self.conn.execute("PRAGMA table_info(boxes)").fetchall()]
        if "metal" not in _bcols:
            self.conn.execute("ALTER TABLE boxes ADD COLUMN metal TEXT DEFAULT ''")
        _cols = [r[1] for r in self.conn.execute("PRAGMA table_info(transactions)").fetchall()]
        for _col, _ddl in (("payment_mode", "TEXT DEFAULT ''"), ("amount", "REAL"), ("bill_no", "TEXT DEFAULT ''")):
            if _col not in _cols:
                self.conn.execute(f"ALTER TABLE transactions ADD COLUMN {_col} {_ddl}")
        self.conn.commit()
        self._seed()

    # ---------- helpers ----------
    def _now(self):
        return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    def _seed(self):
        cur = self.conn.cursor()
        now = self._now()
        for name in DEFAULT_CATEGORIES:
            cur.execute("INSERT OR IGNORE INTO box_categories (name, is_active, created_at) VALUES (?,?,?)",
                        (name, 1, now))
        defaults = {
            "showroom_name": "RAMANAND JEWELLERS",
            "weight_unit": "Grams",
            "date_format": "DD-MM-YYYY",
            "time_format": "12-hour",
            "auto_backup": "1",
        }
        for k, v in defaults.items():
            cur.execute("INSERT OR IGNORE INTO application_settings (key, value) VALUES (?,?)", (k, v))
        self.conn.commit()

    def get_setting(self, key, default=""):
        row = self.conn.execute("SELECT value FROM application_settings WHERE key=?", (key,)).fetchone()
        return row["value"] if row else default

    def set_setting(self, key, value):
        self.conn.execute("INSERT INTO application_settings (key, value) VALUES (?,?) "
                          "ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, str(value)))
        self.conn.commit()

    def _audit(self, cur, txn_id, box_id, action, old, new, reason=""):
        cur.execute("INSERT INTO audit_logs (txn_id, box_id, action, old_value, new_value, reason, created_at) "
                    "VALUES (?,?,?,?,?,?,?)", (txn_id, box_id, action, str(old), str(new), reason, self._now()))

    def _next_txn_id(self, cur):
        """Next transaction id (v1.47 fix): MAX existing number + 1,
        NOT COUNT(*) + 1. The old COUNT rule broke the moment any
        transaction was deleted (Delete Box deletes that box's
        transactions; Reset Day deletes a day's transactions):
        COUNT drops, so the next id REUSED a number that still
        exists — e.g. 3 boxes (txn 1,2,3), delete the first box
        (count 3->2), next sale gets txn 3 again, which is still
        the third box's BOX_OUT, and SQLite raises exactly the
        error in the user's 2026-11-06 video: "UNIQUE constraint
        failed: transactions.txn_id", and the sale does not save.
        MAX + 1 can never collide: the new number is greater
        than every id still in the database, whatever was
        deleted. If the deleted row held the highest number,
        reusing it would also be safe, but MAX + 1 is simpler
        and always moves forward. Suffix is parsed in Python
        (after the last '-') so it stays correct past 99999
        too, where a fixed-width SQL substring would not."""
        _max = 0
        for _r in cur.execute("SELECT txn_id FROM transactions").fetchall():
            try:
                _n = int(str(_r["txn_id"]).rsplit("-", 1)[-1])
                if _n > _max:
                    _max = _n
            except Exception:
                continue
        return f"TXN-{datetime.now().strftime('%Y%m%d')}-{_max + 1:05d}"

    # ---------- categories / salespersons ----------
    def categories(self, active_only=False):
        q = "SELECT * FROM box_categories"
        if active_only:
            q += " WHERE is_active=1"
        return [dict(r) for r in self.conn.execute(q + " ORDER BY name").fetchall()]

    def salespersons(self, active_only=False):
        q = "SELECT * FROM salespersons"
        if active_only:
            q += " WHERE is_active=1"
        return [dict(r) for r in self.conn.execute(q + " ORDER BY name").fetchall()]

    def add_category(self, name):
        name = (name or "").strip().upper()
        if not name:
            raise ValidationError("Category name is required.")
        try:
            self.conn.execute("INSERT INTO box_categories (name, is_active, created_at) VALUES (?,?,?)",
                              (name, 1, self._now()))
            self.conn.commit()
        except sqlite3.IntegrityError:
            raise ValidationError(f"Category '{name}' already exists.")

    def add_salesperson(self, name):
        name = (name or "").strip()
        if not name:
            raise ValidationError("Salesperson name is required.")
        try:
            self.conn.execute("INSERT INTO salespersons (name, is_active, created_at) VALUES (?,?,?)",
                              (name, 1, self._now()))
            self.conn.commit()
        except sqlite3.IntegrityError:
            raise ValidationError(f"Salesperson '{name}' already exists.")

    # ---------- attendance (v1.19) ----------
    ATTENDANCE_STATUSES = ("PRESENT", "ABSENT", "LEAVE", "HALF DAY")

    def mark_attendance(self, d, salesperson_name, status, in_time="", out_time="", remarks=""):
        """One record per salesperson per date; marking again updates
        that day's record instead of adding a duplicate. In/Out times
        are HH:MM when given. Attendance lives in the same database
        as the boxes, so a Backup restores it too."""
        import re as _re
        name = (salesperson_name or "").strip()
        if not name:
            raise ValidationError("Select a salesperson.")
        status = (status or "").strip().upper()
        if status not in self.ATTENDANCE_STATUSES:
            raise ValidationError("Status must be PRESENT, ABSENT, LEAVE or HALF DAY.")
        for _label, _v in (("In time", in_time), ("Out time", out_time)):
            _v = (_v or "").strip()
            if _v and not _re.match(r"^([01]\d|2[0-3]):[0-5]\d$", _v):
                raise ValidationError(f"{_label} must be HH:MM, e.g. 10:00.")
        row = self.conn.execute("SELECT id FROM salespersons WHERE name=?", (name,)).fetchone()
        if not row:
            raise ValidationError(f"Salesperson '{name}' not found (add them in Settings first).")
        sp_id = row["id"]
        now = self._now()
        cur = self.conn.execute("SELECT id FROM attendance WHERE date=? AND salesperson_id=?", (d, sp_id)).fetchone()
        if cur:
            self.conn.execute("UPDATE attendance SET status=?, in_time=?, out_time=?, remarks=?, updated_at=? WHERE id=?",
                              (status, (in_time or "").strip(), (out_time or "").strip(), (remarks or "").strip(), now, cur["id"]))
        else:
            self.conn.execute("INSERT INTO attendance (date, salesperson_id, status, in_time, out_time, remarks, created_at, updated_at) "
                              "VALUES (?,?,?,?,?,?,?,?)",
                              (d, sp_id, status, (in_time or "").strip(), (out_time or "").strip(), (remarks or "").strip(), now, now))
        self.conn.commit()

    def attendance_for_date(self, d):
        """Every ACTIVE salesperson for the date, marked or not, so
        the tab shows who is still unmarked as well as who is present."""
        out = []
        for sp in self.salespersons(active_only=True):
            row = self.conn.execute("SELECT * FROM attendance WHERE date=? AND salesperson_id=?", (d, sp["id"])).fetchone()
            out.append({"salesperson": sp["name"],
                        "status": row["status"] if row else "",
                        "in_time": row["in_time"] if row else "",
                        "out_time": row["out_time"] if row else "",
                        "remarks": row["remarks"] if row else ""})
        return out

    def attendance_for_month(self, year, month):
        """Monthly attendance showcase (v1.34): one row per ACTIVE
        salesperson, one column per day of the month, cells are
        P / A / L / H (PRESENT / ABSENT / LEAVE / HALF DAY) or
        blank when that day was never marked. Totals count only
        marked days — future / unmarked days are never counted
        as absent. Attendance is already stored in this same
        database (one record per salesperson per date), so the
        monthly view is just a different presentation of it,
        and a Backup restores it too."""
        import calendar as _cal
        days = _cal.monthrange(year, month)[1]
        start = f"{year:04d}-{month:02d}-01"
        end = f"{year:04d}-{month:02d}-{days:02d}"
        code_map = {"PRESENT": "P", "ABSENT": "A", "LEAVE": "L", "HALF DAY": "H"}
        rows = []
        for sp in self.salespersons(active_only=True):
            recs = self.conn.execute(
                "SELECT date, status FROM attendance WHERE salesperson_id=? AND date BETWEEN ? AND ?",
                (sp["id"], start, end)).fetchall()
            days_map = {}
            for r in recs:
                try:
                    dnum = int(r["date"][-2:])
                except Exception:
                    continue
                days_map[dnum] = code_map.get(r["status"], "")
            rows.append({
                "salesperson": sp["name"],
                "days": days_map,
                "present": sum(1 for v in days_map.values() if v == "P"),
                "absent": sum(1 for v in days_map.values() if v == "A"),
                "leave": sum(1 for v in days_map.values() if v == "L"),
                "half_day": sum(1 for v in days_map.values() if v == "H"),
                "marked": len(days_map),
            })
        totals = {
            "present": sum(r["present"] for r in rows),
            "absent": sum(r["absent"] for r in rows),
            "leave": sum(r["leave"] for r in rows),
            "half_day": sum(r["half_day"] for r in rows),
            "marked": sum(r["marked"] for r in rows),
        }
        return {"year": year, "month": month, "days": days, "rows": rows, "totals": totals}

    def attendance_summary(self, d):
        rows = self.attendance_for_date(d)
        marked = [r for r in rows if r["status"]]
        return {"total": len(rows), "marked": len(marked), "unmarked": len(rows) - len(marked),
                "present": sum(1 for r in marked if r["status"] == "PRESENT"),
                "absent": sum(1 for r in marked if r["status"] == "ABSENT"),
                "leave": sum(1 for r in marked if r["status"] == "LEAVE"),
                "half_day": sum(1 for r in marked if r["status"] == "HALF DAY")}

    def rename_category(self, cat_id, new_name):
        new_name = (new_name or "").strip().upper()
        if not new_name:
            raise ValidationError("Category name is required.")
        self.conn.execute("UPDATE box_categories SET name=? WHERE id=?", (new_name, cat_id))
        self.conn.commit()

    def rename_salesperson(self, sp_id, new_name):
        new_name = (new_name or "").strip()
        if not new_name:
            raise ValidationError("Salesperson name is required.")
        self.conn.execute("UPDATE salespersons SET name=? WHERE id=?", (new_name, sp_id))
        self.conn.commit()

    def set_category_active(self, cat_id, active):
        self.conn.execute("UPDATE box_categories SET is_active=? WHERE id=?", (1 if active else 0, cat_id))
        self.conn.commit()

    def set_salesperson_active(self, sp_id, active):
        self.conn.execute("UPDATE salespersons SET is_active=? WHERE id=?", (1 if active else 0, sp_id))
        self.conn.commit()

    def delete_category(self, cat_id):
        used = self.conn.execute("SELECT COUNT(*) c FROM boxes WHERE category_id=?", (cat_id,)).fetchone()["c"]
        if used:
            raise ValidationError("Cannot delete a category that has been used in a box. Deactivate it instead.")
        self.conn.execute("DELETE FROM box_categories WHERE id=?", (cat_id,))
        self.conn.commit()

    def delete_salesperson(self, sp_id):
        used = self.conn.execute("SELECT COUNT(*) c FROM boxes WHERE salesperson_id=?", (sp_id,)).fetchone()["c"]
        if used:
            raise ValidationError("Cannot delete a salesperson who has handled a box. Deactivate them instead.")
        self.conn.execute("DELETE FROM salespersons WHERE id=?", (sp_id,))
        self.conn.commit()

    def _resolve_category(self, name):
        row = self.conn.execute("SELECT * FROM box_categories WHERE name=?", (name.strip().upper(),)).fetchone()
        if not row:
            raise ValidationError(f"Category '{name}' not found. Add it with the + New Category button next to Box Category, or in Settings.")
        if not row["is_active"]:
            raise ValidationError(f"Category '{name}' is deactivated.")
        return dict(row)

    def _resolve_salesperson(self, name):
        row = self.conn.execute("SELECT * FROM salespersons WHERE name=?", (name.strip(),)).fetchone()
        if not row:
            raise ValidationError(f"Salesperson '{name}' not found. Add them in Settings first.")
        if not row["is_active"]:
            raise ValidationError(f"Salesperson '{name}' is deactivated.")
        return dict(row)

    @staticmethod
    def _check_weight(w):
        try:
            v = float(w)
        except Exception:
            raise ValidationError("Weight must be a number.")
        if v <= 0:
            raise ValidationError("Weight must be greater than 0.")
        return round(v, 3)

    # ---------- boxes ----------
    def next_box_id(self, d=None):
        d = d or today_str()
        prefix = "BOX-" + d.replace("-", "")
        row = self.conn.execute("SELECT box_id FROM boxes WHERE date=? ORDER BY id DESC LIMIT 1", (d,)).fetchone()
        n = 1
        if row:
            try:
                n = int(row["box_id"].rsplit("-", 1)[-1]) + 1
            except Exception:
                n = 1
        return f"{prefix}-{n:03d}"

    def create_box(self, category_name, salesperson_name, opening_weight, d=None, metal=""):
        d = d or today_str()
        metal = (metal or "").strip().upper()
        if metal not in ("GOLD", "SILVER"):
            raise ValidationError("Please select the box metal: GOLD or SILVER.")
        opening = self._check_weight(opening_weight)
        cat = self._resolve_category(category_name)
        sp = self._resolve_salesperson(salesperson_name)
        box_id = self.next_box_id(d)
        cur = self.conn.cursor()
        try:
            cur.execute("INSERT INTO boxes (box_id, date, category_id, salesperson_id, opening_weight, metal, status, created_at) "
                        "VALUES (?,?,?,?,?,?,'ACTIVE',?)",
                        (box_id, d, cat["id"], sp["id"], opening, metal, self._now()))
            bid = cur.lastrowid
            txn = self._next_txn_id(cur)
            cur.execute("INSERT INTO transactions (txn_id, box_id, date, type, weight, remarks, created_at) "
                        "VALUES (?,?,?,'BOX_OUT',?,'Box taken out',?)",
                        (txn, bid, d, opening, self._now()))
            self._audit(cur, txn, bid, "BOX_OUT", "", f"{opening:.3f} g", "Box opened")
            self.conn.commit()
        except Exception:
            self.conn.rollback()
            raise
        return box_id

    def get_box(self, box_id_str):
        row = self.conn.execute(
            "SELECT b.*, c.name AS category, s.name AS salesperson FROM boxes b "
            "JOIN box_categories c ON c.id=b.category_id "
            "JOIN salespersons s ON s.id=b.salesperson_id WHERE b.box_id=?", (box_id_str,)).fetchone()
        return dict(row) if row else None

    def box_summary(self, box_id_str):
        box = self.get_box(box_id_str)
        if not box:
            raise ValidationError(f"Box {box_id_str} not found.")
        sold = self.conn.execute("SELECT COALESCE(SUM(weight),0) s FROM transactions WHERE box_id=? AND type='SALE' AND voided=0",
                                 (box["id"],)).fetchone()["s"]
        added = self.conn.execute("SELECT COALESCE(SUM(weight),0) s FROM transactions WHERE box_id=? AND type='ADD_STOCK' AND voided=0",
                                  (box["id"],)).fetchone()["s"]
        expected = round(box["opening_weight"] + added - sold, 3)
        sale_amount = self.conn.execute("SELECT COALESCE(SUM(amount),0) s FROM transactions WHERE box_id=? AND type='SALE' AND voided=0",
                                        (box["id"],)).fetchone()["s"]
        bill_rows = self.conn.execute("SELECT bill_no FROM transactions WHERE box_id=? AND type='SALE' AND voided=0 AND bill_no IS NOT NULL AND bill_no != '' ORDER BY id",
                                      (box["id"],)).fetchall()
        out = dict(box)
        out["sold"] = round(sold, 3)
        out["added"] = round(added, 3)
        out["expected_remaining"] = expected
        out["remaining"] = expected  # kept for validation/history; no longer a Dashboard column (v1.6)
        out["sale_amount"] = round(sale_amount, 2)
        out["bill_nos"] = ", ".join(r["bill_no"] for r in bill_rows)
        # "Return" for the Dashboard table: actual returned weight once closed, blank while active
        out["return_weight"] = box["returned_weight"]
        return out

    def latest_sale(self, box_id_str):
        box = self.get_box(box_id_str)
        if not box:
            return None
        row = self.conn.execute("SELECT * FROM transactions WHERE box_id=? AND type='SALE' AND voided=0 ORDER BY id DESC LIMIT 1",
                                (box["id"],)).fetchone()
        return dict(row) if row else None

    def update_latest_sale(self, box_id_str, amount=None, bill_no=None):
        """Manual cell edit: set Amount and/or Bill No. on the box's latest
        sale. Used by Dashboard inline editing (Sell Amount / Bill No.
        columns). Raises ValidationError if there is no sale yet."""
        sale = self.latest_sale(box_id_str)
        if not sale:
            raise ValidationError("No sale yet for this box — enter a Sold weight first, then Amount / Bill No.")
        sets, params = [], []
        if amount is not None:
            amt = self._check_amount(amount)
            sets.append("amount=?"); params.append(amt)
        if bill_no is not None:
            sets.append("bill_no=?"); params.append(str(bill_no).strip())
        if not sets:
            return sale["txn_id"]
        params.append(sale["id"])
        cur = self.conn.cursor()
        cur.execute(f"UPDATE transactions SET {', '.join(sets)} WHERE id=?", params)
        self._audit(cur, sale["txn_id"], sale["box_id"], "MANUAL_EDIT", "",
                    f"Amount={amount} Bill={bill_no}", "Dashboard cell edit")
        self.conn.commit()
        return sale["txn_id"]

    def get_transaction(self, txn_id):
        row = self.conn.execute("SELECT * FROM transactions WHERE txn_id=?", (txn_id,)).fetchone()
        return dict(row) if row else None

    def get_splits(self, txn_id):
        rows = self.conn.execute("SELECT mode, amount FROM payment_splits WHERE txn_id=? ORDER BY id", (txn_id,)).fetchall()
        return [dict(r) for r in rows]

    @staticmethod
    def _validate_splits(splits, total_amount):
        """Split payment (v1.30): at least 2 different modes, every
        split > 0, and the splits must add up to the total amount
        (within 1 paisa). Returns a normalised [(mode, amount)] list.
        A single-mode sale passes splits=None and skips this."""
        if not splits or len(splits) < 2:
            raise ValidationError("Split payment needs at least 2 modes (e.g. CASH + UPI).")
        if total_amount is None:
            raise ValidationError("Split payment needs a total amount — the splits must add up to it.")
        modes, out, total = [], [], 0.0
        for mode, amt in splits:
            mode = (mode or "").strip()
            if not mode:
                raise ValidationError("Every split needs a payment mode.")
            if mode in modes:
                raise ValidationError(f"Split mode {mode} is used twice — use each mode once.")
            try:
                v = float(amt)
            except Exception:
                raise ValidationError("Every split amount must be a number (Rs).")
            if v <= 0:
                raise ValidationError("Every split amount must be more than 0.")
            modes.append(mode); out.append((mode, round(v, 2))); total += round(v, 2)
        if abs(round(total, 2) - round(float(total_amount), 2)) > 0.01:
            raise ValidationError(f"Split amounts add up to Rs {total:.2f}, not the total Rs {float(total_amount):.2f}. Fix a split amount first.")
        return out

    def _save_splits(self, cur, txn_id, splits):
        cur.execute("DELETE FROM payment_splits WHERE txn_id=?", (txn_id,))
        for mode, amt in splits:
            cur.execute("INSERT INTO payment_splits (txn_id, mode, amount) VALUES (?,?,?)", (txn_id, mode, amt))

    def _add_txn(self, box, txn_type, weight, remarks, override_reason="", payment_mode="", amount=None, bill_no=""):
        cur = self.conn.cursor()
        try:
            txn = self._next_txn_id(cur)
            cur.execute("INSERT INTO transactions (txn_id, box_id, date, type, weight, remarks, created_at, payment_mode, amount, bill_no) "
                        "VALUES (?,?,?, ?,?,?,?, ?,?,?)",
                        (txn, box["id"], box["date"], txn_type, weight, remarks, self._now(),
                         payment_mode or "", amount, bill_no or ""))
            self._audit(cur, txn, box["id"], txn_type, "", f"{weight:.3f} g", override_reason or remarks)
            self.conn.commit()
            return txn
        except Exception:
            self.conn.rollback()
            raise

    @staticmethod
    def _check_amount(amount):
        """Amount (Rs) is optional; if given it must be a number >= 0."""
        if amount is None or (isinstance(amount, str) and not amount.strip()):
            return None
        try:
            v = float(amount)
        except Exception:
            raise ValidationError("Amount must be a number (Rs).")
        if v < 0:
            raise ValidationError("Amount cannot be negative.")
        return round(v, 2)

    def add_sale(self, box_id_str, weight, remarks="", override=False, override_reason="",
                 payment_mode="", amount=None, bill_no="", splits=None):
        w = self._check_weight(weight)
        amt = self._check_amount(amount)
        norm_splits = None
        if splits is not None:
            norm_splits = self._validate_splits(splits, amt)
            payment_mode = "+".join(m for m, _ in norm_splits)
        box = self.box_summary(box_id_str)
        if box["status"] != "ACTIVE":
            raise ValidationError("This box is already returned / closed. It cannot take new sales.")
        if w > box["remaining"] and not override:
            raise OverWeightError(box["remaining"], w)
        if w > box["remaining"] and not (override_reason or "").strip():
            raise ValidationError("An override reason is required when sold weight exceeds remaining weight.")
        txn_id = self._add_txn(box, "SALE", w, remarks, override_reason,
                               payment_mode=payment_mode, amount=amt, bill_no=bill_no)
        if norm_splits:
            cur = self.conn.cursor()
            try:
                self._save_splits(cur, txn_id, norm_splits)
                self.conn.commit()
            except Exception:
                self.conn.rollback()
                raise
        return txn_id

    def edit_sale(self, txn_id, weight, payment_mode="", amount=None, bill_no="", remarks="", splits=None, reason=""):
        """Edit a past sale (v1.30): weight (gm), mode, amount, bill
        no. and remarks can all be changed, even minutes later — e.g.
        a 2 gm CASH sale can become a different weight, a different
        mode, or a split CASH+UPI sale. The old values are NOT
        deleted: they are kept in the audit trail (SALE_EDIT, old ->
        new). Weight rules: on an ACTIVE box the new weight must
        fit in (remaining + old weight); on a CLOSED box the weight
        may change freely and the box difference is recomputed, so
        the return stays consistent. Splits, when given, replace the
        old splits entirely (or clear them, when splits=None and the
        sale becomes single-mode)."""
        row = self.get_transaction(txn_id)
        if not row:
            raise ValidationError("Sale not found.")
        if row["type"] != "SALE":
            raise ValidationError("Only a sale entry can be edited this way.")
        if row["voided"]:
            raise ValidationError("This sale is voided — it cannot be edited.")
        w = self._check_weight(weight)
        amt = self._check_amount(amount)
        norm_splits = None
        if splits is not None:
            norm_splits = self._validate_splits(splits, amt)
            payment_mode = "+".join(m for m, _ in norm_splits)
        box = self.box_summary(self.conn.execute("SELECT box_id FROM boxes WHERE id=?", (row["box_id"],)).fetchone()["box_id"])
        if box["status"] == "ACTIVE":
            available = round(box["remaining"] + row["weight"], 3)
            if w > available:
                raise OverWeightError(available, w)
        old_desc = f"{row['weight']:.3f} g, {row.get('payment_mode') or ''}, Rs {row['amount'] if row['amount'] is not None else ''}, Bill {row.get('bill_no') or ''}"
        new_desc = f"{w:.3f} g, {payment_mode or ''}, Rs {amt if amt is not None else ''}, Bill {(bill_no or '').strip()}"
        cur = self.conn.cursor()
        try:
            cur.execute("UPDATE transactions SET weight=?, payment_mode=?, amount=?, bill_no=?, remarks=? WHERE id=?",
                        (w, payment_mode or "", amt, (bill_no or "").strip(), remarks or "", row["id"]))
            if norm_splits:
                self._save_splits(cur, txn_id, norm_splits)
            else:
                cur.execute("DELETE FROM payment_splits WHERE txn_id=?", (txn_id,))
            # Closed box: recompute its difference from the new sold total.
            if box["status"] == "CLOSED" and box["returned_weight"] is not None:
                s = self.conn.execute("SELECT COALESCE(SUM(weight),0) s FROM transactions WHERE box_id=? AND type='SALE' AND voided=0", (row["box_id"],)).fetchone()["s"]
                a = self.conn.execute("SELECT COALESCE(SUM(weight),0) s FROM transactions WHERE box_id=? AND type='ADD_STOCK' AND voided=0", (row["box_id"],)).fetchone()["s"]
                expected = round(box["opening_weight"] + a - s, 3)
                cur.execute("UPDATE boxes SET difference=? WHERE id=?", (round(box["returned_weight"] - expected, 3), row["box_id"]))
            self._audit(cur, txn_id, row["box_id"], "SALE_EDIT", old_desc, new_desc, reason or "Sale edited")
            self.conn.commit()
        except Exception:
            self.conn.rollback()
            raise
        return txn_id

    def add_stock(self, box_id_str, weight, remarks=""):
        w = self._check_weight(weight)
        box = self.box_summary(box_id_str)
        if box["status"] != "ACTIVE":
            raise ValidationError("This box is already returned / closed.")
        return self._add_txn(box, "ADD_STOCK", w, remarks)

    def return_box(self, box_id_str, actual_weight, remarks=""):
        actual = self._check_weight(actual_weight)
        box = self.box_summary(box_id_str)
        if box["status"] != "ACTIVE":
            raise ValidationError("This box is already returned.")
        expected = box["expected_remaining"]
        diff = round(actual - expected, 3)
        # v1.27: auto-return on a weight difference, with auto remarks
        # instead of blocking. A Mettler scale can show 0.001 g (
        # mili) or more difference, often returned MORE than expected,
        # and the old rule ("enter a reason first or the box stays
        # open") blocked exactly that case. Now, if no remarks were
        # typed, remarks are generated automatically from the exact
        # difference, so the return completes and the audit trail
        # still records what happened. A remark the user DID type is
        # always kept, never overwritten. Diff within 0.0001 g needs
        # no remarks at all, as before.
        if abs(diff) >= 0.0001 and not (remarks or "").strip():
            if diff > 0:
                remarks = (f"Auto: scale difference {diff:+.3f} g — returned {actual:.3f} g "
                           f"vs expected {expected:.3f} g (returned more than expected)")
            else:
                remarks = (f"Auto: difference {diff:+.3f} g — returned {actual:.3f} g "
                           f"vs expected {expected:.3f} g (returned less than expected, no sale recorded)")
        cur = self.conn.cursor()
        try:
            txn = self._next_txn_id(cur)
            cur.execute("INSERT INTO transactions (txn_id, box_id, date, type, weight, remarks, created_at) "
                        "VALUES (?,?,?,'RETURN',?,?,?)",
                        (txn, box["id"], box["date"], actual, remarks, self._now()))
            cur.execute("UPDATE boxes SET status='CLOSED', returned_weight=?, difference=?, return_remarks=?, closed_at=? WHERE id=?",
                        (actual, diff, remarks, self._now(), box["id"]))
            self._audit(cur, txn, box["id"], "RETURN", f"Expected {expected:.3f} g", f"Returned {actual:.3f} g, diff {diff:+.3f} g", remarks)
            self.conn.commit()
        except Exception:
            self.conn.rollback()
            raise
        return {"expected": expected, "actual": actual, "difference": diff}

    def carry_forward_silver(self, today):
        """Silver carry-forward (v1.35, per-box from v1.41):
        for EVERY ACTIVE silver box from before today, close it
        at exactly its remaining weight (difference 0, remarks
        say it was carried forward) and open a NEW silver box
        today for the same category + salesperson with opening
        = that box's remaining. Yes — every box, individually:
        two silver boxes of the same category + salesperson
        become two new boxes today (e.g. 1980 g + 2000 g), not
        just the latest one. The v1.35-v1.40 per-group rule
        (latest box per category + salesperson only) stranded
        the other boxes on yesterday, as seen on 2026-11-03
        with BOX-20261102-003 (BRACELET + ajay, 1980 g left).
        Gold boxes are never carried — gold stays daily and
        must be returned by hand. A zero-remaining box is not
        carried (opening must be > 0). Duplicate protection
        is the box status itself: after a carry the old box is
        CLOSED, so starting the app twice never duplicates a
        carry, and a manually created box today is a separate
        box, not a reason to skip yesterday's box. Returns a
        list of {old_box_id, new_box_id, category, salesperson,
        opening}."""
        carried = []
        rows = self.conn.execute(
            "SELECT b.*, c.name AS category, s.name AS salesperson FROM boxes b "
            "JOIN box_categories c ON c.id=b.category_id JOIN salespersons s ON s.id=b.salesperson_id "
            "WHERE b.metal='SILVER' AND b.status='ACTIVE' AND b.date < ? ORDER BY b.date ASC, b.id ASC",
            (today,)).fetchall()
        for r in rows:
            summary = self.box_summary(r["box_id"])
            remaining = summary["expected_remaining"]
            if not remaining or remaining <= 0:
                continue
            self.return_box(r["box_id"], remaining,
                            f"Carried forward to {today} — silver remaining becomes today's opening")
            new_id = self.create_box(r["category"], r["salesperson"], remaining, d=today, metal="SILVER")
            carried.append({"old_box_id": r["box_id"], "new_box_id": new_id,
                            "category": r["category"], "salesperson": r["salesperson"],
                            "opening": remaining})
        return carried

    def edit_box(self, box_id_str, category_name, salesperson_name, metal, opening_weight=None, reason=""):
        """Edit ONE box row (v1.39, Dashboard Edit Box):
        Category, Salesperson and Metal can change any time —
        they are labels, they do not change any weight total.
        Opening Weight can change ONLY on an ACTIVE box with no
        sales and no added stock yet (the usual typo case: a
        freshly created box with a wrong opening weight). After
        sales / stock, or once returned, opening is locked —
        use Correct / Void for transactions, or Return and make
        a new box. Changing category / salesperson to a
        deactivated name is rejected, EXCEPT keeping the box's
        own current category / salesperson (so a box whose
        category was later deactivated can still be edited).
        Every change is kept in the audit trail (BOX_EDIT,
        old -> new). Returns the box code. No change -> no write."""
        box = self.get_box(box_id_str)
        if not box:
            raise ValidationError("Box not found.")
        summary = self.box_summary(box_id_str)
        metal = (metal or "").strip().upper()
        if metal not in ("GOLD", "SILVER"):
            raise ValidationError("Metal must be GOLD or SILVER.")
        # Category: keep own id if unchanged, else resolve (active only).
        if (category_name or "").strip().upper() == box["category"]:
            cat_id = box["category_id"]
        else:
            cat_id = self._resolve_category(category_name)["id"]
        if (salesperson_name or "").strip() == box["salesperson"]:
            sp_id = box["salesperson_id"]
        else:
            sp_id = self._resolve_salesperson(salesperson_name)["id"]
        new_opening = box["opening_weight"]
        if opening_weight is not None and str(opening_weight).strip() != "":
            try:
                _new_w = float(opening_weight)
            except Exception:
                raise ValidationError("Opening weight must be a number.")
            if round(_new_w, 3) != round(box["opening_weight"], 3):
                if box["status"] != "ACTIVE":
                    raise ValidationError("Opening weight cannot be changed on a returned box.")
                if summary["sold"] > 0 or summary["added"] > 0:
                    raise ValidationError("Opening weight cannot be changed after sales or stock adds — use Correct / Void for those entries.")
                new_opening = self._check_weight(opening_weight)
        old_desc = f"{box['category']}, {box['salesperson']}, {box['metal'] or ''}, Opening {box['opening_weight']:.3f} g"
        # Resolve new names for the audit description.
        new_cat = self.conn.execute("SELECT name FROM box_categories WHERE id=?", (cat_id,)).fetchone()["name"]
        new_sp = self.conn.execute("SELECT name FROM salespersons WHERE id=?", (sp_id,)).fetchone()["name"]
        new_desc = f"{new_cat}, {new_sp}, {metal}, Opening {new_opening:.3f} g"
        if old_desc == new_desc:
            return box_id_str
        cur = self.conn.cursor()
        try:
            cur.execute("UPDATE boxes SET category_id=?, salesperson_id=?, metal=?, opening_weight=? WHERE id=?",
                        (cat_id, sp_id, metal, new_opening, box["id"]))
            self._audit(cur, box_id_str, box["id"], "BOX_EDIT", old_desc, new_desc, reason or "Box edited")
            self.conn.commit()
        except Exception:
            self.conn.rollback()
            raise
        return box_id_str

    def delete_box(self, box_id_str):
        """Delete ONE box row (v1.39, Dashboard Delete Box):
        allowed ONLY if the box has no non-voided sales, stock
        adds or return yet — i.e. a mistakenly created box with
        only its BOX_OUT entry. A box with real entries cannot
        be deleted (that would erase sales history); use Return,
        or Void / Correct its entries, or Reset Today for the
        whole day. Deletes the box, its transactions and its
        audit rows (same pattern as reset_day, but for one box).
        The caller must make a safety backup BEFORE calling
        this, and must sync Excel afterwards. Returns the box
        code."""
        box = self.get_box(box_id_str)
        if not box:
            raise ValidationError("Box not found.")
        bad = self.conn.execute(
            "SELECT COUNT(*) c FROM transactions WHERE box_id=? AND voided=0 AND type IN ('SALE', 'ADD_STOCK', 'RETURN')",
            (box["id"],)).fetchone()["c"]
        if bad:
            raise ValidationError("This box has sales, stock adds or a return — it cannot be deleted. Use Return, or Void / Correct its entries instead.")
        if box["status"] != "ACTIVE":
            raise ValidationError("This box is already returned — it cannot be deleted.")
        cur = self.conn.cursor()
        try:
            cur.execute("DELETE FROM audit_logs WHERE box_id=?", (box["id"],))
            cur.execute("DELETE FROM transactions WHERE box_id=?", (box["id"],))
            cur.execute("DELETE FROM boxes WHERE id=?", (box["id"],))
            self.conn.commit()
        except Exception:
            self.conn.rollback()
            raise
        return box_id_str

    def correct_transaction(self, txn_id, new_weight, reason):
        if not (reason or "").strip():
            raise ValidationError("A reason is required for every correction (audit trail).")
        w = self._check_weight(new_weight)
        row = self.conn.execute("SELECT * FROM transactions WHERE txn_id=?", (txn_id,)).fetchone()
        if not row:
            raise ValidationError("Transaction not found.")
        if row["voided"]:
            raise ValidationError("This transaction is already voided.")
        if row["type"] not in ("SALE", "ADD_STOCK", "BOX_OUT"):
            raise ValidationError("Only sale, stock and opening entries can be corrected.")
        cur = self.conn.cursor()
        try:
            old = row["weight"]
            cur.execute("UPDATE transactions SET weight=? WHERE id=?", (w, row["id"]))
            if row["type"] == "BOX_OUT":
                cur.execute("UPDATE boxes SET opening_weight=? WHERE id=?", (w, row["box_id"]))
            # recompute difference for a closed box
            box = self.conn.execute("SELECT * FROM boxes WHERE id=?", (row["box_id"],)).fetchone()
            if box and box["status"] == "CLOSED" and box["returned_weight"] is not None:
                s = self.conn.execute("SELECT COALESCE(SUM(weight),0) s FROM transactions WHERE box_id=? AND type='SALE' AND voided=0", (box["id"],)).fetchone()["s"]
                a = self.conn.execute("SELECT COALESCE(SUM(weight),0) s FROM transactions WHERE box_id=? AND type='ADD_STOCK' AND voided=0", (box["id"],)).fetchone()["s"]
                opening = w if row["type"] == "BOX_OUT" else box["opening_weight"]
                expected = round(opening + a - s, 3)
                cur.execute("UPDATE boxes SET difference=? WHERE id=?", (round(box["returned_weight"] - expected, 3), box["id"]))
            self._audit(cur, txn_id, row["box_id"], "CORRECTION", f"{old:.3f} g", f"{w:.3f} g", reason)
            self.conn.commit()
        except Exception:
            self.conn.rollback()
            raise

    def void_transaction(self, txn_id, reason):
        if not (reason or "").strip():
            raise ValidationError("A reason is required to void an entry (audit trail).")
        row = self.conn.execute("SELECT * FROM transactions WHERE txn_id=?", (txn_id,)).fetchone()
        if not row:
            raise ValidationError("Transaction not found.")
        if row["type"] == "BOX_OUT":
            raise ValidationError("An opening entry cannot be voided. Correct it instead, or return the box.")
        cur = self.conn.cursor()
        try:
            cur.execute("UPDATE transactions SET voided=1 WHERE id=?", (row["id"],))
            self._audit(cur, txn_id, row["box_id"], "VOID", f"{row['weight']:.3f} g", "VOIDED", reason)
            self.conn.commit()
        except Exception:
            self.conn.rollback()
            raise

    # ---------- queries ----------
    def active_boxes(self, d=None):
        d = d or today_str()
        rows = self.conn.execute(
            "SELECT b.*, c.name AS category, s.name AS salesperson FROM boxes b "
            "JOIN box_categories c ON c.id=b.category_id JOIN salespersons s ON s.id=b.salesperson_id "
            "WHERE b.date=? AND b.status='ACTIVE' ORDER BY b.id", (d,)).fetchall()
        out = []
        for r in rows:
            s = self.box_summary(r["box_id"])
            out.append(s)
        return out

    def boxes_for_date(self, d):
        rows = self.conn.execute(
            "SELECT b.*, c.name AS category, s.name AS salesperson FROM boxes b "
            "JOIN box_categories c ON c.id=b.category_id JOIN salespersons s ON s.id=b.salesperson_id "
            "WHERE b.date=? ORDER BY b.id", (d,)).fetchall()
        return [self.box_summary(r["box_id"]) for r in rows]

    def daily_transactions(self, d, category=None, salesperson=None, txn_type=None, box_search=None, metal=None):
        q = ("SELECT t.*, b.box_id AS box_code, b.metal AS metal, c.name AS category, s.name AS salesperson FROM transactions t "
             "JOIN boxes b ON b.id=t.box_id JOIN box_categories c ON c.id=b.category_id "
             "JOIN salespersons s ON s.id=b.salesperson_id WHERE t.date=? AND t.voided=0")
        params = [d]
        if category:
            q += " AND c.name=?"; params.append(category)
        if salesperson:
            q += " AND s.name=?"; params.append(salesperson)
        if txn_type:
            q += " AND t.type=?"; params.append(txn_type)
        if box_search:
            q += " AND b.box_id LIKE ?"; params.append(f"%{box_search}%")
        if metal:
            q += " AND b.metal=?"; params.append(metal)
        q += " ORDER BY t.id"
        return [dict(r) for r in self.conn.execute(q, params).fetchall()]

    def box_history(self, box_id_str):
        box = self.get_box(box_id_str)
        if not box:
            return []
        rows = self.conn.execute("SELECT * FROM transactions WHERE box_id=? ORDER BY id", (box["id"],)).fetchall()
        return [dict(r) for r in rows]

    def daily_totals(self, d):
        boxes = self.boxes_for_date(d)
        opening = round(sum(b["opening_weight"] for b in boxes), 4)
        sold = round(sum(b["sold"] for b in boxes), 4)
        added = round(sum(b["added"] for b in boxes), 4)
        returned = round(sum(b["returned_weight"] or 0 for b in boxes if b["status"] == "CLOSED"), 4)
        remaining = round(sum(b["expected_remaining"] for b in boxes if b["status"] == "ACTIVE"), 4)
        sale_amount = self.conn.execute(
            "SELECT COALESCE(SUM(amount),0) s FROM transactions WHERE date=? AND type='SALE' AND voided=0", (d,)).fetchone()["s"]
        # For closed boxes the stock is back in stock; remaining-on-counter = active only.
        return {
            "boxes": len(boxes), "active": sum(1 for b in boxes if b["status"] == "ACTIVE"),
            "returned_count": sum(1 for b in boxes if b["status"] == "CLOSED"),
            "opening": opening, "sold": sold, "added": added,
            "returned": returned, "remaining": remaining,
            "sale_amount": round(sale_amount, 2),
        }

    def payment_mode_totals(self, d):
        """Payment-mode totals for one day (v1.39, Excel report):
        how much of the day's sale amount came in as CASH, UPI,
        CARD, etc. Split sales are broken down by their actual
        splits (a CASH 60000 + UPI 40000 sale adds 60000 to CASH
        and 40000 to UPI), never double-counted, so the sum of
        all mode amounts always equals daily_totals sale_amount.
        A sale with no splits and a combined mode string (legacy
        data) is kept under that combined label, so nothing is
        lost. Voided sales are excluded (daily_transactions
        already filters voided=0). Returns a list of
        {"mode": ..., "amount": ...} in the shop's payment-mode
        order, with any other labels alphabetical after."""
        # Mirrors app.PAYMENT_MODES (db.py cannot import app.py).
        order = ["CASH", "UPI", "CARD", "BANK TRANSFER", "CREDIT / UDHAAR", "CHEQUE", "OTHER"]
        totals = {}
        for sale in self.daily_transactions(d, txn_type="SALE"):
            splits = self.get_splits(sale["txn_id"])
            if splits:
                for sp in splits:
                    totals[sp["mode"]] = round(totals.get(sp["mode"], 0) + (sp["amount"] or 0), 2)
            else:
                mode = (sale.get("payment_mode") or "").strip() or "UNSPECIFIED"
                totals[mode] = round(totals.get(mode, 0) + (sale.get("amount") or 0), 2)
        def _key(item):
            mode = item[0]
            return (0, order.index(mode)) if mode in order else (1, mode)
        return [{"mode": m, "amount": round(a, 2)} for m, a in sorted(totals.items(), key=_key)]

    def category_totals(self, d):
        rows = self.conn.execute(
            "SELECT c.name AS category, COUNT(DISTINCT b.id) boxes, "
            "COALESCE(SUM(CASE WHEN t.type='SALE' AND t.voided=0 THEN t.weight END),0) sold, "
            "COALESCE(SUM(CASE WHEN t.type='ADD_STOCK' AND t.voided=0 THEN t.weight END),0) added "
            "FROM boxes b JOIN box_categories c ON c.id=b.category_id "
            "LEFT JOIN transactions t ON t.box_id=b.id WHERE b.date=? GROUP BY c.name ORDER BY c.name", (d,)).fetchall()
        out = []
        for r in rows:
            opening = self.conn.execute("SELECT COALESCE(SUM(opening_weight),0) s FROM boxes b JOIN box_categories c ON c.id=b.category_id WHERE b.date=? AND c.name=?",
                                        (d, r["category"])).fetchone()["s"]
            out.append({"category": r["category"], "boxes": r["boxes"], "opening": round(opening, 3),
                        "sold": round(r["sold"], 3), "added": round(r["added"], 3),
                        "remaining": round(opening + r["added"] - r["sold"], 3)})
        return out

    def metal_totals(self, d):
        out = []
        for metal in ("GOLD", "SILVER"):
            boxes = [b for b in self.boxes_for_date(d) if (b.get("metal") or "") == metal]
            if not boxes:
                continue
            opening = round(sum(b["opening_weight"] for b in boxes), 4)
            sold = round(sum(b["sold"] for b in boxes), 4)
            added = round(sum(b["added"] for b in boxes), 4)
            out.append({"metal": metal, "boxes": len(boxes), "opening": opening, "sold": sold,
                        "added": added, "remaining": round(opening + added - sold, 3)})
        return out

    def salesperson_report(self, d):
        rows = self.conn.execute(
            "SELECT s.name AS salesperson, COUNT(DISTINCT b.id) boxes, "
            "COALESCE(SUM(b.opening_weight),0) opening FROM boxes b "
            "JOIN salespersons s ON s.id=b.salesperson_id WHERE b.date=? GROUP BY s.name ORDER BY s.name", (d,)).fetchall()
        out = []
        for r in rows:
            sold = self.conn.execute("SELECT COALESCE(SUM(t.weight),0) s FROM transactions t JOIN boxes b ON b.id=t.box_id JOIN salespersons s ON s.id=b.salesperson_id WHERE b.date=? AND s.name=? AND t.type='SALE' AND t.voided=0", (d, r["salesperson"])).fetchone()["s"]
            added = self.conn.execute("SELECT COALESCE(SUM(t.weight),0) s FROM transactions t JOIN boxes b ON b.id=t.box_id JOIN salespersons s ON s.id=b.salesperson_id WHERE b.date=? AND s.name=? AND t.type='ADD_STOCK' AND t.voided=0", (d, r["salesperson"])).fetchone()["s"]
            ret = self.conn.execute("SELECT COUNT(*) c, COALESCE(SUM(returned_weight),0) s FROM boxes b JOIN salespersons s ON s.id=b.salesperson_id WHERE b.date=? AND s.name=? AND b.status='CLOSED'", (d, r["salesperson"])).fetchone()
            active = self.conn.execute("SELECT COUNT(*) c FROM boxes b JOIN salespersons s ON s.id=b.salesperson_id WHERE b.date=? AND s.name=? AND b.status='ACTIVE'", (d, r["salesperson"])).fetchone()["c"]
            cats = self.conn.execute("SELECT DISTINCT c.name FROM boxes b JOIN box_categories c ON c.id=b.category_id JOIN salespersons s ON s.id=b.salesperson_id WHERE b.date=? AND s.name=?", (d, r["salesperson"])).fetchall()
            out.append({"salesperson": r["salesperson"], "boxes": r["boxes"], "categories": ", ".join(x["name"] for x in cats),
                        "opening": round(r["opening"], 3), "sold": round(sold, 3), "added": round(added, 3),
                        "returned": round(ret["s"], 3), "returned_count": ret["c"], "active": active,
                        "remaining": round(r["opening"] + added - sold, 3)})
        return out

    def audit_for_box(self, box_id_str):
        box = self.get_box(box_id_str)
        if not box:
            return []
        return [dict(r) for r in self.conn.execute("SELECT * FROM audit_logs WHERE box_id=? ORDER BY id", (box["id"],)).fetchall()]

    def backup(self):
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        dest = os.path.join(self.paths["backups"], f"weighing_scale_{stamp}.db")
        self.conn.commit()
        shutil.copy2(self.db_path, dest)
        # also copy WAL if present
        return dest

    def reset_day(self, d):
        """Delete EVERY entry for one day: all boxes of that date, their
        transactions and audit rows. Other days are untouched. Returns
        (boxes_deleted, txns_deleted). The caller deletes the day's Excel
        file and clears its pending queue; it must make a safety backup
        BEFORE calling this, and must check the Excel file is not locked
        first, so a reset is never half-done."""
        cur = self.conn.cursor()
        box_ids = [r["id"] for r in self.conn.execute("SELECT id FROM boxes WHERE date=?", (d,)).fetchall()]
        txn_count = self.conn.execute("SELECT COUNT(*) c FROM transactions WHERE date=?", (d,)).fetchone()["c"]
        if box_ids:
            ph = ",".join("?" * len(box_ids))
            cur.execute(f"DELETE FROM audit_logs WHERE box_id IN ({ph})", box_ids)
            cur.execute(f"DELETE FROM transactions WHERE box_id IN ({ph})", box_ids)
        cur.execute("DELETE FROM transactions WHERE date=?", (d,))
        cur.execute("DELETE FROM boxes WHERE date=?", (d,))
        self.conn.commit()
        return len(box_ids), txn_count

    def close(self):
        try:
            self.conn.commit()
            self.conn.close()
        except Exception:
            pass
