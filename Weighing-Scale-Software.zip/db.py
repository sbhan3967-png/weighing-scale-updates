"""Weighing Scale - SQLite data layer. Database is the source of truth.
Excel is always regenerated from this database, never the other way round.
All weights are stored as REAL grams, displayed to 2 decimals.
Dates are stored YYYY-MM-DD, display format DD-MM-YYYY is applied in UI/Excel.
"""
import os, sqlite3, shutil
from datetime import datetime, date

DEFAULT_CATEGORIES = [
    "LADIES RING", "GENTS RING", "LADIES CHAIN", "GENTS CHAIN",
    "NECKLACE", "EARRINGS", "BANGLES", "BRACELET", "PENDANT",
    "PAYAL", "NOSE PIN", "MANGALSUTRA", "OTHER",
]

class ValidationError(Exception):
    pass

class OverWeightError(Exception):
    """Sold weight exceeds remaining weight."""
    def __init__(self, remaining, requested):
        self.remaining = remaining
        self.requested = requested
        super().__init__(f"Sold weight {requested:.2f} g exceeds remaining {remaining:.2f} g")

def fmt_date(d):
    """YYYY-MM-DD -> DD-MM-YYYY"""
    if not d:
        return ""
    try:
        return datetime.strptime(d, "%Y-%m-%d").strftime("%d-%m-%Y")
    except Exception:
        return d

def today_str():
    return date.today().isoformat()

def default_base_dir():
    # Windows: Documents\Weighing Scale ; elsewhere: ~/Weighing Scale
    docs = os.path.join(os.path.expanduser("~"), "Documents")
    if os.path.isdir(docs):
        return os.path.join(docs, "Weighing Scale")
    return os.path.join(os.path.expanduser("~"), "Weighing Scale")

def paths_for(base_dir):
    return {
        "base": base_dir,
        "db_dir": os.path.join(base_dir, "Database"),
        "db": os.path.join(base_dir, "Database", "weighing_scale.db"),
        "reports": os.path.join(base_dir, "Daily Reports"),
        "backups": os.path.join(base_dir, "Backups", "Database Backups"),
        "pending": os.path.join(base_dir, "pending_excel.json"),
    }

def ensure_dirs(base_dir):
    p = paths_for(base_dir)
    for k in ("db_dir", "reports", "backups"):
        os.makedirs(p[k], exist_ok=True)
    return p

SCHEMA = """
CREATE TABLE IF NOT EXISTS box_categories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    is_active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS salespersons (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    is_active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS boxes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    box_id TEXT NOT NULL UNIQUE,
    date TEXT NOT NULL,
    category_id INTEGER NOT NULL REFERENCES box_categories(id),
    salesperson_id INTEGER NOT NULL REFERENCES salespersons(id),
    opening_weight REAL NOT NULL,
    metal TEXT DEFAULT '',
    status TEXT NOT NULL DEFAULT 'ACTIVE',
    returned_weight REAL,
    difference REAL,
    return_remarks TEXT DEFAULT '',
    created_at TEXT NOT NULL,
    closed_at TEXT
);
CREATE TABLE IF NOT EXISTS transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    txn_id TEXT NOT NULL UNIQUE,
    box_id INTEGER NOT NULL REFERENCES boxes(id),
    date TEXT NOT NULL,
    type TEXT NOT NULL,
    weight REAL NOT NULL,
    remarks TEXT DEFAULT '',
    created_at TEXT NOT NULL,
    voided INTEGER NOT NULL DEFAULT 0,
    payment_mode TEXT DEFAULT '',
    amount REAL,
    bill_no TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS audit_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    txn_id TEXT,
    box_id INTEGER,
    action TEXT NOT NULL,
    old_value TEXT DEFAULT '',
    new_value TEXT DEFAULT '',
    reason TEXT DEFAULT '',
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS application_settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_boxes_date ON boxes(date);
CREATE INDEX IF NOT EXISTS idx_boxes_status ON boxes(status);
CREATE INDEX IF NOT EXISTS idx_txn_date ON transactions(date);
CREATE INDEX IF NOT EXISTS idx_txn_box ON transactions(box_id);
"""

class Database:
    def __init__(self, base_dir=None):
        self.base_dir = base_dir or default_base_dir()
        self.paths = ensure_dirs(self.base_dir)
        self.db_path = self.paths["db"]
        self.conn = sqlite3.connect(self.db_path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA foreign_keys = ON")
        self.conn.execute("PRAGMA journal_mode = WAL")
        self.conn.executescript(SCHEMA)
        # Migration for databases created before v1.3 (sale payment fields).
        # Existing rows keep working; the new columns simply start empty.
        _bcols = [r[1] for r in self.conn.execute("PRAGMA table_info(boxes)").fetchall()]
        if "metal" not in _bcols:
            self.conn.execute("ALTER TABLE boxes ADD COLUMN metal TEXT DEFAULT ''")
        _cols = [r[1] for r in self.conn.execute("PRAGMA table_info(transactions)").fetchall()]
        for _col, _ddl in (("payment_mode", "TEXT DEFAULT ''"), ("amount", "REAL"), ("bill_no", "TEXT DEFAULT ''")):
            if _col not in _cols:
                self.conn.execute(f"ALTER TABLE transactions ADD COLUMN {_col} {_ddl}")
        self.conn.commit()
        self._seed()

    # ---------- helpers ----------
    def _now(self):
        return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    def _seed(self):
        cur = self.conn.cursor()
        now = self._now()
        for name in DEFAULT_CATEGORIES:
            cur.execute("INSERT OR IGNORE INTO box_categories (name, is_active, created_at) VALUES (?,?,?)",
                        (name, 1, now))
        defaults = {
            "showroom_name": "RAMANAND JEWELLERS",
            "weight_unit": "Grams",
            "date_format": "DD-MM-YYYY",
            "time_format": "12-hour",
            "auto_backup": "1",
        }
        for k, v in defaults.items():
            cur.execute("INSERT OR IGNORE INTO application_settings (key, value) VALUES (?,?)", (k, v))
        self.conn.commit()

    def get_setting(self, key, default=""):
        row = self.conn.execute("SELECT value FROM application_settings WHERE key=?", (key,)).fetchone()
        return row["value"] if row else default

    def set_setting(self, key, value):
        self.conn.execute("INSERT INTO application_settings (key, value) VALUES (?,?) "
                          "ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, str(value)))
        self.conn.commit()

    def _audit(self, cur, txn_id, box_id, action, old, new, reason=""):
        cur.execute("INSERT INTO audit_logs (txn_id, box_id, action, old_value, new_value, reason, created_at) "
                    "VALUES (?,?,?,?,?,?,?)", (txn_id, box_id, action, str(old), str(new), reason, self._now()))

    def _next_txn_id(self, cur):
        n = cur.execute("SELECT COUNT(*) c FROM transactions").fetchone()["c"] + 1
        return f"TXN-{datetime.now().strftime('%Y%m%d')}-{n:05d}"

    # ---------- categories / salespersons ----------
    def categories(self, active_only=False):
        q = "SELECT * FROM box_categories"
        if active_only:
            q += " WHERE is_active=1"
        return [dict(r) for r in self.conn.execute(q + " ORDER BY name").fetchall()]

    def salespersons(self, active_only=False):
        q = "SELECT * FROM salespersons"
        if active_only:
            q += " WHERE is_active=1"
        return [dict(r) for r in self.conn.execute(q + " ORDER BY name").fetchall()]

    def add_category(self, name):
        name = (name or "").strip().upper()
        if not name:
            raise ValidationError("Category name is required.")
        try:
            self.conn.execute("INSERT INTO box_categories (name, is_active, created_at) VALUES (?,?,?)",
                              (name, 1, self._now()))
            self.conn.commit()
        except sqlite3.IntegrityError:
            raise ValidationError(f"Category '{name}' already exists.")

    def add_salesperson(self, name):
        name = (name or "").strip()
        if not name:
            raise ValidationError("Salesperson name is required.")
        try:
            self.conn.execute("INSERT INTO salespersons (name, is_active, created_at) VALUES (?,?,?)",
                              (name, 1, self._now()))
            self.conn.commit()
        except sqlite3.IntegrityError:
            raise ValidationError(f"Salesperson '{name}' already exists.")

    def rename_category(self, cat_id, new_name):
        new_name = (new_name or "").strip().upper()
        if not new_name:
            raise ValidationError("Category name is required.")
        self.conn.execute("UPDATE box_categories SET name=? WHERE id=?", (new_name, cat_id))
        self.conn.commit()

    def rename_salesperson(self, sp_id, new_name):
        new_name = (new_name or "").strip()
        if not new_name:
            raise ValidationError("Salesperson name is required.")
        self.conn.execute("UPDATE salespersons SET name=? WHERE id=?", (new_name, sp_id))
        self.conn.commit()

    def set_category_active(self, cat_id, active):
        self.conn.execute("UPDATE box_categories SET is_active=? WHERE id=?", (1 if active else 0, cat_id))
        self.conn.commit()

    def set_salesperson_active(self, sp_id, active):
        self.conn.execute("UPDATE salespersons SET is_active=? WHERE id=?", (1 if active else 0, sp_id))
        self.conn.commit()

    def delete_category(self, cat_id):
        used = self.conn.execute("SELECT COUNT(*) c FROM boxes WHERE category_id=?", (cat_id,)).fetchone()["c"]
        if used:
            raise ValidationError("Cannot delete a category that has been used in a box. Deactivate it instead.")
        self.conn.execute("DELETE FROM box_categories WHERE id=?", (cat_id,))
        self.conn.commit()

    def delete_salesperson(self, sp_id):
        used = self.conn.execute("SELECT COUNT(*) c FROM boxes WHERE salesperson_id=?", (sp_id,)).fetchone()["c"]
        if used:
            raise ValidationError("Cannot delete a salesperson who has handled a box. Deactivate them instead.")
        self.conn.execute("DELETE FROM salespersons WHERE id=?", (sp_id,))
        self.conn.commit()

    def _resolve_category(self, name):
        row = self.conn.execute("SELECT * FROM box_categories WHERE name=?", (name.strip().upper(),)).fetchone()
        if not row:
            raise ValidationError(f"Category '{name}' not found. Add it in Settings first.")
        if not row["is_active"]:
            raise ValidationError(f"Category '{name}' is deactivated.")
        return dict(row)

    def _resolve_salesperson(self, name):
        row = self.conn.execute("SELECT * FROM salespersons WHERE name=?", (name.strip(),)).fetchone()
        if not row:
            raise ValidationError(f"Salesperson '{name}' not found. Add them in Settings first.")
        if not row["is_active"]:
            raise ValidationError(f"Salesperson '{name}' is deactivated.")
        return dict(row)

    @staticmethod
    def _check_weight(w):
        try:
            v = float(w)
        except Exception:
            raise ValidationError("Weight must be a number.")
        if v <= 0:
            raise ValidationError("Weight must be greater than 0.")
        return round(v, 2)

    # ---------- boxes ----------
    def next_box_id(self, d=None):
        d = d or today_str()
        prefix = "BOX-" + d.replace("-", "")
        row = self.conn.execute("SELECT box_id FROM boxes WHERE date=? ORDER BY id DESC LIMIT 1", (d,)).fetchone()
        n = 1
        if row:
            try:
                n = int(row["box_id"].rsplit("-", 1)[-1]) + 1
            except Exception:
                n = 1
        return f"{prefix}-{n:03d}"

    def create_box(self, category_name, salesperson_name, opening_weight, d=None, metal=""):
        d = d or today_str()
        metal = (metal or "").strip().upper()
        if metal not in ("GOLD", "SILVER"):
            raise ValidationError("Please select the box metal: GOLD or SILVER.")
        opening = self._check_weight(opening_weight)
        cat = self._resolve_category(category_name)
        sp = self._resolve_salesperson(salesperson_name)
        box_id = self.next_box_id(d)
        cur = self.conn.cursor()
        try:
            cur.execute("INSERT INTO boxes (box_id, date, category_id, salesperson_id, opening_weight, metal, status, created_at) "
                        "VALUES (?,?,?,?,?,?,'ACTIVE',?)",
                        (box_id, d, cat["id"], sp["id"], opening, metal, self._now()))
            bid = cur.lastrowid
            txn = self._next_txn_id(cur)
            cur.execute("INSERT INTO transactions (txn_id, box_id, date, type, weight, remarks, created_at) "
                        "VALUES (?,?,?,'BOX_OUT',?,'Box taken out',?)",
                        (txn, bid, d, opening, self._now()))
            self._audit(cur, txn, bid, "BOX_OUT", "", f"{opening:.2f} g", "Box opened")
            self.conn.commit()
        except Exception:
            self.conn.rollback()
            raise
        return box_id

    def get_box(self, box_id_str):
        row = self.conn.execute(
            "SELECT b.*, c.name AS category, s.name AS salesperson FROM boxes b "
            "JOIN box_categories c ON c.id=b.category_id "
            "JOIN salespersons s ON s.id=b.salesperson_id WHERE b.box_id=?", (box_id_str,)).fetchone()
        return dict(row) if row else None

    def box_summary(self, box_id_str):
        box = self.get_box(box_id_str)
        if not box:
            raise ValidationError(f"Box {box_id_str} not found.")
        sold = self.conn.execute("SELECT COALESCE(SUM(weight),0) s FROM transactions WHERE box_id=? AND type='SALE' AND voided=0",
                                 (box["id"],)).fetchone()["s"]
        added = self.conn.execute("SELECT COALESCE(SUM(weight),0) s FROM transactions WHERE box_id=? AND type='ADD_STOCK' AND voided=0",
                                  (box["id"],)).fetchone()["s"]
        expected = round(box["opening_weight"] + added - sold, 2)
        sale_amount = self.conn.execute("SELECT COALESCE(SUM(amount),0) s FROM transactions WHERE box_id=? AND type='SALE' AND voided=0",
                                        (box["id"],)).fetchone()["s"]
        bill_rows = self.conn.execute("SELECT bill_no FROM transactions WHERE box_id=? AND type='SALE' AND voided=0 AND bill_no IS NOT NULL AND bill_no != '' ORDER BY id",
                                      (box["id"],)).fetchall()
        out = dict(box)
        out["sold"] = round(sold, 2)
        out["added"] = round(added, 2)
        out["expected_remaining"] = expected
        out["remaining"] = expected  # kept for validation/history; no longer a Dashboard column (v1.6)
        out["sale_amount"] = round(sale_amount, 2)
        out["bill_nos"] = ", ".join(r["bill_no"] for r in bill_rows)
        # "Return" for the Dashboard table: actual returned weight once closed, blank while active
        out["return_weight"] = box["returned_weight"]
        return out

    def latest_sale(self, box_id_str):
        box = self.get_box(box_id_str)
        if not box:
            return None
        row = self.conn.execute("SELECT * FROM transactions WHERE box_id=? AND type='SALE' AND voided=0 ORDER BY id DESC LIMIT 1",
                                (box["id"],)).fetchone()
        return dict(row) if row else None

    def update_latest_sale(self, box_id_str, amount=None, bill_no=None):
        """Manual cell edit: set Amount and/or Bill No. on the box's latest
        sale. Used by Dashboard inline editing (Sell Amount / Bill No.
        columns). Raises ValidationError if there is no sale yet."""
        sale = self.latest_sale(box_id_str)
        if not sale:
            raise ValidationError("No sale yet for this box — enter a Sold weight first, then Amount / Bill No.")
        sets, params = [], []
        if amount is not None:
            amt = self._check_amount(amount)
            sets.append("amount=?"); params.append(amt)
        if bill_no is not None:
            sets.append("bill_no=?"); params.append(str(bill_no).strip())
        if not sets:
            return sale["txn_id"]
        params.append(sale["id"])
        cur = self.conn.cursor()
        cur.execute(f"UPDATE transactions SET {', '.join(sets)} WHERE id=?", params)
        self._audit(cur, sale["txn_id"], sale["box_id"], "MANUAL_EDIT", "",
                    f"Amount={amount} Bill={bill_no}", "Dashboard cell edit")
        self.conn.commit()
        return sale["txn_id"]

    def _add_txn(self, box, txn_type, weight, remarks, override_reason="", payment_mode="", amount=None, bill_no=""):
        cur = self.conn.cursor()
        try:
            txn = self._next_txn_id(cur)
            cur.execute("INSERT INTO transactions (txn_id, box_id, date, type, weight, remarks, created_at, payment_mode, amount, bill_no) "
                        "VALUES (?,?,?, ?,?,?,?, ?,?,?)",
                        (txn, box["id"], box["date"], txn_type, weight, remarks, self._now(),
                         payment_mode or "", amount, bill_no or ""))
            self._audit(cur, txn, box["id"], txn_type, "", f"{weight:.2f} g", override_reason or remarks)
            self.conn.commit()
            return txn
        except Exception:
            self.conn.rollback()
            raise

    @staticmethod
    def _check_amount(amount):
        """Amount (Rs) is optional; if given it must be a number >= 0."""
        if amount is None or (isinstance(amount, str) and not amount.strip()):
            return None
        try:
            v = float(amount)
        except Exception:
            raise ValidationError("Amount must be a number (Rs).")
        if v < 0:
            raise ValidationError("Amount cannot be negative.")
        return round(v, 2)

    def add_sale(self, box_id_str, weight, remarks="", override=False, override_reason="",
                 payment_mode="", amount=None, bill_no=""):
        w = self._check_weight(weight)
        amt = self._check_amount(amount)
        box = self.box_summary(box_id_str)
        if box["status"] != "ACTIVE":
            raise ValidationError("This box is already returned / closed. It cannot take new sales.")
        if w > box["remaining"] and not override:
            raise OverWeightError(box["remaining"], w)
        if w > box["remaining"] and not (override_reason or "").strip():
            raise ValidationError("An override reason is required when sold weight exceeds remaining weight.")
        return self._add_txn(box, "SALE", w, remarks, override_reason,
                             payment_mode=payment_mode, amount=amt, bill_no=bill_no)

    def add_stock(self, box_id_str, weight, remarks=""):
        w = self._check_weight(weight)
        box = self.box_summary(box_id_str)
        if box["status"] != "ACTIVE":
            raise ValidationError("This box is already returned / closed.")
        return self._add_txn(box, "ADD_STOCK", w, remarks)

    def return_box(self, box_id_str, actual_weight, remarks=""):
        actual = self._check_weight(actual_weight)
        box = self.box_summary(box_id_str)
        if box["status"] != "ACTIVE":
            raise ValidationError("This box is already returned.")
        expected = box["expected_remaining"]
        diff = round(actual - expected, 2)
        if abs(diff) >= 0.01 and not (remarks or "").strip():
            raise ValidationError("Weight difference found. Please enter an explanation in Remarks before returning.")
        cur = self.conn.cursor()
        try:
            txn = self._next_txn_id(cur)
            cur.execute("INSERT INTO transactions (txn_id, box_id, date, type, weight, remarks, created_at) "
                        "VALUES (?,?,?,'RETURN',?,?,?)",
                        (txn, box["id"], box["date"], actual, remarks, self._now()))
            cur.execute("UPDATE boxes SET status='CLOSED', returned_weight=?, difference=?, return_remarks=?, closed_at=? WHERE id=?",
                        (actual, diff, remarks, self._now(), box["id"]))
            self._audit(cur, txn, box["id"], "RETURN", f"Expected {expected:.2f} g", f"Returned {actual:.2f} g, diff {diff:+.2f} g", remarks)
            self.conn.commit()
        except Exception:
            self.conn.rollback()
            raise
        return {"expected": expected, "actual": actual, "difference": diff}

    def correct_transaction(self, txn_id, new_weight, reason):
        if not (reason or "").strip():
            raise ValidationError("A reason is required for every correction (audit trail).")
        w = self._check_weight(new_weight)
        row = self.conn.execute("SELECT * FROM transactions WHERE txn_id=?", (txn_id,)).fetchone()
        if not row:
            raise ValidationError("Transaction not found.")
        if row["voided"]:
            raise ValidationError("This transaction is already voided.")
        if row["type"] not in ("SALE", "ADD_STOCK", "BOX_OUT"):
            raise ValidationError("Only sale, stock and opening entries can be corrected.")
        cur = self.conn.cursor()
        try:
            old = row["weight"]
            cur.execute("UPDATE transactions SET weight=? WHERE id=?", (w, row["id"]))
            if row["type"] == "BOX_OUT":
                cur.execute("UPDATE boxes SET opening_weight=? WHERE id=?", (w, row["box_id"]))
            # recompute difference for a closed box
            box = self.conn.execute("SELECT * FROM boxes WHERE id=?", (row["box_id"],)).fetchone()
            if box and box["status"] == "CLOSED" and box["returned_weight"] is not None:
                s = self.conn.execute("SELECT COALESCE(SUM(weight),0) s FROM transactions WHERE box_id=? AND type='SALE' AND voided=0", (box["id"],)).fetchone()["s"]
                a = self.conn.execute("SELECT COALESCE(SUM(weight),0) s FROM transactions WHERE box_id=? AND type='ADD_STOCK' AND voided=0", (box["id"],)).fetchone()["s"]
                opening = w if row["type"] == "BOX_OUT" else box["opening_weight"]
                expected = round(opening + a - s, 2)
                cur.execute("UPDATE boxes SET difference=? WHERE id=?", (round(box["returned_weight"] - expected, 2), box["id"]))
            self._audit(cur, txn_id, row["box_id"], "CORRECTION", f"{old:.2f} g", f"{w:.2f} g", reason)
            self.conn.commit()
        except Exception:
            self.conn.rollback()
            raise

    def void_transaction(self, txn_id, reason):
        if not (reason or "").strip():
            raise ValidationError("A reason is required to void an entry (audit trail).")
        row = self.conn.execute("SELECT * FROM transactions WHERE txn_id=?", (txn_id,)).fetchone()
        if not row:
            raise ValidationError("Transaction not found.")
        if row["type"] == "BOX_OUT":
            raise ValidationError("An opening entry cannot be voided. Correct it instead, or return the box.")
        cur = self.conn.cursor()
        try:
            cur.execute("UPDATE transactions SET voided=1 WHERE id=?", (row["id"],))
            self._audit(cur, txn_id, row["box_id"], "VOID", f"{row['weight']:.2f} g", "VOIDED", reason)
            self.conn.commit()
        except Exception:
            self.conn.rollback()
            raise

    # ---------- queries ----------
    def active_boxes(self, d=None):
        d = d or today_str()
        rows = self.conn.execute(
            "SELECT b.*, c.name AS category, s.name AS salesperson FROM boxes b "
            "JOIN box_categories c ON c.id=b.category_id JOIN salespersons s ON s.id=b.salesperson_id "
            "WHERE b.date=? AND b.status='ACTIVE' ORDER BY b.id", (d,)).fetchall()
        out = []
        for r in rows:
            s = self.box_summary(r["box_id"])
            out.append(s)
        return out

    def boxes_for_date(self, d):
        rows = self.conn.execute(
            "SELECT b.*, c.name AS category, s.name AS salesperson FROM boxes b "
            "JOIN box_categories c ON c.id=b.category_id JOIN salespersons s ON s.id=b.salesperson_id "
            "WHERE b.date=? ORDER BY b.id", (d,)).fetchall()
        return [self.box_summary(r["box_id"]) for r in rows]

    def daily_transactions(self, d, category=None, salesperson=None, txn_type=None, box_search=None, metal=None):
        q = ("SELECT t.*, b.box_id AS box_code, b.metal AS metal, c.name AS category, s.name AS salesperson FROM transactions t "
             "JOIN boxes b ON b.id=t.box_id JOIN box_categories c ON c.id=b.category_id "
             "JOIN salespersons s ON s.id=b.salesperson_id WHERE t.date=? AND t.voided=0")
        params = [d]
        if category:
            q += " AND c.name=?"; params.append(category)
        if salesperson:
            q += " AND s.name=?"; params.append(salesperson)
        if txn_type:
            q += " AND t.type=?"; params.append(txn_type)
        if box_search:
            q += " AND b.box_id LIKE ?"; params.append(f"%{box_search}%")
        if metal:
            q += " AND b.metal=?"; params.append(metal)
        q += " ORDER BY t.id"
        return [dict(r) for r in self.conn.execute(q, params).fetchall()]

    def box_history(self, box_id_str):
        box = self.get_box(box_id_str)
        if not box:
            return []
        rows = self.conn.execute("SELECT * FROM transactions WHERE box_id=? ORDER BY id", (box["id"],)).fetchall()
        return [dict(r) for r in rows]

    def daily_totals(self, d):
        boxes = self.boxes_for_date(d)
        opening = round(sum(b["opening_weight"] for b in boxes), 2)
        sold = round(sum(b["sold"] for b in boxes), 2)
        added = round(sum(b["added"] for b in boxes), 2)
        returned = round(sum(b["returned_weight"] or 0 for b in boxes if b["status"] == "CLOSED"), 2)
        remaining = round(sum(b["expected_remaining"] for b in boxes if b["status"] == "ACTIVE"), 2)
        sale_amount = self.conn.execute(
            "SELECT COALESCE(SUM(amount),0) s FROM transactions WHERE date=? AND type='SALE' AND voided=0", (d,)).fetchone()["s"]
        # For closed boxes the stock is back in stock; remaining-on-counter = active only.
        return {
            "boxes": len(boxes), "active": sum(1 for b in boxes if b["status"] == "ACTIVE"),
            "returned_count": sum(1 for b in boxes if b["status"] == "CLOSED"),
            "opening": opening, "sold": sold, "added": added,
            "returned": returned, "remaining": remaining,
            "sale_amount": round(sale_amount, 2),
        }

    def category_totals(self, d):
        rows = self.conn.execute(
            "SELECT c.name AS category, COUNT(DISTINCT b.id) boxes, "
            "COALESCE(SUM(CASE WHEN t.type='SALE' AND t.voided=0 THEN t.weight END),0) sold, "
            "COALESCE(SUM(CASE WHEN t.type='ADD_STOCK' AND t.voided=0 THEN t.weight END),0) added "
            "FROM boxes b JOIN box_categories c ON c.id=b.category_id "
            "LEFT JOIN transactions t ON t.box_id=b.id WHERE b.date=? GROUP BY c.name ORDER BY c.name", (d,)).fetchall()
        out = []
        for r in rows:
            opening = self.conn.execute("SELECT COALESCE(SUM(opening_weight),0) s FROM boxes b JOIN box_categories c ON c.id=b.category_id WHERE b.date=? AND c.name=?",
                                        (d, r["category"])).fetchone()["s"]
            out.append({"category": r["category"], "boxes": r["boxes"], "opening": round(opening, 2),
                        "sold": round(r["sold"], 2), "added": round(r["added"], 2),
                        "remaining": round(opening + r["added"] - r["sold"], 2)})
        return out

    def metal_totals(self, d):
        out = []
        for metal in ("GOLD", "SILVER"):
            boxes = [b for b in self.boxes_for_date(d) if (b.get("metal") or "") == metal]
            if not boxes:
                continue
            opening = round(sum(b["opening_weight"] for b in boxes), 2)
            sold = round(sum(b["sold"] for b in boxes), 2)
            added = round(sum(b["added"] for b in boxes), 2)
            out.append({"metal": metal, "boxes": len(boxes), "opening": opening, "sold": sold,
                        "added": added, "remaining": round(opening + added - sold, 2)})
        return out

    def salesperson_report(self, d):
        rows = self.conn.execute(
            "SELECT s.name AS salesperson, COUNT(DISTINCT b.id) boxes, "
            "COALESCE(SUM(b.opening_weight),0) opening FROM boxes b "
            "JOIN salespersons s ON s.id=b.salesperson_id WHERE b.date=? GROUP BY s.name ORDER BY s.name", (d,)).fetchall()
        out = []
        for r in rows:
            sold = self.conn.execute("SELECT COALESCE(SUM(t.weight),0) s FROM transactions t JOIN boxes b ON b.id=t.box_id JOIN salespersons s ON s.id=b.salesperson_id WHERE b.date=? AND s.name=? AND t.type='SALE' AND t.voided=0", (d, r["salesperson"])).fetchone()["s"]
            added = self.conn.execute("SELECT COALESCE(SUM(t.weight),0) s FROM transactions t JOIN boxes b ON b.id=t.box_id JOIN salespersons s ON s.id=b.salesperson_id WHERE b.date=? AND s.name=? AND t.type='ADD_STOCK' AND t.voided=0", (d, r["salesperson"])).fetchone()["s"]
            ret = self.conn.execute("SELECT COUNT(*) c, COALESCE(SUM(returned_weight),0) s FROM boxes b JOIN salespersons s ON s.id=b.salesperson_id WHERE b.date=? AND s.name=? AND b.status='CLOSED'", (d, r["salesperson"])).fetchone()
            active = self.conn.execute("SELECT COUNT(*) c FROM boxes b JOIN salespersons s ON s.id=b.salesperson_id WHERE b.date=? AND s.name=? AND b.status='ACTIVE'", (d, r["salesperson"])).fetchone()["c"]
            cats = self.conn.execute("SELECT DISTINCT c.name FROM boxes b JOIN box_categories c ON c.id=b.category_id JOIN salespersons s ON s.id=b.salesperson_id WHERE b.date=? AND s.name=?", (d, r["salesperson"])).fetchall()
            out.append({"salesperson": r["salesperson"], "boxes": r["boxes"], "categories": ", ".join(x["name"] for x in cats),
                        "opening": round(r["opening"], 2), "sold": round(sold, 2), "added": round(added, 2),
                        "returned": round(ret["s"], 2), "returned_count": ret["c"], "active": active,
                        "remaining": round(r["opening"] + added - sold, 2)})
        return out

    def audit_for_box(self, box_id_str):
        box = self.get_box(box_id_str)
        if not box:
            return []
        return [dict(r) for r in self.conn.execute("SELECT * FROM audit_logs WHERE box_id=? ORDER BY id", (box["id"],)).fetchall()]

    def backup(self):
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        dest = os.path.join(self.paths["backups"], f"weighing_scale_{stamp}.db")
        self.conn.commit()
        shutil.copy2(self.db_path, dest)
        # also copy WAL if present
        return dest

    def close(self):
        try:
            self.conn.commit()
            self.conn.close()
        except Exception:
            pass
