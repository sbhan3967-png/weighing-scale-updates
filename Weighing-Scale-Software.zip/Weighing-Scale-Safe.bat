@echo off
REM Safe start: runs the app with no auto-update check and no startup Excel
REM sync. Use this if the normal icon opens and closes in a second.
REM If it still fails, look for crash_log.txt in this folder and send it.
@echo off
REM Find the SAME Python the launcher uses (312, then 313, 314, 315),
REM so diagnostics / safe mode never run a different interpreter
REM than the desktop icon — e.g. a newly installed latest Python
REM that never had openpyxl installed by Setup.
cd /d "%~dp0"
set PY=
for %%P in (
    "%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
    "%LOCALAPPDATA%\Programs\Python\Python313\python.exe"
    "%LOCALAPPDATA%\Programs\Python\Python314\python.exe"
    "%LOCALAPPDATA%\Programs\Python\Python315\python.exe"
    "%ProgramFiles%\Python312\python.exe"
    "%ProgramFiles%\Python313\python.exe"
    "%ProgramFiles%\Python314\python.exe"
    "%ProgramFiles%\Python315\python.exe"
    "C:\Python312\python.exe"
    "C:\Python313\python.exe"
    "C:\Python314\python.exe"
    "C:\Python315\python.exe"
) do (
    if not defined PY if exist %%P set PY="%%P"
)
if not defined PY (
    py -3 --version >nul 2>nul
    if %errorlevel%==0 set PY=py -3
)
if not defined PY set PY=python
echo Using Python:
%PY% --version
%PY% app.py --safe
pause
