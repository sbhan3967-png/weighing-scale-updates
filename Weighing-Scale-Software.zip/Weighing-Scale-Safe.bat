@echo off
REM Safe start: runs the app with no auto-update check and no startup Excel
REM sync. Use this if the normal icon opens and closes in a second.
REM If it still fails, look for crash_log.txt in this folder and send it.
cd /d "%~dp0"
python app.py --safe
pause
