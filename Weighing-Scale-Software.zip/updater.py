"""Weighing Scale - GitHub auto-update channel.

How it works (same pattern as Parchi Reader):
1. On startup, in a background thread (never blocks the UI), the app fetches
   version.json from the public GitHub repo sbhan3967-png/weighing-scale-updates.
2. If version.json has a newer version than CURRENT_VERSION, the user is
   asked once: "New version X available. Update now?"
3. On Yes (Windows): the new zip is downloaded, a small apply_update.bat is
   written, the app exits, the batch file extracts the zip over the install
   folder (so no file is locked by the running app), then relaunches the app.
   No reinstall, no Setup re-run, no files to copy by hand.
   On other systems it extracts directly over the install folder.

To push an update (for Suraj):
1. Build the new Weighing-Scale-Software.zip.
2. Upload it to the weighing-scale-updates repo, replacing the old zip.
3. Edit version.json in the same repo: bump "version" and set "url" to the
   new zip's raw URL (or leave url out to use the default below).
Every PC with the app picks it up automatically on next launch.

If there is no internet, or the check fails, the app just runs normally
and tries again next launch. Nothing ever breaks because of an update.
An update never touches Documents\\Weighing Scale\\ — database, daily
Excel files and backups are outside the install folder and are untouched.
"""
import json
import os
import shutil
import subprocess
import sys
import tempfile
import urllib.request
import zipfile

CURRENT_VERSION = "1.30"
UPDATE_CHECK_URL = ("https://raw.githubusercontent.com/sbhan3967-png/"
                    "weighing-scale-updates/main/version.json")
UPDATE_ZIP_URL = ("https://raw.githubusercontent.com/sbhan3967-png/"
                  "weighing-scale-updates/main/Weighing-Scale-Software.zip")
TIMEOUT = 8


def _ver_tuple(v):
    out = []
    for part in str(v).split("."):
        digits = "".join(ch for ch in part if ch.isdigit())
        out.append(int(digits) if digits else 0)
    return tuple(out)


def check_for_update(current_version=CURRENT_VERSION):
    """Return (latest, url, notes) if an update exists, else None. Never raises."""
    try:
        req = urllib.request.Request(UPDATE_CHECK_URL, headers={"User-Agent": "WeighingScale"})
        with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
            info = json.loads(resp.read().decode("utf-8"))
        latest = str(info.get("version", "")).strip()
        if not latest or _ver_tuple(latest) <= _ver_tuple(current_version):
            return None
        return (latest, info.get("url") or UPDATE_ZIP_URL, info.get("notes", ""))
    except Exception:
        return None


def install_dir():
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))


def download_zip(download_url):
    tmpdir = tempfile.mkdtemp(prefix="weighing_update_")
    zippath = os.path.join(tmpdir, "update.zip")
    req = urllib.request.Request(download_url, headers={"User-Agent": "WeighingScale"})
    with urllib.request.urlopen(req, timeout=120) as resp, open(zippath, "wb") as f:
        shutil.copyfileobj(resp, f)
    with zipfile.ZipFile(zippath) as zf:
        for name in zf.namelist():
            target = os.path.normpath(os.path.join(install_dir(), name))
            if not target.startswith(os.path.normpath(install_dir()) + os.sep):
                raise ValueError(f"Unsafe path in update: {name}")
    return zippath


def apply_update(download_url):
    """Download + install the update. On Windows, hands over to a batch file
    after this process exits (avoids locked-file failures). Returns True.
    v1.8: the downloaded zip is validated BEFORE exiting. An invalid zip
    (e.g. an HTML error page from a stale CDN edge) used to make the app
    close itself and then fail to restart — the "opens then closes" loop.
    A bad zip now aborts with an error and the current app keeps running."""
    zippath = download_zip(download_url)
    # Validate: must be a real zip containing app.py, otherwise do not exit.
    try:
        with zipfile.ZipFile(zippath) as zf:
            if zf.testzip() is not None or "app.py" not in zf.namelist():
                raise ValueError("Downloaded update is not a valid Weighing Scale zip.")
    except Exception:
        try:
            shutil.rmtree(os.path.dirname(zippath), ignore_errors=True)
        except Exception:
            pass
        raise
    dest = install_dir()
    if sys.platform.startswith("win"):
        # Copy the zip into the install folder, then exit and let the batch
        # file do the extraction (the running .py files are then free).
        local_zip = os.path.join(dest, "update.zip")
        shutil.copy2(zippath, local_zip)
        bat = os.path.join(dest, "apply_update.bat")
        with open(bat, "w") as f:
            f.write("@echo off\r\n")
            f.write("timeout /t 2 /nobreak >nul\r\n")
            # v1.8: even if extraction fails, RESTART THE APP anyway, so the
            # user is never left with a closed app and nothing to open.
            # A failed extraction writes update_error.txt for diagnosis.
            ps_cmd = "powershell -NoProfile -ExecutionPolicy Bypass -Command Expand-Archive -Path '" + local_zip + "' -DestinationPath '" + dest + "' -Force"
            f.write(ps_cmd + "\r\n")
            f.write('if errorlevel 1 echo Update extraction failed > update_error.txt\r\n')
            f.write(f'del "{local_zip}" >nul 2>&1\r\n')
            f.write('start "" "Weighing-Scale.vbs"\r\n')
            f.write('del "%~f0" >nul 2>&1\r\n')
        subprocess.Popen([bat], cwd=dest, shell=True)
        os._exit(0)
    with zipfile.ZipFile(zippath) as zf:
        zf.extractall(dest)
    shutil.rmtree(os.path.dirname(zippath), ignore_errors=True)
    return True
