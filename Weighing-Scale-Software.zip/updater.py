"""Weighing Scale - GitHub auto-update channel.

How it works (same pattern as Parchi Reader):
1. On startup, in a background thread (never blocks the UI), the app fetches
   version.json from the public GitHub repo sbhan3967-png/weighing-scale-updates.
2. If version.json has a newer version than CURRENT_VERSION, the user is
   asked once: "New version X available. Update now?"
3. On Yes (Windows): the new zip is downloaded, a small apply_update.bat is
   written, the app exits, the batch file extracts the zip over the install
   folder (so no file is locked by the running app), then relaunches the app.
   No reinstall, no Setup re-run, no files to copy by hand.
   On other systems it extracts directly over the install folder.

To push an update (for Suraj):
1. Build the new Weighing-Scale-Software.zip.
2. Upload it to the weighing-scale-updates repo, replacing the old zip.
3. Edit version.json in the same repo: bump "version" and set "url" to the
   new zip's raw URL (or leave url out to use the default below).
Every PC with the app picks it up automatically on next launch.

If there is no internet, or the check fails, the app just runs normally
and tries again next launch. Nothing ever breaks because of an update.
An update never touches Documents\\Weighing Scale\\ — database, daily
Excel files and backups are outside the install folder and are untouched.
"""
import json
import os
import shutil
import subprocess
import sys
import tempfile
import urllib.request
import zipfile

CURRENT_VERSION = "1.44"
UPDATE_CHECK_URL = ("https://raw.githubusercontent.com/sbhan3967-png/"
                    "weighing-scale-updates/main/version.json")
# Fallback address for the same file (via github.com, which redirects
# to the raw host). If the raw host itself is blocked or slow on a
# PC, this second address sometimes still works.
UPDATE_CHECK_URL_FALLBACK = ("https://github.com/sbhan3967-png/"
                             "weighing-scale-updates/raw/main/version.json")
# Third address (v1.40): the same file via jsDelivr, a different
# CDN with its own cache. See _fetch_version_json below for why
# three addresses are needed, not just one plus a fallback.
UPDATE_CHECK_URL_JSDELIVR = ("https://cdn.jsdelivr.net/gh/sbhan3967-png/"
                             "weighing-scale-updates@main/version.json")
UPDATE_CHECK_URLS = (UPDATE_CHECK_URL, UPDATE_CHECK_URL_FALLBACK, UPDATE_CHECK_URL_JSDELIVR)
UPDATE_ZIP_URL = ("https://raw.githubusercontent.com/sbhan3967-png/"
                  "weighing-scale-updates/main/Weighing-Scale-Software.zip")
# v1.36: 8 seconds was too short on slow connections — a slow CDN
# reply timed out, and the old code then reported "Up to date".
# 20 seconds gives a slow connection time to answer.
TIMEOUT = 20


def _ver_tuple(v):
    out = []
    for part in str(v).split("."):
        digits = "".join(ch for ch in part if ch.isdigit())
        out.append(int(digits) if digits else 0)
    return tuple(out)


def _fetch_version_json():
    """Fetch version.json (v1.40, stale-cache fix). The old code
    stopped at the FIRST address that answered — so if GitHub's
    CDN served a stale copy (e.g. 1.38 when 1.39 was already
    live, as happened on 2026-11-02), the app reported "Up to
    date" and never tried the other addresses. Now it tries ALL
    three addresses (raw, github.com raw, jsDelivr — three
    different caches) and returns the NEWEST version any of
    them reports. Only if NONE of them answer is it an error.
    Returns (info, error_message): info is the parsed JSON
    with the newest version on success, error_message is a
    short human-readable reason on failure (None on success)."""
    best = None
    last_error = "unknown error"
    for url in UPDATE_CHECK_URLS:
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "WeighingScale"})
            with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
                info = json.loads(resp.read().decode("utf-8"))
            if best is None or _ver_tuple(str(info.get("version", "")).strip()) > _ver_tuple(str(best.get("version", "")).strip()):
                best = info
        except Exception as e:
            last_error = f"{type(e).__name__}: {e}"
    if best is not None:
        return (best, None)
    return (None, last_error)


def check_for_update_status(current_version=CURRENT_VERSION):
    """v1.36: like check_for_update, but tells the truth about
    failures. Returns (status, payload) where status is:
    - "update": payload is (latest, url, notes)
    - "up_to_date": payload is None (the server answered, and
      there really is no newer version)
    - "error": payload is a short error message (the server could
      NOT be reached at all — this is NOT "up to date").
    Never raises."""
    info, error = _fetch_version_json()
    if info is None:
        return ("error", error)
    latest = str(info.get("version", "")).strip()
    if not latest or _ver_tuple(latest) <= _ver_tuple(current_version):
        return ("up_to_date", None)
    return ("update", (latest, info.get("url") or UPDATE_ZIP_URL, info.get("notes", "")))


def write_update_error(error_message):
    """Save the last update-check failure to update_check_error.txt
    in the app folder, so the user can report the exact reason
    instead of guessing. Best effort — never raises."""
    try:
        import datetime as _dt
        path = os.path.join(install_dir(), "update_check_error.txt")
        with open(path, "w", encoding="utf-8") as f:
            f.write(f"Time: {_dt.datetime.now().isoformat()}\n")
            f.write(f"Current version: {CURRENT_VERSION}\n")
            f.write(f"Update URL: {UPDATE_CHECK_URL}\n")
            f.write(f"Error: {error_message}\n")
    except Exception:
        pass


def check_for_update(current_version=CURRENT_VERSION):
    """Return (latest, url, notes) if an update exists, else None. Never raises.
    Kept for the background startup check, which must stay silent:
    on a network error it returns None (no popup), exactly as before.
    The manual Backup-tab check now uses check_for_update_status
    instead, so a failure is shown as a failure, not as 'Up to date'."""
    status, payload = check_for_update_status(current_version)
    if status == "update":
        return payload
    return None


def install_dir():
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))


def download_zip(download_url):
    tmpdir = tempfile.mkdtemp(prefix="weighing_update_")
    zippath = os.path.join(tmpdir, "update.zip")
    req = urllib.request.Request(download_url, headers={"User-Agent": "WeighingScale"})
    with urllib.request.urlopen(req, timeout=120) as resp, open(zippath, "wb") as f:
        shutil.copyfileobj(resp, f)
    with zipfile.ZipFile(zippath) as zf:
        for name in zf.namelist():
            target = os.path.normpath(os.path.join(install_dir(), name))
            if not target.startswith(os.path.normpath(install_dir()) + os.sep):
                raise ValueError(f"Unsafe path in update: {name}")
    return zippath


def apply_update(download_url):
    """Download + install the update. On Windows, hands over to a batch file
    after this process exits (avoids locked-file failures). Returns True.
    v1.8: the downloaded zip is validated BEFORE exiting. An invalid zip
    (e.g. an HTML error page from a stale CDN edge) used to make the app
    close itself and then fail to restart — the "opens then closes" loop.
    A bad zip now aborts with an error and the current app keeps running."""
    zippath = download_zip(download_url)
    # Validate: must be a real zip containing app.py, otherwise do not exit.
    try:
        with zipfile.ZipFile(zippath) as zf:
            if zf.testzip() is not None or "app.py" not in zf.namelist():
                raise ValueError("Downloaded update is not a valid Weighing Scale zip.")
    except Exception:
        try:
            shutil.rmtree(os.path.dirname(zippath), ignore_errors=True)
        except Exception:
            pass
        raise
    dest = install_dir()
    if sys.platform.startswith("win"):
        # Copy the zip into the install folder, then exit and let the batch
        # file do the extraction (the running .py files are then free).
        local_zip = os.path.join(dest, "update.zip")
        shutil.copy2(zippath, local_zip)
        bat = os.path.join(dest, "apply_update.bat")
        with open(bat, "w") as f:
            f.write("@echo off\r\n")
            f.write("timeout /t 2 /nobreak >nul\r\n")
            # v1.8: even if extraction fails, RESTART THE APP anyway, so the
            # user is never left with a closed app and nothing to open.
            # A failed extraction writes update_error.txt for diagnosis.
            ps_cmd = "powershell -NoProfile -ExecutionPolicy Bypass -Command Expand-Archive -Path '" + local_zip + "' -DestinationPath '" + dest + "' -Force"
            f.write(ps_cmd + "\r\n")
            f.write('if errorlevel 1 echo Update extraction failed > update_error.txt\r\n')
            f.write(f'del "{local_zip}" >nul 2>&1\r\n')
            f.write('start "" "Weighing-Scale.vbs"\r\n')
            f.write('del "%~f0" >nul 2>&1\r\n')
        subprocess.Popen([bat], cwd=dest, shell=True)
        os._exit(0)
    with zipfile.ZipFile(zippath) as zf:
        zf.extractall(dest)
    shutil.rmtree(os.path.dirname(zippath), ignore_errors=True)
    return True
