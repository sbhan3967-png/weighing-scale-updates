' Weighing Scale - hidden launcher (no cmd window at all, not even a flash).
' The desktop shortcut points here. It runs Weighing-Scale.bat hidden,
' and that batch file starts the app with pythonw.exe (windowless Python)
' and then exits, so nothing console-related stays open.
Set WshShell = CreateObject("WScript.Shell")
Set FSO = CreateObject("Scripting.FileSystemObject")
Folder = FSO.GetParentFolderName(WScript.ScriptFullName)
WshShell.Run Chr(34) & Folder & "\Weighing-Scale.bat" & Chr(34), 0, False
