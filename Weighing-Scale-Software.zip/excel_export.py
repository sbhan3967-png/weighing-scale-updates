"""Daily Excel generation - regenerated from the SQLite database every time.
If the file is open/locked, the update is queued (pending_excel.json) and
no database transaction is lost. Call retry_pending() on next save/startup.
"""
import os, json
from datetime import datetime
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from db import fmt_date, paths_for

GOLD = "C9A227"
GOLD_LIGHT = "FFF2CC"
DARK = "333333"
THIN = Side(style="thin", color="D9D9D9")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)

def month_name(d):
    return datetime.strptime(d, "%Y-%m-%d").strftime("%B")

def excel_path_for(base_dir, d):
    y = d[:4]
    folder = os.path.join(paths_for(base_dir)["reports"], y, month_name(d))
    os.makedirs(folder, exist_ok=True)
    return os.path.join(folder, fmt_date(d) + ".xlsx")

def build_workbook(db, d):
    showroom = db.get_setting("showroom_name", "RAMANAND JEWELLERS")
    totals = db.daily_totals(d)
    txns = db.daily_transactions(d)
    boxes = db.boxes_for_date(d)
    wb = Workbook()
    ws = wb.active
    ws.title = "Daily Report"
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.page_setup.orientation = "landscape"
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0

    # Title block
    ws.merge_cells("A1:R1")
    c = ws["A1"]; c.value = showroom; c.font = Font(size=16, bold=True, color=DARK); c.alignment = Alignment(horizontal="center")
    ws.merge_cells("A2:R2")
    c = ws["A2"]; c.value = f"Daily Weighing Report  —  {fmt_date(d)}"; c.font = Font(size=12, bold=True, color="7A5C00"); c.alignment = Alignment(horizontal="center")
    ws.merge_cells("A3:R3")
    c = ws["A3"]; c.value = "G O L D  •  Weights in grams  •  Generated automatically from the database — do not edit by hand; edit in the software instead."
    c.font = Font(size=9, italic=True, color="666666"); c.alignment = Alignment(horizontal="center")

    headers = ["S.No.", "Box ID", "Date", "Category", "Metal", "Transaction Type", "Salesperson",
               "Opening Weight", "Sold Weight", "Additional Stock", "Returned Weight",
               "Remaining Weight", "Difference", "Mode of Trans.", "Amount (Rs)", "Bill No./Rokar/Book",
               "Transaction Time", "Remarks"]
    widths = [7, 18, 12, 16, 10, 17, 16, 15, 13, 16, 15, 15, 12, 15, 14, 20, 18, 26]
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w
    hr = 5
    for col, h in enumerate(headers, 1):
        cell = ws.cell(row=hr, column=col, value=h)
        cell.font = Font(bold=True, color="FFFFFF", size=10)
        cell.fill = PatternFill("solid", fgColor=GOLD)
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = BORDER
    ws.row_dimensions[hr].height = 30

    # Running remaining per box, in chronological order
    running = {}
    for box in boxes:
        running[box["box_id"]] = box["opening_weight"]
    r = hr + 1
    for i, t in enumerate(txns, 1):
        code = t["box_code"]
        box = next((b for b in boxes if b["box_id"] == code), None)
        opening = box["opening_weight"] if box else 0
        if t["type"] == "BOX_OUT":
            running[code] = t["weight"]
            rem = running[code]
        elif t["type"] == "SALE":
            running[code] = round(running.get(code, opening) - t["weight"], 4); rem = running[code]
        elif t["type"] == "ADD_STOCK":
            running[code] = round(running.get(code, opening) + t["weight"], 4); rem = running[code]
        elif t["type"] == "RETURN":
            rem = t["weight"]
        else:
            rem = running.get(code, opening)
        # v1.30: split sales show their breakdown in Remarks, so the
        # Excel layout (18 columns) does not change, but the split is
        # still visible: "Split: CASH Rs 60000.00 + UPI Rs 40000.00".
        _remarks = t["remarks"] or ""
        if t["type"] == "SALE":
            try:
                _splits = db.get_splits(t["txn_id"])
            except Exception:
                _splits = []
            if _splits:
                _remarks = (_remarks + " | " if _remarks else "") + "Split: " + " + ".join(f"{sp['mode']} Rs {sp['amount']:.2f}" for sp in _splits)
        vals = [i, code, fmt_date(t["date"]), t["category"], t.get("metal") or "", t["type"], t["salesperson"],
                opening if t["type"] == "BOX_OUT" else "",
                t["weight"] if t["type"] == "SALE" else "",
                t["weight"] if t["type"] == "ADD_STOCK" else "",
                t["weight"] if t["type"] == "RETURN" else "",
                rem,
                (box["difference"] if (box and t["type"] == "RETURN" and box["difference"] is not None) else ""),
                t.get("payment_mode") or "",
                t.get("amount") if t.get("amount") is not None else "",
                t.get("bill_no") or "",
                t["created_at"], _remarks]
        for col, v in enumerate(vals, 1):
            cell = ws.cell(row=r, column=col, value=v)
            cell.font = Font(size=10, color=DARK)
            cell.border = BORDER
            cell.alignment = Alignment(horizontal="center" if col not in (4, 7, 18) else "left", vertical="center")
            if col in (8, 9, 10, 11, 12, 13) and isinstance(v, (int, float)):
                cell.number_format = '0.0000'
            elif col == 15 and isinstance(v, (int, float)):
                cell.number_format = '0.00'
        if t["type"] == "RETURN" and box and box["difference"] not in (None, 0):
            ws.cell(row=r, column=13).fill = PatternFill("solid", fgColor="FCE4E4")
            ws.cell(row=r, column=13).font = Font(size=10, bold=True, color="B00000")
        r += 1

    # Summary section
    r += 1
    ws.merge_cells(f"A{r}:R{r}")
    c = ws.cell(row=r, column=1, value="DAILY SUMMARY"); c.font = Font(bold=True, size=12, color="7A5C00")
    r += 1
    summary = [
        ("Total Boxes", totals["boxes"]), ("Active Boxes", totals["active"]),
        ("Boxes Returned", totals["returned_count"]),
        ("Total Opening Weight (g)", totals["opening"]),
        ("Total Sold Weight (g)", totals["sold"]),
        ("Additional Stock Added (g)", totals["added"]),
        ("Total Returned Weight (g)", totals["returned"]),
        ("Total Remaining Weight — active boxes (g)", totals["remaining"]),
        ("Total Sale Amount (Rs)", totals.get("sale_amount", 0)),
    ]
    for label, val in summary:
        ws.merge_cells(f"A{r}:C{r}"); ws.cell(row=r, column=1, value=label).font = Font(bold=True, size=10)
        cell = ws.cell(row=r, column=4, value=val); cell.font = Font(size=10, bold=True)
        if isinstance(val, float):
            cell.number_format = '0.0000' if '(g)' in label else '0.00'
        r += 1
    r += 1
    ws.merge_cells(f"A{r}:R{r}"); ws.cell(row=r, column=1, value="CATEGORY-WISE TOTALS").font = Font(bold=True, size=12, color="7A5C00"); r += 1
    for h, col in zip(["Category", "Boxes", "Opening", "Sold", "Added", "Remaining"], range(1, 7)):
        cell = ws.cell(row=r, column=col, value=h); cell.font = Font(bold=True, color="FFFFFF"); cell.fill = PatternFill("solid", fgColor=GOLD); cell.border = BORDER
    r += 1
    for ct in db.category_totals(d):
        for col, v in enumerate([ct["category"], ct["boxes"], ct["opening"], ct["sold"], ct["added"], ct["remaining"]], 1):
            cell = ws.cell(row=r, column=col, value=v); cell.border = BORDER; cell.font = Font(size=10)
            if col >= 3 and isinstance(v, float):
                cell.number_format = '0.0000'
        r += 1
    r += 1
    ws.merge_cells(f"A{r}:R{r}"); ws.cell(row=r, column=1, value="METAL-WISE TOTALS").font = Font(bold=True, size=12, color="7A5C00"); r += 1
    for h, col in zip(["Metal", "Boxes", "Opening", "Sold", "Added", "Remaining"], range(1, 7)):
        cell = ws.cell(row=r, column=col, value=h); cell.font = Font(bold=True, color="FFFFFF"); cell.fill = PatternFill("solid", fgColor=GOLD); cell.border = BORDER
    r += 1
    for mt in db.metal_totals(d):
        for col, v in enumerate([mt["metal"], mt["boxes"], mt["opening"], mt["sold"], mt["added"], mt["remaining"]], 1):
            cell = ws.cell(row=r, column=col, value=v); cell.border = BORDER; cell.font = Font(size=10)
            if col >= 3 and isinstance(v, float):
                cell.number_format = '0.0000'
        r += 1
    r += 1
    ws.merge_cells(f"A{r}:R{r}"); ws.cell(row=r, column=1, value="SALESPERSON-WISE TOTALS").font = Font(bold=True, size=12, color="7A5C00"); r += 1
    for h, col in zip(["Salesperson", "Boxes", "Opening", "Sold", "Returned", "Active", "Remaining"], range(1, 8)):
        cell = ws.cell(row=r, column=col, value=h); cell.font = Font(bold=True, color="FFFFFF"); cell.fill = PatternFill("solid", fgColor=GOLD); cell.border = BORDER
    r += 1
    for sp in db.salesperson_report(d):
        for col, v in enumerate([sp["salesperson"], sp["boxes"], sp["opening"], sp["sold"], sp["returned"], sp["active"], sp["remaining"]], 1):
            cell = ws.cell(row=r, column=col, value=v); cell.border = BORDER; cell.font = Font(size=10)
            if col >= 3 and isinstance(v, float):
                cell.number_format = '0.0000'
        r += 1

    # Boxes sheet
    bs = wb.create_sheet("Boxes Summary")
    for i, w in enumerate([7, 18, 16, 16, 15, 13, 16, 15, 15, 12, 12], 1):
        bs.column_dimensions[get_column_letter(i)].width = w
    for col, h in enumerate(["S.No.", "Box ID", "Category", "Salesperson", "Opening", "Sold", "Added", "Expected Remaining", "Returned", "Difference", "Status"], 1):
        cell = bs.cell(row=1, column=col, value=h); cell.font = Font(bold=True, color="FFFFFF"); cell.fill = PatternFill("solid", fgColor=GOLD); cell.border = BORDER
    for i, b in enumerate(boxes, 1):
        for col, v in enumerate([i, b["box_id"], b["category"], b["salesperson"], b["opening_weight"], b["sold"], b["added"], b["expected_remaining"], b["returned_weight"] or "", b["difference"] if b["difference"] is not None else "", b["status"]], 1):
            cell = bs.cell(row=i + 1, column=col, value=v); cell.border = BORDER; cell.font = Font(size=10)
            if col >= 5 and isinstance(v, float):
                cell.number_format = '0.0000'
    ws.print_title_rows = '5:5'
    return wb

def _pending_path(base_dir):
    return paths_for(base_dir)["pending"]

def _read_pending(base_dir):
    try:
        with open(_pending_path(base_dir)) as f:
            data = json.load(f)
            return data if isinstance(data, list) else []
    except Exception:
        return []

def _write_pending(base_dir, dates):
    with open(_pending_path(base_dir), "w") as f:
        json.dump(sorted(set(dates)), f)

def sync_excel(db, d):
    """Returns 'ok' or 'queued'. Never raises for a locked file."""
    base_dir = db.base_dir
    path = excel_path_for(base_dir, d)
    wb = build_workbook(db, d)
    tmp = path + ".tmp.xlsx"
    try:
        wb.save(tmp)
        os.replace(tmp, path)
    except PermissionError:
        try:
            os.remove(tmp)
        except Exception:
            pass
        pending = _read_pending(base_dir)
        if d not in pending:
            pending.append(d)
        _write_pending(base_dir, pending)
        return "queued"
    except OSError:
        pending = _read_pending(base_dir)
        if d not in pending:
            pending.append(d)
        _write_pending(base_dir, pending)
        return "queued"
    # success: drop this date from pending
    pending = [x for x in _read_pending(base_dir) if x != d]
    _write_pending(base_dir, pending)
    return "ok"

def retry_pending(db):
    results = {}
    for d in _read_pending(db.base_dir):
        results[d] = sync_excel(db, d)
    return results

def pending_dates(base_dir):
    return _read_pending(base_dir)


# ---------- Monthly attendance report (v1.34) ----------
STATUS_FILL = {"P": "E2EFDA", "A": "FCE4E4", "L": "FFF2CC", "H": "DDEBF7"}

def attendance_month_path_for(base_dir, year, month):
    """Monthly attendance Excel lives alongside the daily reports:
    Daily Reports/YYYY/MonthName/Attendance-MonthName-YYYY.xlsx,
    so it is found in the same place as the daily files and is
    regenerable from the database at any time via Export."""
    d = f"{year:04d}-{month:02d}-01"
    folder = os.path.join(paths_for(base_dir)["reports"], str(year), month_name(d))
    os.makedirs(folder, exist_ok=True)
    return os.path.join(folder, f"Attendance-{month_name(d)}-{year}.xlsx")

def build_attendance_month_workbook(db, year, month):
    data = db.attendance_for_month(year, month)
    showroom = db.get_setting("showroom_name", "RAMANAND JEWELLERS")
    month_label = datetime(year, month, 1).strftime("%B %Y")
    wb = Workbook()
    ws = wb.active
    ws.title = "Monthly Attendance"
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.page_setup.orientation = "landscape"
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ncols = 1 + data["days"] + 5
    last_col = get_column_letter(ncols)
    ws.merge_cells(f"A1:{last_col}1")
    c = ws["A1"]; c.value = showroom; c.font = Font(size=16, bold=True, color=DARK); c.alignment = Alignment(horizontal="center")
    ws.merge_cells(f"A2:{last_col}2")
    c = ws["A2"]; c.value = f"Monthly Attendance  —  {month_label}"; c.font = Font(size=12, bold=True, color="7A5C00"); c.alignment = Alignment(horizontal="center")
    ws.merge_cells(f"A3:{last_col}3")
    c = ws["A3"]; c.value = "P = Present  •  A = Absent  •  L = Leave  •  H = Half Day  •  Blank = not marked that day (never counted as absent)."
    c.font = Font(size=9, italic=True, color="666666"); c.alignment = Alignment(horizontal="center")
    headers = ["Salesperson"] + [str(d) for d in range(1, data["days"] + 1)] + ["Present", "Absent", "Leave", "Half Day", "Marked"]
    ws.column_dimensions["A"].width = 22
    for col in range(2, 2 + data["days"]):
        ws.column_dimensions[get_column_letter(col)].width = 5
    for col in range(2 + data["days"], ncols + 1):
        ws.column_dimensions[get_column_letter(col)].width = 11
    hr = 5
    for col, h in enumerate(headers, 1):
        cell = ws.cell(row=hr, column=col, value=h)
        cell.font = Font(bold=True, color="FFFFFF", size=10)
        cell.fill = PatternFill("solid", fgColor=GOLD)
        cell.alignment = Alignment(horizontal="center", vertical="center")
        cell.border = BORDER
    r = hr + 1
    for row in data["rows"]:
        ws.cell(row=r, column=1, value=row["salesperson"]).font = Font(size=10, bold=True)
        ws.cell(row=r, column=1).border = BORDER
        for dnum in range(1, data["days"] + 1):
            cell = ws.cell(row=r, column=1 + dnum, value=row["days"].get(dnum, ""))
            cell.font = Font(size=10, bold=True); cell.border = BORDER
            cell.alignment = Alignment(horizontal="center")
            if cell.value in STATUS_FILL:
                cell.fill = PatternFill("solid", fgColor=STATUS_FILL[cell.value])
        for col, v in enumerate([row["present"], row["absent"], row["leave"], row["half_day"], row["marked"]], 2 + data["days"]):
            cell = ws.cell(row=r, column=col, value=v)
            cell.font = Font(size=10, bold=True); cell.border = BORDER; cell.alignment = Alignment(horizontal="center")
        r += 1
    # Totals row
    ws.cell(row=r, column=1, value="TOTAL").font = Font(size=10, bold=True)
    ws.cell(row=r, column=1).border = BORDER
    for col in range(2, 2 + data["days"]):
        ws.cell(row=r, column=col).border = BORDER
    tot = data["totals"]
    for col, v in enumerate([tot["present"], tot["absent"], tot["leave"], tot["half_day"], tot["marked"]], 2 + data["days"]):
        cell = ws.cell(row=r, column=col, value=v)
        cell.font = Font(size=10, bold=True); cell.border = BORDER; cell.alignment = Alignment(horizontal="center")
    return wb

def export_attendance_month(db, base_dir, year, month):
    """Save the monthly attendance workbook. Returns its path.
    Raises PermissionError if the file is open in Excel — the
    caller shows that plainly instead of silently queueing."""
    path = attendance_month_path_for(base_dir, year, month)
    wb = build_attendance_month_workbook(db, year, month)
    wb.save(path)
    return path
