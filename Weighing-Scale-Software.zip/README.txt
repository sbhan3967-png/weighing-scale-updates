================================================================
 WEIGHING SCALE — Jewellery Box Management & Daily Weighing
================================================================
Offline Windows desktop software. No internet needed after setup.
No cloud, no login. Your data stays on your own computer.

WHAT IT DOES
  Morning: pick a Box Category + Salesperson, type the opening
  weight from the scale, SAVE BOX OUT. A Box ID is generated
  automatically, e.g. BOX-20261031-001.
  During the day: select the active box and Add Sale / Add Stock.
  Remaining weight updates instantly:
      Remaining = Opening + Stock Added - Sold
  Evening: select the box, Return Box, type the actual weight
  from the scale. The software shows Expected vs Actual and the
  Difference, and asks for an explanation if they differ.
  Every save writes to SQLite immediately AND updates that day's
  Excel file. Close the laptop, reopen later — everything is back.

INSTALL (one time, needs internet for Python/packages only)
  1. Extract the FULL zip to a folder (e.g. Documents\Weighing-Scale).
     Do not run Setup from inside the zip.
  2. Double-click Setup.bat and wait. If Python is missing it
     installs Python 3.12 by itself, installs openpyxl, and puts a
     "Weighing Scale" icon on your desktop.
  3. Double-click the desktop icon to start.
  NOTE: if your antivirus quarantines Setup.bat, restore it from
  Windows Security -> Protection history (it only installs Python
  and one Excel package — nothing harmful).

FIRST USE (2 minutes)
  1. Settings tab -> Salespersons -> type each name -> Add.
     (Categories are pre-loaded: Ladies Ring, Gents Ring, Ladies
     Chain, Gents Chain, Necklace, Earrings, Bangles, Bracelet,
     Pendant, Payal, Nose Pin, Mangalsutra, Other. Add/rename/
     deactivate any of them there.)
  2. Settings tab -> General -> check your showroom name.
  3. Dashboard -> pick Category + Salesperson, type opening
     weight, SAVE BOX OUT. Done — the box is active.

DAILY USE
  Dashboard: today's boxes, opening, sold and remaining totals
  are at the top. Active boxes are listed below.
  Add Sale: select a box -> Add Sale -> type sold weight.
    If the sale is bigger than the remaining weight, the software
    STOPS and asks for an override with a reason. Without a reason
    a negative remaining weight is not allowed.
  Add Stock: select a box -> Add Stock -> type weight added.
  Return Box: select a box -> Return Box -> type actual weight.
  View History: select a box -> View History -> every transaction
    plus the audit trail (corrections and voids).
  Daily Entries: correct or void an entry — a reason is required
    and the old value stays in the audit trail. Nothing is ever
    silently overwritten.
  Reports & History: pick any past date, filter by category /
    salesperson / type, search by Box ID, re-export or open Excel.
  Salesperson Reports: per-day boxes, categories, opening, sold,
    returned, active and remaining per salesperson.
  Backup & Restore: backup runs automatically on every close.
    Backup Now / Restore from Backup are on this tab.

WHERE YOUR DATA LIVES
  Documents\Weighing Scale\
      Database\weighing_scale.db        <- source of truth
      Daily Reports\2026\October\31-10-2026.xlsx
      Backups\Database Backups\weighing_scale_YYYYMMDD_HHMMSS.db
  Change the folder in Settings -> Change Folder (the database
  is copied to the new folder; restart the app after changing).

EXCEL — IMPORTANT
  One Excel file per date, never two. It is regenerated from the
  database on every save, with a gold header, 2-decimal weights,
  a daily summary, category-wise totals and salesperson-wise
  totals, plus a "Boxes Summary" sheet.
  If the Excel file is OPEN when you save, nothing is lost: the
  database save succeeds and the Excel update is QUEUED. Close
  Excel, then Backup tab -> Retry Pending Excel. The dashboard
  header warns you while anything is pending.
  Do not edit the Excel file by hand to fix a mistake — correct
  it in the software (Daily Entries) so the database stays true.

NEW DAY
  On 1 November the dashboard starts fresh and empty, and a new
  01-11-2026.xlsx is created. Yesterday's records are NOT deleted
  — open them any time in Reports & History.

TROUBLESHOOTING
  - App doesn't open: run Weighing-Scale-Debug.bat — it shows the error.
  - "Salesperson list is empty": add names in Settings first.
  - Excel not updating: check the dashboard header for the pending
    warning, close Excel, retry from the Backup tab.
  - Wrong weight entered: Daily Entries -> select it -> Correct
    Entry, with a reason. Do not edit the Excel file directly.

SOURCE FILES IN THIS FOLDER
  app.py           - the desktop interface (all 7 tabs)
  db.py            - SQLite database + weight calculations + audit
  excel_export.py  - daily Excel generation + locked-file queue
  test_all.py      - the 10 acceptance tests (run: python test_all.py)

Built for Ramanand Jewellers. Tested: box 126.44 g - sale 26.44 g = 100.00 g;
close/reopen recovery; new-day freshness with history intact;
return difference; Excel totals; locked-Excel queue with no data loss.

----------------------------------------------------------------
GITHUB AUTO-UPDATE (v1.1, online updates)
----------------------------------------------------------------
  The app checks GitHub on every launch (in the background) for a
  newer version, and also has "Check for Updates" on the Backup tab.
  Update channel (public repo, no login needed to read it):
      github.com/sbhan3967-png/weighing-scale-updates
      version.json  +  Weighing-Scale-Software.zip
  If a newer version is found, the app asks once. On Yes it
  downloads the new zip, installs it over the app folder and
  restarts. Your database, daily Excel files and backups live in
  Documents\Weighing Scale\ — outside the app folder — so updates
  never touch them.
  No internet? The check just finds nothing and the app runs
  normally, offline, as before.
  TO PUSH A NEW VERSION (from the developer side): replace
  Weighing-Scale-Software.zip in that repo and bump "version" in
  version.json. Every PC picks it up on next launch.

APP ICON
  icon.ico is the gold weighing-scale icon: it shows in the app
  window title bar and on the desktop shortcut created by Setup.bat.

----------------------------------------------------------------
WHY THE CMD WINDOW OPENED (v1.0/v1.1) — FIXED IN v1.2
----------------------------------------------------------------
  The old launcher ran the app with python.exe, which is a
  console program: Windows kept its black cmd window open for
  as long as the app ran, and closing that window killed the app.
  v1.2 fixes it two ways:
  1. Weighing-Scale.bat now uses pythonw.exe (windowless Python)
     and exits immediately, so no cmd window stays open.
  2. The desktop shortcut (recreated by Setup.bat) now points to
     Weighing-Scale.vbs, which runs the launcher completely
     hidden — not even a brief cmd flash.
  If you launch Weighing-Scale.bat directly you may still see a
  very brief flash; launch from the desktop icon for none at all.
  Weighing-Scale-Debug.bat still opens a cmd window on purpose,
  so errors are visible when troubleshooting.

----------------------------------------------------------------
SALE PAYMENT DETAILS (v1.3)
----------------------------------------------------------------
  When you Add Sale, the sale window now asks for:
    Mode of Transaction — dropdown: CASH, UPI, CARD, BANK TRANSFER,
      CREDIT / UDHAAR, CHEQUE, OTHER (defaults to CASH, as on the
      old manual sheet)
    Amount (Rs) — typed by you, e.g. 250000
    Bill No./Rokar/Book (BN) — typed by you, e.g. 25150
  Amount and Bill No./Rokar/Book may be left blank if you don't have them yet;
  they are saved with the sale and show in Daily Entries, Reports,
  Box History and the daily Excel file (new Mode / Amount / Bill
  columns), and the daily summary now totals the sale amount in Rs.
  Old databases are upgraded automatically on first launch of v1.3
  — your existing sales simply show blank Mode/Amount/Bill No./Rokar/Book

----------------------------------------------------------------
CLIENT PC INSTALL — WHAT SETUP INSTALLS AUTOMATICALLY (v1.4)
----------------------------------------------------------------
  On a brand-new client PC, the client does NOTHING except:
    1. Extract the zip to a folder.
    2. Double-click Setup.bat once.
    3. Double-click the desktop "Weighing Scale" icon.
  Setup.bat then installs/verifies, in order, with no manual steps:
    a. Python 3.12 — if Python is missing, Setup installs it
       itself (first via winget, else by downloading the official
       Python 3.12 installer from python.org, per-user, no admin).
       It only accepts a Python that actually runs — the Windows
       Microsoft Store stub that says "Python was not found" is
       ignored, and known install folders are searched even if
       Python is not on PATH.
    b. tkinter + sqlite3 — checked (both ship inside Python on
       Windows; if tkinter is missing Setup stops with a clear
       message to reinstall Python with "tcl/tk and IDLE" ticked).
    c. Python packages — openpyxl (for Excel) + its dependency
       et_xmlfile, installed from the wheels/ folder bundled in
       this zip, so packages install EVEN WITHOUT INTERNET.
       If the wheels folder is missing, Setup falls back to
       downloading them online (pip).
    d. App self-check — Setup runs: python app.py --check
       which proves tkinter + sqlite3 + openpyxl + the database
       all work, and prints the version. Setup stops with an
       error instead of claiming success if this fails.
    e. Data folders + desktop shortcut — Documents\Weighing Scale
       (Database / Daily Reports / Backups) is created, and the
       shortcut points to the hidden launcher (no cmd window).
  After Setup, the app works fully OFFLINE. Internet is needed
  only once, and only if Python itself is missing (step a).
  Future updates need NO Setup re-run: the app auto-updates
  from GitHub (see GITHUB AUTO-UPDATE above).
  Files that make this work: Setup.bat, requirements.txt,
  wheels/openpyxl-*.whl, wheels/et_xmlfile-*.whl, app.py --check.

----------------------------------------------------------------
BOX IDENTIFICATION — GOLD OR SILVER (v1.5)
----------------------------------------------------------------
  Every box now carries a Metal identity: GOLD or SILVER.
  Dashboard -> BOX OUT panel has a Metal dropdown (defaults to
  GOLD) next to Category and Salesperson. Pick it when the box
  is taken out — it stays with that box for its whole life.
  Metal shows in: Active Boxes table, Daily Entries, Reports &
  History (with a Metal filter: GOLD / SILVER / all), Box History,
  and the daily Excel file (new Metal column + METAL-WISE TOTALS
  section: boxes, opening, sold, added and remaining per metal).
  Old boxes made before v1.5 show a blank Metal (they were made
  before this field existed); their weights and history are
  unchanged, and the database upgrades automatically.

----------------------------------------------------------------
KEYBOARD-FIRST USE + DASHBOARD COLUMNS (v1.6, customer preference)
----------------------------------------------------------------
  The client barely uses the mouse, so the Dashboard is built
  for the keyboard (mouse still works everywhere):
    Tab / Shift+Tab — move to the next / previous field
    Enter — save (in Box Out, Add Sale, Add Stock, Return,
      Correct and Void windows)
    Esc — close a window without saving
    Up / Down — pick a box in the Active Boxes table
    Enter on a selected box — Add Sale for that box
    S — Add Sale   •   A — Add Stock   •   R — Return Box
    H — View History   •   Alt+1…7 — switch tabs
  Flow with no mouse: open the app (cursor starts on Category),
  Tab through Category -> Salesperson -> Metal -> Opening Weight,
  type, press Enter to save the box, then Up/Down to the box,
  press S, type weight / Mode / Amount / Bill No./Rokar/Book (Tab between
  them), press Enter to save the sale. After a Box Out save the
  cursor returns to Category for the next box.
  DASHBOARD TABLE (like the customer's manual sheet):
    S.No. | Category | Metal | Salesperson | Opening | Sold |
    Return | Sell Amount | Bill No./Rokar/Book | Status | Time
  Changes vs before: Box ID column is HIDDEN (the box id is
  still stored and used internally, just not shown), the
  Remaining column is REMOVED from this table and replaced by
  Return (actual returned weight — blank while the box is still
  out, filled when it comes back), followed by Sell Amount
  (total Rs sold from that box) and Bill No./Rokar/Book (bill numbers from
  its sales, joined with commas). Remaining weight is still
  calculated internally for the overweight check and still
  appears in Box History and in the Excel report — tell us if
  you want it removed there too.

----------------------------------------------------------------
RETURN COLUMN — EMPTY UNTIL THE SCALE WEIGHT IS ENTERED (v1.7)
----------------------------------------------------------------
  Return is NEVER pre-filled — not with 0, not with the expected
  remaining weight. While a box is out, its Return cell is blank.
  When the box comes back, press R on that box, type exactly the
  weight printed by the weighing scale, press Enter — that typed
  weight is what appears in the Return column. The Return window
  no longer shows an "expected remaining" figure, so nothing
  suggests a value to copy.
  Returned boxes now STAY on the Dashboard's "Today's Boxes"
  list for the day (Status shows RETURNED), so the filled Return
  stays visible on the same day's sheet, exactly like the manual
  sheet. Sale / Stock / Return keys work only on ACTIVE boxes;
  trying them on a returned box shows a clear message.

----------------------------------------------------------------
FIX: APP OPENS THEN CLOSES IN A SECOND (v1.8)
----------------------------------------------------------------
  What was happening: under the hidden launcher (pythonw) any
  startup error closed the window with NO error message, so it
  looked like "loading, then closing in a second". The most
  likely triggers were (a) one Dashboard/Reports tab failing
  during startup refresh, which used to kill the whole app, and
  (b) an update prompt 1 second after opening that closed the
  app to apply the update — if the apply step then failed to
  restart it, the user was left with no app at all.
  v1.8 fixes all three, so the app cannot die silently again:
    * refresh_all is guarded tab by tab — a bad tab is logged
      and skipped, the other tabs still load, the app stays open.
    * The app NEVER auto-prompts an update on launch any more.
      If an update is available it only shows a quiet line in
      the header ("Update vX available — open Backup tab").
      Updates are started deliberately from Backup tab →
      Check for Updates.
    * Before an update closes the app, the downloaded zip is
      validated (must contain app.py). A bad zip aborts and
      the current app keeps running instead of closing.
    * The apply batch ALWAYS restarts the app, even if
      extraction fails (and writes update_error.txt then).
    * Any startup crash now writes crash_log.txt in the app
      folder AND shows it in a message box, instead of just
      closing. Send that file if it ever happens again.
    * New Weighing-Scale-Safe.bat: runs "python app.py --safe"
      (no auto-update check, no startup Excel sync). Use it
      first if the normal icon ever fails again.

----------------------------------------------------------------
FIX: DASHBOARD TABLE EMPTY (v1.9) — ROOT CAUSE OF THE CLOSING BUG TOO
----------------------------------------------------------------
  Bug (introduced in v1.6 when Box ID was hidden): the Dashboard
  table insert was written as
      tree.insert("", iid=box_id, end="end", ...)
  but tkinter's Treeview.insert needs the position as the 2nd
  POSITIONAL argument: insert("", "end", iid=box_id, ...).
  Passing end="end" as a keyword threw TypeError on the first
  row, so the Dashboard table stayed empty even though the box
  count, Excel file and Daily Entries all updated correctly —
  and before v1.8's startup guard, that same error closed the
  whole app a second after opening. Fixed in v1.9: the table
  now shows every box for today, with Return / Sell Amount /
  Bill No./Rokar/Book as in v1.6/v1.7, and the v1.8 guards stay in place
  as a safety net.

----------------------------------------------------------------
MANUAL CELL ENTRY — TYPE DIRECTLY IN THE COLUMNS (v1.10)
----------------------------------------------------------------
  Dashboard table, keyboard only, like the manual Excel sheet:
    Up / Down — move row   •   Left / Right — move COLUMN
    Home / End — first / last column
    The selected cell is shown under the table
    ("Selected cell: Row ... • Column: ... • Value: ...").
  MANUALLY TYPE IN THESE COLUMNS (no dialog, no mouse):
    Sold — press Enter / F2 (or just type a number) and type
      a sale weight. Enter saves it as a NEW sale for that box
      (Mode CASH by default; Amount and Bill No./Rokar/Book are then typed
      in their own columns). Esc cancels.
    Sell Amount — type the amount for the box's LATEST sale.
      It shows the latest sale's amount first, so it can be
      corrected in place.
    Bill No./Rokar/Book — type the bill number for the box's LATEST sale.
      (Sell Amount / Bill No./Rokar/Book need a Sold weight first — the
      app will say so if there is no sale yet.)
    Return — type the weighing-scale print weight. Enter
      returns the box with exactly that weight. If it differs
      from expected, a small Reason box appears (required by
      the audit rule) — type the reason, Enter, done.
  After Enter, the cursor moves one column to the right, so
  Sold -> Return -> Sell Amount -> Bill No./Rokar/Book can be filled
  left to right. Other columns (Category, Metal, Salesperson,
  Opening, Status, Time) are NOT typed in directly — press
  Enter on one of those to see that box's History. S / A / R /
  H shortcuts still work on the selected row from any column.
  Overweight: typing a Sold weight above remaining is refused
  with a message (use Add Sale with S for an override reason).

----------------------------------------------------------------
RESET BUTTON (v1.11)
----------------------------------------------------------------
  Dashboard has "Reset Today" (under the boxes table) and Daily
  Entries has "Reset This Date" (for the date shown there).
  What Reset does for THAT date only:
    * Deletes every box for that date, with all its sales,
      stock adds and returns (and their audit rows).
    * Deletes that day's Excel file.
    * Clears that date from the pending-Excel queue.
  What it does NOT do:
    * Other days are NOT touched — their boxes, entries and
      Excel files stay exactly as they are.
  Safety, because Reset cannot be undone by itself:
    * A safety backup of the whole database is made FIRST
      (Backups folder). If Reset was pressed by mistake, go to
      Backup tab → Restore and pick that backup.
    * A confirmation box lists the date, how many boxes will
      be deleted, and the Excel path, and asks "Are you sure?"
    * If that day's Excel file is open/locked, Reset stops
      BEFORE deleting anything and tells you to close Excel
      first, so you never end up with entries deleted but the
      Excel file still there (or vice versa).
  Keyboard: Tab to the Reset button, Enter to press it, then
  Tab / Enter on the confirmation (Yes = first button in the
  dialog on Windows; use Tab to move if needed).

----------------------------------------------------------------
HORIZONTAL SALE ENTRY (v1.12)
----------------------------------------------------------------
  Add Sale is now ONE horizontal row, like Excel, instead of a
  vertical stack of label-over-field:
    Sold (g)  |  Mode  |  Amount (Rs)  |  Bill No./Rokar/Book  |  Remarks
  with those column names as a header row on top.
  Type left to right: Tab or Enter moves Sold -> Mode ->
  Amount -> Bill No./Rokar/Book -> Remarks -> Save. Ctrl+Enter saves
  from any field, Esc cancels. Mode keyboard picks are
  unchanged (1=CASH 2=UPI 3=CARD 4=BANK TRANSFER
  5=CREDIT / UDHAAR 6=CHEQUE 7=OTHER, letter cycles, ↓ opens).
  The Dashboard table's own manual cell entry is unchanged —
  arrow to Sold / Added / Return / Sell Amount / Bill No./Rokar/Book
  and type directly in the cell.

----------------------------------------------------------------
COLOUR WHERE YOU ARE + REMOVED LINES (v1.13)
----------------------------------------------------------------
  Colour, so you can tell at a glance where you are:
    * Selected row in ANY table (Dashboard, Daily, Reports,
      History) is now GOLD, not the plain system blue/grey.
    * The field you are typing in turns PALE YELLOW, and
      back to white when you leave it — in the sale row,
      Box Out, Add Stock / Return, Correct / Void, and the
      Daily date/search boxes. The inline cell Entry over a
      Dashboard cell is pale yellow too.
    * In the horizontal sale row, the HEADER above the field
      you are in turns GOLD (Sold -> Mode -> Amount -> Bill
      No. -> Remarks as you Tab / Enter across), the rest
      stay light. So the column you are in is coloured twice:
      header gold + field pale yellow.
  Removed, as asked:
    * The "(Return stays blank until the box comes back)"
      note under "Today's Boxes" — heading is now just
      "Today's Boxes — active and returned".
    * The Box Out help line "Date & time are taken
      automatically ... Metal is GOLD or SILVER — pick it
      here, it stays with the box." — the Box Out row itself
      is unchanged.

----------------------------------------------------------------
CELL COLOUR ACROSS COLUMNS + FIRST-LETTER DROPDOWN (v1.14)
----------------------------------------------------------------
  1) Cell colour across columns: the table itself can only
     colour a whole ROW, which is why moving Left/Right in
     the same row showed no colour change — the row stayed
     gold, the column did not. Fixed with a gold cell overlay:
     a gold box now sits exactly on the cell you are on and
     moves with you, Left/Right across columns in the same
     row as well as Up/Down across rows, showing that cell's
     value in bold. It hides while an inline edit Entry is
     open (that Entry is pale yellow instead) and comes back
     when editing ends, and it repositions after a mouse-
     wheel scroll.
  2) Box Out Category / Salesperson — type the first letter:
     both boxes are now typeable (they were read-only before,
     so typing did nothing). Type L and the box fills with
     the first L item (LADIES CHAIN; keep typing LADIES R
     for LADIES RING), type P and it shows PAYAL, type R in
     Salesperson and it shows Rahul. The dropdown arrow is
     still there — click it, or press Down — and it then
     shows only the matching items; clearing the box brings
     the full list back. A name that is not in the list is
     left as typed, and Save will say it is not found
     (add it in Settings first). Enter still saves the box.

----------------------------------------------------------------
VERSION ALWAYS VISIBLE (v1.15)
----------------------------------------------------------------
  You could not SEE which version you were on — the title
  bar had no version at all, so "am I on v14?" had no answer
  on screen. Fixed: the title bar now reads
  "Weighing Scale v1.15 — Ramanand Jewellers" and the header
  next to the showroom name shows "Version v1.15" permanently
  (it is never cleared by a refresh, unlike the update /
  Excel-pending line). Backup tab → Check for Updates also
  still tells you your current version in its message.
  v1.15 contains everything in v1.14 (gold cell moving
  column to column, first-letter Category/Salesperson
  autocomplete) plus this visibility fix.

----------------------------------------------------------------
RETURN FIRST, THEN SELL (v1.16)
----------------------------------------------------------------
  Return Box now works return-first, then sell:
    * Type the weighing-scale print weight as before.
    * If the box comes back LIGHTER than expected, the
      Sale panel opens AUTOMATICALLY, with the missing
      weight already written in Sold. Example: opening
      400 g, return 300 g -> Sold opens at 100.00 g.
      You only fill Mode / Amount / Bill No./Rokar/Book and save.
    * The sale is saved BEFORE the box closes, so after
      it the expected weight matches the returned weight
      exactly and the box closes with difference 0
      (400 - 100 sale = 300 expected = 300 return).
    * If you cancel the Sale panel, the old flow applies:
      the box returns with the difference noted, and a
      reason is required, as before.
    * A box that comes back HEAVIER than expected never
      opens the Sale panel — extra weight is not a sale —
      it returns with a reason, as before.
    * With a prior sale it works the same way on the
      remaining difference: opening 400, sold 50, return
      300 -> Sale panel opens at 50.00 g.
  Note: this auto-Sale applies to the Return Box button.
  Typing a Return directly in the Dashboard table still
  asks for a reason when it differs, as before.

----------------------------------------------------------------
RETURN -> SELL NOTIFICATION (v1.17)
----------------------------------------------------------------
  Between Return and Sell there is now a notification, so
  the Sale panel does not just pop open unannounced:
    "Weight difference: 100.00 g
     Opening: 400.00 g  •  Expected: 400.00 g  •  Returned: 300.00 g
     Do you want to go to the Sell panel to record this
     100.00 g as a sale?"
    [Yes — Go to Sell panel]   [No — Return with reason]
  Press ENTER (or click Yes) and the Sale panel opens with
  the difference already in Sold, exactly as in v1.16.
  Press ESC (or click No) and the box returns with the
  difference noted, with a reason required, as before.
  The notification is a custom dialog (not a plain system
  popup) so Enter is guaranteed to mean Yes.

----------------------------------------------------------------
BOX OUT HORIZONTAL SCROLLING (v1.18)
----------------------------------------------------------------
  The Box Out row (Category + Salesperson + Metal +
  Opening Weight + Save) is about 1330 px wide, wider than
  the 1180 px window, so the Save button used to fall off
  the right edge with no way to reach it. Now the Box Out
  panel has a horizontal scrollbar underneath it: drag it,
  or just Tab / click to any field, and the panel scrolls
  that field (including the Save button) into view
  automatically. The Dashboard table itself stretches to
  the window width, so it did not need a scrollbar.

----------------------------------------------------------------
v1.19 — KEYBOARD SHORTCUTS, 4-DECIMAL WEIGHTS, ATTENDANCE
----------------------------------------------------------------
  KEYBOARD
  - B (with the Dashboard table selected) = jump to Box
    Category in the Box Out panel and open its list.
  - Space (in a Box Out field, when that field already
    holds a complete value) = jump to the table, last box
    selected. A half-typed name (e.g. "LADIES" on the way
    to "LADIES RING") still gets its space, so typing is
    not broken.
  - Sale panel: Enter now goes Sold -> Amount -> Bill No./Rokar/Book
    -> Remarks -> Save, skipping Mode (Mode stays CASH
    unless you Tab to it). A sale opened from Return
    (weight already written) opens directly on Amount.
    Saving a sale with no weight now warns instead of
    silently doing nothing.
  4-DECIMAL WEIGHTS (Mettler print)
  - Every weight in the app is now stored and shown to
    4 decimals, exactly as a Mettler scale prints it:
    Box Out, Return, Sold, Added, tables, messages and
    Excel (Excel weight columns use 0.0000). Rs amounts
    stay at 2 decimals. Old weights show trailing zeros
    (100.0000) — same weight, just 4-decimal display.
    The Return difference threshold is now 0.0001 g.
  ATTENDANCE (new tab, Alt+7)
  - Separate panel for salespersons: pick a date, mark
    PRESENT / ABSENT / LEAVE / HALF DAY, optional In and
    Out times (HH:MM, e.g. 10:00) and remarks. One record
    per person per day — marking again updates that day,
    it never duplicates. The table shows every active
    salesperson, marked or not, with a summary (Present /
    Absent / Leave / Half Day / Unmarked). Click a row to
    load it into the form and correct it. After Save, the
    form moves to the next unmarked person automatically.

----------------------------------------------------------------
v1.20 — LIVE MCX RATES BANNER (mcxlive.org)
----------------------------------------------------------------
  A black-and-gold banner scrolls across the top of the
  Dashboard: MCX Gold and MCX Silver from mcxlive.org,
  refreshed every 60 seconds in the background (never
  blocking the app). Example: "MCX GOLD (04 Dec 2026)
  ₹1,38,419 / 10 g ▼ -66 (-0.05%) • MCX SILVER
  ₹1,78,900 / 1 kg ▼ -232 (-0.13%) • Last trade
  30 Oct 23:29 PM • Site updated … • Source:
  mcxlive.org". Gold is per 10 g, silver per 1 kg, as
  MCX quotes them. Buttons on the banner: ↻ Refresh
  (fetch now) and ⏸ Pause / ▶ Resume (stops the scroll
  and the fetching). If the internet or the site is down,
  the last good rate stays up marked OFFLINE; if the
  site's page layout changes, the banner keeps the last
  rate instead of showing a wrong number.
  HONEST LIMIT: mcxlive.org has no public per-minute
  API — the app fetches its gold and silver pages every
  minute and shows the site's latest Last Trade table.
  The banner always shows the site's own "As on" time
  and last-trade time, so when the market is closed
  (weekends, holidays) you see the last close, not a
  fake live price.

----------------------------------------------------------------
v1.21 — SIMPLER LIVE RATES BANNER
----------------------------------------------------------------
  Refresh and Pause buttons removed from the banner.
  The scrolling text is now gold and silver only, no
  dates and no extra text, e.g.: "MCX GOLD ₹1,38,419 /
  10 g ▼ -66 (-0.05%) • MCX SILVER ₹1,78,900 / 1 kg
  ▼ -232 (-0.13%)". The small LIVE / OFFLINE label at
  the right edge stays, so you can still see at a glance
  whether the rate is live or the last rate held while
  offline. Fetching still runs automatically every 60
  seconds in the background — no button press needed.

----------------------------------------------------------------
v1.22 — SOLD COLUMN GREEN ONLY WHEN SOLD
----------------------------------------------------------------
  The Sold column entry in the Dashboard table turns
  GREEN only when that box has actually sold weight.
  Only the Sold entry is green — the rest of the row
  stays the normal gold selection. If Opening weight =
  Returned weight, the Sold entry is NOT highlighted
  green (a box returned whole, even if stock was added
  and sold in equal amounts, counts as not sold by
  that rule). Clicking a green Sold entry selects that
  box and moves the cell cursor onto Sold. The green
  labels reposition on scroll and window resize, so
  they never go stale.

----------------------------------------------------------------
v1.23 — BILL NO. RENAMED TO BILL NO./ROKAR/BOOK
----------------------------------------------------------------
  Everywhere the column used to read "Bill No." it now
  reads "Bill No./Rokar/Book" — Dashboard, Daily Entries,
  Reports & History, box History, the Add Sale panel
  header, the selected-cell line, and the Excel export
  header. The column is wider so the full name fits.
  Nothing else changed: it still holds the same bill /
  rokar / book number, and inline editing on that
  column works exactly as before (the internal name
  was left alone on purpose, so no editing logic broke).

----------------------------------------------------------------
v1.24 — SPACE ALWAYS JUMPS TO THE TABLE
----------------------------------------------------------------
  Space in a Box Out field now ALWAYS jumps to the
  Dashboard table (last box selected) — not Enter
  (Enter saves the box). The old v1.19 rule, where
  Space only jumped when the field already held a
  complete value, is removed: whenever you want the
  table, Space gets you there, whatever is in the
  field. Shift+Space still types a real space, for
  the rare case a name itself needs one (picking a
  name from the dropdown is the normal way to get
  "LADIES RING" and other multi-word names).

----------------------------------------------------------------
v1.25 — WEIGHT NUMBERS ONLY + SCROLLABLE SHORTCUTS HELP
----------------------------------------------------------------
  WEIGHT NUMBERS ONLY: every weight field now takes
  numbers only as you type — digits and one decimal
  point. Letters, spaces, minus signs and a second
  decimal point are blocked and simply never appear,
  instead of failing on Save. Covered: Box Out
  Opening Weight, Dashboard Sold / Added / Return
  cells (and Sell Amount, also a number), Add Sale
  Sold weight and Amount, Add Stock / Return weight
  dialogs, and Correct Entry weight. Bill No./Rokar/
  Book is left free on purpose — bill numbers can
  contain letters.
  SCROLLABLE SHORTCUTS HELP: the Dashboard page
  itself is now scrollable (mouse wheel anywhere on
  the page, or drag the right scrollbar), because
  its total height used to exceed the window and
  squeeze the bottom help to 1 pixel, so it could
  not be read or scrolled. The keyboard shortcuts
  are also now one line each in a small box with its
  own scrollbar — scroll inside that box to read
  them all. Wheel over the table still scrolls the
  table, wheel over the shortcuts box still scrolls
  that box; wheel elsewhere scrolls the page.

----------------------------------------------------------------
v1.26 — STARTUP CRASH NOW VISIBLE (NOT SILENT UNDER pythonw)
----------------------------------------------------------------
  The old Treeview.insert() "missing index" error from the
  old crash log is ALREADY fixed (v1.9) — every insert()
  in this version uses ("", "end", ...) correctly, and
  that fix was NOT repeated. The actual current silent-
  crash path was different: import failures and database
  initialisation failures happen BEFORE the old crash
  handler, so under pythonw.exe (no console) the app
  just closed with no crash_log and no dialog.
  Fixed in app.py only:
    - A startup-failure helper, defined before any
      risky import, writes a FRESH timestamped
      crash_log.txt first, then shows a clear error
      dialog (tkinter, else Windows MessageBox via
      ctypes, else stderr), then exits.
    - All risky imports are now inside a try that
      calls that helper on failure.
    - Database creation is guarded the same way:
      on failure it logs + shows the dialog with
      the exact database path tried, and exits
      WITHOUT creating a new database, WITHOUT
      switching paths, and WITHOUT deleting,
      replacing or moving any existing database
      or Excel file. If the error is "unable to
      open database file", check that this Windows
      user can WRITE to the Database folder shown
      in the dialog / log.
    - write_crash_log() no longer fails when the
      database did not initialise (it used to touch
      DB.db_path and could leave the log empty).
    - Dashboard refresh was already guarded per
      tab (v1.8) and needs no change: a refresh
      error is logged, other tabs still load.
  Verified here: safe-mode launch opens the window
  (no crash_log, process stays running); a forced
  database failure (base path set to a file) writes
  a fresh timestamped crash_log with the full
  traceback and the database path tried, and leaves
  the existing file untouched.
