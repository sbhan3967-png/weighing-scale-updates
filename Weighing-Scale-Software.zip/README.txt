================================================================
 WEIGHING SCALE — Jewellery Box Management & Daily Weighing
================================================================
Offline Windows desktop software. No internet needed after setup.
No cloud, no login. Your data stays on your own computer.

WHAT IT DOES
  Morning: pick a Box Category + Salesperson, type the opening
  weight from the scale, SAVE BOX OUT. A Box ID is generated
  automatically, e.g. BOX-20261031-001.
  During the day: select the active box and Add Sale / Add Stock.
  Remaining weight updates instantly:
      Remaining = Opening + Stock Added - Sold
  Evening: select the box, Return Box, type the actual weight
  from the scale. The software shows Expected vs Actual and the
  Difference, and asks for an explanation if they differ.
  Every save writes to SQLite immediately AND updates that day's
  Excel file. Close the laptop, reopen later — everything is back.

INSTALL (one time, needs internet for Python/packages only)
  1. Extract the FULL zip to a folder (e.g. Documents\Weighing-Scale).
     Do not run Setup from inside the zip.
  2. Double-click Setup.bat and wait. If Python is missing it
     installs Python 3.12 by itself, installs openpyxl, and puts a
     "Weighing Scale" icon on your desktop.
  3. Double-click the desktop icon to start.
  NOTE: if your antivirus quarantines Setup.bat, restore it from
  Windows Security -> Protection history (it only installs Python
  and one Excel package — nothing harmful).

FIRST USE (2 minutes)
  1. Settings tab -> Salespersons -> type each name -> Add.
     (Categories are pre-loaded: Ladies Ring, Gents Ring, Ladies
     Chain, Gents Chain, Necklace, Earrings, Bangles, Bracelet,
     Pendant, Payal, Nose Pin, Mangalsutra, Other. Add/rename/
     deactivate any of them there.)
  2. Settings tab -> General -> check your showroom name.
  3. Dashboard -> pick Category + Salesperson, type opening
     weight, SAVE BOX OUT. Done — the box is active.

DAILY USE
  Dashboard: today's boxes, opening, sold and remaining totals
  are at the top. Active boxes are listed below.
  Add Sale: select a box -> Add Sale -> type sold weight.
    If the sale is bigger than the remaining weight, the software
    STOPS and asks for an override with a reason. Without a reason
    a negative remaining weight is not allowed.
  Add Stock: select a box -> Add Stock -> type weight added.
  Return Box: select a box -> Return Box -> type actual weight.
  View History: select a box -> View History -> every transaction
    plus the audit trail (corrections and voids).
  Daily Entries: correct or void an entry — a reason is required
    and the old value stays in the audit trail. Nothing is ever
    silently overwritten.
  Reports & History: pick any past date, filter by category /
    salesperson / type, search by Box ID, re-export or open Excel.
  Salesperson Reports: per-day boxes, categories, opening, sold,
    returned, active and remaining per salesperson.
  Backup & Restore: backup runs automatically on every close.
    Backup Now / Restore from Backup are on this tab.

WHERE YOUR DATA LIVES
  Documents\Weighing Scale\
      Database\weighing_scale.db        <- source of truth
      Daily Reports\2026\October\31-10-2026.xlsx
      Backups\Database Backups\weighing_scale_YYYYMMDD_HHMMSS.db
  Change the folder in Settings -> Change Folder (the database
  is copied to the new folder; restart the app after changing).

EXCEL — IMPORTANT
  One Excel file per date, never two. It is regenerated from the
  database on every save, with a gold header, 2-decimal weights,
  a daily summary, category-wise totals and salesperson-wise
  totals, plus a "Boxes Summary" sheet.
  If the Excel file is OPEN when you save, nothing is lost: the
  database save succeeds and the Excel update is QUEUED. Close
  Excel, then Backup tab -> Retry Pending Excel. The dashboard
  header warns you while anything is pending.
  Do not edit the Excel file by hand to fix a mistake — correct
  it in the software (Daily Entries) so the database stays true.

NEW DAY
  On 1 November the dashboard starts fresh and empty, and a new
  01-11-2026.xlsx is created. Yesterday's records are NOT deleted
  — open them any time in Reports & History.

TROUBLESHOOTING
  - App doesn't open: run Weighing-Scale-Debug.bat — it shows the error.
  - "Salesperson list is empty": add names in Settings first.
  - Excel not updating: check the dashboard header for the pending
    warning, close Excel, retry from the Backup tab.
  - Wrong weight entered: Daily Entries -> select it -> Correct
    Entry, with a reason. Do not edit the Excel file directly.

SOURCE FILES IN THIS FOLDER
  app.py           - the desktop interface (all 7 tabs)
  db.py            - SQLite database + weight calculations + audit
  excel_export.py  - daily Excel generation + locked-file queue
  test_all.py      - the 10 acceptance tests (run: python test_all.py)

Built for Ramanand Jewellers. Tested: box 126.44 g - sale 26.44 g = 100.00 g;
close/reopen recovery; new-day freshness with history intact;
return difference; Excel totals; locked-Excel queue with no data loss.

----------------------------------------------------------------
GITHUB AUTO-UPDATE (v1.1, online updates)
----------------------------------------------------------------
  The app checks GitHub on every launch (in the background) for a
  newer version, and also has "Check for Updates" on the Backup tab.
  Update channel (public repo, no login needed to read it):
      github.com/sbhan3967-png/weighing-scale-updates
      version.json  +  Weighing-Scale-Software.zip
  If a newer version is found, the app asks once. On Yes it
  downloads the new zip, installs it over the app folder and
  restarts. Your database, daily Excel files and backups live in
  Documents\Weighing Scale\ — outside the app folder — so updates
  never touch them.
  No internet? The check just finds nothing and the app runs
  normally, offline, as before.
  TO PUSH A NEW VERSION (from the developer side): replace
  Weighing-Scale-Software.zip in that repo and bump "version" in
  version.json. Every PC picks it up on next launch.

APP ICON
  icon.ico is the gold weighing-scale icon: it shows in the app
  window title bar and on the desktop shortcut created by Setup.bat.

----------------------------------------------------------------
WHY THE CMD WINDOW OPENED (v1.0/v1.1) — FIXED IN v1.2
----------------------------------------------------------------
  The old launcher ran the app with python.exe, which is a
  console program: Windows kept its black cmd window open for
  as long as the app ran, and closing that window killed the app.
  v1.2 fixes it two ways:
  1. Weighing-Scale.bat now uses pythonw.exe (windowless Python)
     and exits immediately, so no cmd window stays open.
  2. The desktop shortcut (recreated by Setup.bat) now points to
     Weighing-Scale.vbs, which runs the launcher completely
     hidden — not even a brief cmd flash.
  If you launch Weighing-Scale.bat directly you may still see a
  very brief flash; launch from the desktop icon for none at all.
  Weighing-Scale-Debug.bat still opens a cmd window on purpose,
  so errors are visible when troubleshooting.

----------------------------------------------------------------
SALE PAYMENT DETAILS (v1.3)
----------------------------------------------------------------
  When you Add Sale, the sale window now asks for:
    Mode of Transaction — dropdown: CASH, UPI, CARD, BANK TRANSFER,
      CREDIT / UDHAAR, CHEQUE, OTHER (defaults to CASH, as on the
      old manual sheet)
    Amount (Rs) — typed by you, e.g. 250000
    Bill No./Rokar/Book (BN) — typed by you, e.g. 25150
  Amount and Bill No./Rokar/Book may be left blank if you don't have them yet;
  they are saved with the sale and show in Daily Entries, Reports,
  Box History and the daily Excel file (new Mode / Amount / Bill
  columns), and the daily summary now totals the sale amount in Rs.
  Old databases are upgraded automatically on first launch of v1.3
  — your existing sales simply show blank Mode/Amount/Bill No./Rokar/Book

----------------------------------------------------------------
CLIENT PC INSTALL — WHAT SETUP INSTALLS AUTOMATICALLY (v1.4)
----------------------------------------------------------------
  On a brand-new client PC, the client does NOTHING except:
    1. Extract the zip to a folder.
    2. Double-click Setup.bat once.
    3. Double-click the desktop "Weighing Scale" icon.
  Setup.bat then installs/verifies, in order, with no manual steps:
    a. Python 3.12 — if Python is missing, Setup installs it
       itself (first via winget, else by downloading the official
       Python 3.12 installer from python.org, per-user, no admin).
       It only accepts a Python that actually runs — the Windows
       Microsoft Store stub that says "Python was not found" is
       ignored, and known install folders are searched even if
       Python is not on PATH.
    b. tkinter + sqlite3 — checked (both ship inside Python on
       Windows; if tkinter is missing Setup stops with a clear
       message to reinstall Python with "tcl/tk and IDLE" ticked).
    c. Python packages — openpyxl (for Excel) + its dependency
       et_xmlfile, installed from the wheels/ folder bundled in
       this zip, so packages install EVEN WITHOUT INTERNET.
       If the wheels folder is missing, Setup falls back to
       downloading them online (pip).
    d. App self-check — Setup runs: python app.py --check
       which proves tkinter + sqlite3 + openpyxl + the database
       all work, and prints the version. Setup stops with an
       error instead of claiming success if this fails.
    e. Data folders + desktop shortcut — Documents\Weighing Scale
       (Database / Daily Reports / Backups) is created, and the
       shortcut points to the hidden launcher (no cmd window).
  After Setup, the app works fully OFFLINE. Internet is needed
  only once, and only if Python itself is missing (step a).
  Future updates need NO Setup re-run: the app auto-updates
  from GitHub (see GITHUB AUTO-UPDATE above).
  Files that make this work: Setup.bat, requirements.txt,
  wheels/openpyxl-*.whl, wheels/et_xmlfile-*.whl, app.py --check.

----------------------------------------------------------------
BOX IDENTIFICATION — GOLD OR SILVER (v1.5)
----------------------------------------------------------------
  Every box now carries a Metal identity: GOLD or SILVER.
  Dashboard -> BOX OUT panel has a Metal dropdown (defaults to
  GOLD) next to Category and Salesperson. Pick it when the box
  is taken out — it stays with that box for its whole life.
  Metal shows in: Active Boxes table, Daily Entries, Reports &
  History (with a Metal filter: GOLD / SILVER / all), Box History,
  and the daily Excel file (new Metal column + METAL-WISE TOTALS
  section: boxes, opening, sold, added and remaining per metal).
  Old boxes made before v1.5 show a blank Metal (they were made
  before this field existed); their weights and history are
  unchanged, and the database upgrades automatically.

----------------------------------------------------------------
KEYBOARD-FIRST USE + DASHBOARD COLUMNS (v1.6, customer preference)
----------------------------------------------------------------
  The client barely uses the mouse, so the Dashboard is built
  for the keyboard (mouse still works everywhere):
    Tab / Shift+Tab — move to the next / previous field
    Enter — save (in Box Out, Add Sale, Add Stock, Return,
      Correct and Void windows)
    Esc — close a window without saving
    Up / Down — pick a box in the Active Boxes table
    Enter on a selected box — Add Sale for that box
    S — Add Sale   •   A — Add Stock   •   R — Return Box
    H — View History   •   Alt+1…7 — switch tabs
  Flow with no mouse: open the app (cursor starts on Category),
  Tab through Category -> Salesperson -> Metal -> Opening Weight,
  type, press Enter to save the box, then Up/Down to the box,
  press S, type weight / Mode / Amount / Bill No./Rokar/Book (Tab between
  them), press Enter to save the sale. After a Box Out save the
  cursor returns to Category for the next box.
  DASHBOARD TABLE (like the customer's manual sheet):
    S.No. | Category | Metal | Salesperson | Opening | Sold |
    Return | Sell Amount | Bill No./Rokar/Book | Status | Time
  Changes vs before: Box ID column is HIDDEN (the box id is
  still stored and used internally, just not shown), the
  Remaining column is REMOVED from this table and replaced by
  Return (actual returned weight — blank while the box is still
  out, filled when it comes back), followed by Sell Amount
  (total Rs sold from that box) and Bill No./Rokar/Book (bill numbers from
  its sales, joined with commas). Remaining weight is still
  calculated internally for the overweight check and still
  appears in Box History and in the Excel report — tell us if
  you want it removed there too.

----------------------------------------------------------------
RETURN COLUMN — EMPTY UNTIL THE SCALE WEIGHT IS ENTERED (v1.7)
----------------------------------------------------------------
  Return is NEVER pre-filled — not with 0, not with the expected
  remaining weight. While a box is out, its Return cell is blank.
  When the box comes back, press R on that box, type exactly the
  weight printed by the weighing scale, press Enter — that typed
  weight is what appears in the Return column. The Return window
  no longer shows an "expected remaining" figure, so nothing
  suggests a value to copy.
  Returned boxes now STAY on the Dashboard's "Today's Boxes"
  list for the day (Status shows RETURNED), so the filled Return
  stays visible on the same day's sheet, exactly like the manual
  sheet. Sale / Stock / Return keys work only on ACTIVE boxes;
  trying them on a returned box shows a clear message.

----------------------------------------------------------------
FIX: APP OPENS THEN CLOSES IN A SECOND (v1.8)
----------------------------------------------------------------
  What was happening: under the hidden launcher (pythonw) any
  startup error closed the window with NO error message, so it
  looked like "loading, then closing in a second". The most
  likely triggers were (a) one Dashboard/Reports tab failing
  during startup refresh, which used to kill the whole app, and
  (b) an update prompt 1 second after opening that closed the
  app to apply the update — if the apply step then failed to
  restart it, the user was left with no app at all.
  v1.8 fixes all three, so the app cannot die silently again:
    * refresh_all is guarded tab by tab — a bad tab is logged
      and skipped, the other tabs still load, the app stays open.
    * The app NEVER auto-prompts an update on launch any more.
      If an update is available it only shows a quiet line in
      the header ("Update vX available — open Backup tab").
      Updates are started deliberately from Backup tab →
      Check for Updates.
    * Before an update closes the app, the downloaded zip is
      validated (must contain app.py). A bad zip aborts and
      the current app keeps running instead of closing.
    * The apply batch ALWAYS restarts the app, even if
      extraction fails (and writes update_error.txt then).
    * Any startup crash now writes crash_log.txt in the app
      folder AND shows it in a message box, instead of just
      closing. Send that file if it ever happens again.
    * New Weighing-Scale-Safe.bat: runs "python app.py --safe"
      (no auto-update check, no startup Excel sync). Use it
      first if the normal icon ever fails again.

----------------------------------------------------------------
FIX: DASHBOARD TABLE EMPTY (v1.9) — ROOT CAUSE OF THE CLOSING BUG TOO
----------------------------------------------------------------
  Bug (introduced in v1.6 when Box ID was hidden): the Dashboard
  table insert was written as
      tree.insert("", iid=box_id, end="end", ...)
  but tkinter's Treeview.insert needs the position as the 2nd
  POSITIONAL argument: insert("", "end", iid=box_id, ...).
  Passing end="end" as a keyword threw TypeError on the first
  row, so the Dashboard table stayed empty even though the box
  count, Excel file and Daily Entries all updated correctly —
  and before v1.8's startup guard, that same error closed the
  whole app a second after opening. Fixed in v1.9: the table
  now shows every box for today, with Return / Sell Amount /
  Bill No./Rokar/Book as in v1.6/v1.7, and the v1.8 guards stay in place
  as a safety net.

----------------------------------------------------------------
MANUAL CELL ENTRY — TYPE DIRECTLY IN THE COLUMNS (v1.10)
----------------------------------------------------------------
  Dashboard table, keyboard only, like the manual Excel sheet:
    Up / Down — move row   •   Left / Right — move COLUMN
    Home / End — first / last column
    The selected cell is shown under the table
    ("Selected cell: Row ... • Column: ... • Value: ...").
  MANUALLY TYPE IN THESE COLUMNS (no dialog, no mouse):
    Sold — press Enter / F2 (or just type a number) and type
      a sale weight. Enter saves it as a NEW sale for that box
      (Mode CASH by default; Amount and Bill No./Rokar/Book are then typed
      in their own columns). Esc cancels.
    Sell Amount — type the amount for the box's LATEST sale.
      It shows the latest sale's amount first, so it can be
      corrected in place.
    Bill No./Rokar/Book — type the bill number for the box's LATEST sale.
      (Sell Amount / Bill No./Rokar/Book need a Sold weight first — the
      app will say so if there is no sale yet.)
    Return — type the weighing-scale print weight. Enter
      returns the box with exactly that weight. If it differs
      from expected, a small Reason box appears (required by
      the audit rule) — type the reason, Enter, done.
  After Enter, the cursor moves one column to the right, so
  Sold -> Return -> Sell Amount -> Bill No./Rokar/Book can be filled
  left to right. Other columns (Category, Metal, Salesperson,
  Opening, Status, Time) are NOT typed in directly — press
  Enter on one of those to see that box's History. S / A / R /
  H shortcuts still work on the selected row from any column.
  Overweight: typing a Sold weight above remaining is refused
  with a message (use Add Sale with S for an override reason).

----------------------------------------------------------------
RESET BUTTON (v1.11)
----------------------------------------------------------------
  Dashboard has "Reset Today" (under the boxes table) and Daily
  Entries has "Reset This Date" (for the date shown there).
  What Reset does for THAT date only:
    * Deletes every box for that date, with all its sales,
      stock adds and returns (and their audit rows).
    * Deletes that day's Excel file.
    * Clears that date from the pending-Excel queue.
  What it does NOT do:
    * Other days are NOT touched — their boxes, entries and
      Excel files stay exactly as they are.
  Safety, because Reset cannot be undone by itself:
    * A safety backup of the whole database is made FIRST
      (Backups folder). If Reset was pressed by mistake, go to
      Backup tab → Restore and pick that backup.
    * A confirmation box lists the date, how many boxes will
      be deleted, and the Excel path, and asks "Are you sure?"
    * If that day's Excel file is open/locked, Reset stops
      BEFORE deleting anything and tells you to close Excel
      first, so you never end up with entries deleted but the
      Excel file still there (or vice versa).
  Keyboard: Tab to the Reset button, Enter to press it, then
  Tab / Enter on the confirmation (Yes = first button in the
  dialog on Windows; use Tab to move if needed).

----------------------------------------------------------------
HORIZONTAL SALE ENTRY (v1.12)
----------------------------------------------------------------
  Add Sale is now ONE horizontal row, like Excel, instead of a
  vertical stack of label-over-field:
    Sold (g)  |  Mode  |  Amount (Rs)  |  Bill No./Rokar/Book  |  Remarks
  with those column names as a header row on top.
  Type left to right: Tab or Enter moves Sold -> Mode ->
  Amount -> Bill No./Rokar/Book -> Remarks -> Save. Ctrl+Enter saves
  from any field, Esc cancels. Mode keyboard picks are
  unchanged (1=CASH 2=UPI 3=CARD 4=BANK TRANSFER
  5=CREDIT / UDHAAR 6=CHEQUE 7=OTHER, letter cycles, ↓ opens).
  The Dashboard table's own manual cell entry is unchanged —
  arrow to Sold / Added / Return / Sell Amount / Bill No./Rokar/Book
  and type directly in the cell.

----------------------------------------------------------------
COLOUR WHERE YOU ARE + REMOVED LINES (v1.13)
----------------------------------------------------------------
  Colour, so you can tell at a glance where you are:
    * Selected row in ANY table (Dashboard, Daily, Reports,
      History) is now GOLD, not the plain system blue/grey.
    * The field you are typing in turns PALE YELLOW, and
      back to white when you leave it — in the sale row,
      Box Out, Add Stock / Return, Correct / Void, and the
      Daily date/search boxes. The inline cell Entry over a
      Dashboard cell is pale yellow too.
    * In the horizontal sale row, the HEADER above the field
      you are in turns GOLD (Sold -> Mode -> Amount -> Bill
      No. -> Remarks as you Tab / Enter across), the rest
      stay light. So the column you are in is coloured twice:
      header gold + field pale yellow.
  Removed, as asked:
    * The "(Return stays blank until the box comes back)"
      note under "Today's Boxes" — heading is now just
      "Today's Boxes — active and returned".
    * The Box Out help line "Date & time are taken
      automatically ... Metal is GOLD or SILVER — pick it
      here, it stays with the box." — the Box Out row itself
      is unchanged.

----------------------------------------------------------------
CELL COLOUR ACROSS COLUMNS + FIRST-LETTER DROPDOWN (v1.14)
----------------------------------------------------------------
  1) Cell colour across columns: the table itself can only
     colour a whole ROW, which is why moving Left/Right in
     the same row showed no colour change — the row stayed
     gold, the column did not. Fixed with a gold cell overlay:
     a gold box now sits exactly on the cell you are on and
     moves with you, Left/Right across columns in the same
     row as well as Up/Down across rows, showing that cell's
     value in bold. It hides while an inline edit Entry is
     open (that Entry is pale yellow instead) and comes back
     when editing ends, and it repositions after a mouse-
     wheel scroll.
  2) Box Out Category / Salesperson — type the first letter:
     both boxes are now typeable (they were read-only before,
     so typing did nothing). Type L and the box fills with
     the first L item (LADIES CHAIN; keep typing LADIES R
     for LADIES RING), type P and it shows PAYAL, type R in
     Salesperson and it shows Rahul. The dropdown arrow is
     still there — click it, or press Down — and it then
     shows only the matching items; clearing the box brings
     the full list back. A name that is not in the list is
     left as typed, and Save will say it is not found
     (add it in Settings first). Enter still saves the box.

----------------------------------------------------------------
VERSION ALWAYS VISIBLE (v1.15)
----------------------------------------------------------------
  You could not SEE which version you were on — the title
  bar had no version at all, so "am I on v14?" had no answer
  on screen. Fixed: the title bar now reads
  "Weighing Scale v1.15 — Ramanand Jewellers" and the header
  next to the showroom name shows "Version v1.15" permanently
  (it is never cleared by a refresh, unlike the update /
  Excel-pending line). Backup tab → Check for Updates also
  still tells you your current version in its message.
  v1.15 contains everything in v1.14 (gold cell moving
  column to column, first-letter Category/Salesperson
  autocomplete) plus this visibility fix.

----------------------------------------------------------------
RETURN FIRST, THEN SELL (v1.16)
----------------------------------------------------------------
  Return Box now works return-first, then sell:
    * Type the weighing-scale print weight as before.
    * If the box comes back LIGHTER than expected, the
      Sale panel opens AUTOMATICALLY, with the missing
      weight already written in Sold. Example: opening
      400 g, return 300 g -> Sold opens at 100.00 g.
      You only fill Mode / Amount / Bill No./Rokar/Book and save.
    * The sale is saved BEFORE the box closes, so after
      it the expected weight matches the returned weight
      exactly and the box closes with difference 0
      (400 - 100 sale = 300 expected = 300 return).
    * If you cancel the Sale panel, the old flow applies:
      the box returns with the difference noted, and a
      reason is required, as before.
    * A box that comes back HEAVIER than expected never
      opens the Sale panel — extra weight is not a sale —
      it returns with a reason, as before.
    * With a prior sale it works the same way on the
      remaining difference: opening 400, sold 50, return
      300 -> Sale panel opens at 50.00 g.
  Note: this auto-Sale applies to the Return Box button.
  Typing a Return directly in the Dashboard table still
  asks for a reason when it differs, as before.

----------------------------------------------------------------
RETURN -> SELL NOTIFICATION (v1.17)
----------------------------------------------------------------
  Between Return and Sell there is now a notification, so
  the Sale panel does not just pop open unannounced:
    "Weight difference: 100.00 g
     Opening: 400.00 g  •  Expected: 400.00 g  •  Returned: 300.00 g
     Do you want to go to the Sell panel to record this
     100.00 g as a sale?"
    [Yes — Go to Sell panel]   [No — Return with reason]
  Press ENTER (or click Yes) and the Sale panel opens with
  the difference already in Sold, exactly as in v1.16.
  Press ESC (or click No) and the box returns with the
  difference noted, with a reason required, as before.
  The notification is a custom dialog (not a plain system
  popup) so Enter is guaranteed to mean Yes.

----------------------------------------------------------------
BOX OUT HORIZONTAL SCROLLING (v1.18)
----------------------------------------------------------------
  The Box Out row (Category + Salesperson + Metal +
  Opening Weight + Save) is about 1330 px wide, wider than
  the 1180 px window, so the Save button used to fall off
  the right edge with no way to reach it. Now the Box Out
  panel has a horizontal scrollbar underneath it: drag it,
  or just Tab / click to any field, and the panel scrolls
  that field (including the Save button) into view
  automatically. The Dashboard table itself stretches to
  the window width, so it did not need a scrollbar.

----------------------------------------------------------------
v1.19 — KEYBOARD SHORTCUTS, 4-DECIMAL WEIGHTS, ATTENDANCE
----------------------------------------------------------------
  KEYBOARD
  - B (with the Dashboard table selected) = jump to Box
    Category in the Box Out panel and open its list.
  - Space (in a Box Out field, when that field already
    holds a complete value) = jump to the table, last box
    selected. A half-typed name (e.g. "LADIES" on the way
    to "LADIES RING") still gets its space, so typing is
    not broken.
  - Sale panel: Enter now goes Sold -> Amount -> Bill No./Rokar/Book
    -> Remarks -> Save, skipping Mode (Mode stays CASH
    unless you Tab to it). A sale opened from Return
    (weight already written) opens directly on Amount.
    Saving a sale with no weight now warns instead of
    silently doing nothing.
  4-DECIMAL WEIGHTS (Mettler print)
  - Every weight in the app is now stored and shown to
    4 decimals, exactly as a Mettler scale prints it:
    Box Out, Return, Sold, Added, tables, messages and
    Excel (Excel weight columns use 0.0000). Rs amounts
    stay at 2 decimals. Old weights show trailing zeros
    (100.0000) — same weight, just 4-decimal display.
    The Return difference threshold is now 0.0001 g.
  ATTENDANCE (new tab, Alt+7)
  - Separate panel for salespersons: pick a date, mark
    PRESENT / ABSENT / LEAVE / HALF DAY, optional In and
    Out times (HH:MM, e.g. 10:00) and remarks. One record
    per person per day — marking again updates that day,
    it never duplicates. The table shows every active
    salesperson, marked or not, with a summary (Present /
    Absent / Leave / Half Day / Unmarked). Click a row to
    load it into the form and correct it. After Save, the
    form moves to the next unmarked person automatically.

----------------------------------------------------------------
v1.20 — LIVE MCX RATES BANNER (mcxlive.org)
----------------------------------------------------------------
  A black-and-gold banner scrolls across the top of the
  Dashboard: MCX Gold and MCX Silver from mcxlive.org,
  refreshed every 60 seconds in the background (never
  blocking the app). Example: "MCX GOLD (04 Dec 2026)
  ₹1,38,419 / 10 g ▼ -66 (-0.05%) • MCX SILVER
  ₹1,78,900 / 1 kg ▼ -232 (-0.13%) • Last trade
  30 Oct 23:29 PM • Site updated … • Source:
  mcxlive.org". Gold is per 10 g, silver per 1 kg, as
  MCX quotes them. Buttons on the banner: ↻ Refresh
  (fetch now) and ⏸ Pause / ▶ Resume (stops the scroll
  and the fetching). If the internet or the site is down,
  the last good rate stays up marked OFFLINE; if the
  site's page layout changes, the banner keeps the last
  rate instead of showing a wrong number.
  HONEST LIMIT: mcxlive.org has no public per-minute
  API — the app fetches its gold and silver pages every
  minute and shows the site's latest Last Trade table.
  The banner always shows the site's own "As on" time
  and last-trade time, so when the market is closed
  (weekends, holidays) you see the last close, not a
  fake live price.

----------------------------------------------------------------
v1.21 — SIMPLER LIVE RATES BANNER
----------------------------------------------------------------
  Refresh and Pause buttons removed from the banner.
  The scrolling text is now gold and silver only, no
  dates and no extra text, e.g.: "MCX GOLD ₹1,38,419 /
  10 g ▼ -66 (-0.05%) • MCX SILVER ₹1,78,900 / 1 kg
  ▼ -232 (-0.13%)". The small LIVE / OFFLINE label at
  the right edge stays, so you can still see at a glance
  whether the rate is live or the last rate held while
  offline. Fetching still runs automatically every 60
  seconds in the background — no button press needed.

----------------------------------------------------------------
v1.22 — SOLD COLUMN GREEN ONLY WHEN SOLD
----------------------------------------------------------------
  The Sold column entry in the Dashboard table turns
  GREEN only when that box has actually sold weight.
  Only the Sold entry is green — the rest of the row
  stays the normal gold selection. If Opening weight =
  Returned weight, the Sold entry is NOT highlighted
  green (a box returned whole, even if stock was added
  and sold in equal amounts, counts as not sold by
  that rule). Clicking a green Sold entry selects that
  box and moves the cell cursor onto Sold. The green
  labels reposition on scroll and window resize, so
  they never go stale.

----------------------------------------------------------------
v1.23 — BILL NO. RENAMED TO BILL NO./ROKAR/BOOK
----------------------------------------------------------------
  Everywhere the column used to read "Bill No." it now
  reads "Bill No./Rokar/Book" — Dashboard, Daily Entries,
  Reports & History, box History, the Add Sale panel
  header, the selected-cell line, and the Excel export
  header. The column is wider so the full name fits.
  Nothing else changed: it still holds the same bill /
  rokar / book number, and inline editing on that
  column works exactly as before (the internal name
  was left alone on purpose, so no editing logic broke).

----------------------------------------------------------------
v1.24 — SPACE ALWAYS JUMPS TO THE TABLE
----------------------------------------------------------------
  Space in a Box Out field now ALWAYS jumps to the
  Dashboard table (last box selected) — not Enter
  (Enter saves the box). The old v1.19 rule, where
  Space only jumped when the field already held a
  complete value, is removed: whenever you want the
  table, Space gets you there, whatever is in the
  field. Shift+Space still types a real space, for
  the rare case a name itself needs one (picking a
  name from the dropdown is the normal way to get
  "LADIES RING" and other multi-word names).

----------------------------------------------------------------
v1.25 — WEIGHT NUMBERS ONLY + SCROLLABLE SHORTCUTS HELP
----------------------------------------------------------------
  WEIGHT NUMBERS ONLY: every weight field now takes
  numbers only as you type — digits and one decimal
  point. Letters, spaces, minus signs and a second
  decimal point are blocked and simply never appear,
  instead of failing on Save. Covered: Box Out
  Opening Weight, Dashboard Sold / Added / Return
  cells (and Sell Amount, also a number), Add Sale
  Sold weight and Amount, Add Stock / Return weight
  dialogs, and Correct Entry weight. Bill No./Rokar/
  Book is left free on purpose — bill numbers can
  contain letters.
  SCROLLABLE SHORTCUTS HELP: the Dashboard page
  itself is now scrollable (mouse wheel anywhere on
  the page, or drag the right scrollbar), because
  its total height used to exceed the window and
  squeeze the bottom help to 1 pixel, so it could
  not be read or scrolled. The keyboard shortcuts
  are also now one line each in a small box with its
  own scrollbar — scroll inside that box to read
  them all. Wheel over the table still scrolls the
  table, wheel over the shortcuts box still scrolls
  that box; wheel elsewhere scrolls the page.

----------------------------------------------------------------
v1.26 — STARTUP CRASH NOW VISIBLE (NOT SILENT UNDER pythonw)
----------------------------------------------------------------
  The old Treeview.insert() "missing index" error from the
  old crash log is ALREADY fixed (v1.9) — every insert()
  in this version uses ("", "end", ...) correctly, and
  that fix was NOT repeated. The actual current silent-
  crash path was different: import failures and database
  initialisation failures happen BEFORE the old crash
  handler, so under pythonw.exe (no console) the app
  just closed with no crash_log and no dialog.
  Fixed in app.py only:
    - A startup-failure helper, defined before any
      risky import, writes a FRESH timestamped
      crash_log.txt first, then shows a clear error
      dialog (tkinter, else Windows MessageBox via
      ctypes, else stderr), then exits.
    - All risky imports are now inside a try that
      calls that helper on failure.
    - Database creation is guarded the same way:
      on failure it logs + shows the dialog with
      the exact database path tried, and exits
      WITHOUT creating a new database, WITHOUT
      switching paths, and WITHOUT deleting,
      replacing or moving any existing database
      or Excel file. If the error is "unable to
      open database file", check that this Windows
      user can WRITE to the Database folder shown
      in the dialog / log.
    - write_crash_log() no longer fails when the
      database did not initialise (it used to touch
      DB.db_path and could leave the log empty).
    - Dashboard refresh was already guarded per
      tab (v1.8) and needs no change: a refresh
      error is logged, other tabs still load.
  Verified here: safe-mode launch opens the window
  (no crash_log, process stays running); a forced
  database failure (base path set to a file) writes
  a fresh timestamped crash_log with the full
  traceback and the database path tried, and leaves
  the existing file untouched.

----------------------------------------------------------------
v1.27 — AUTO-RETURN ON WEIGHT DIFFERENCE, AUTO REMARKS
----------------------------------------------------------------
  A Mettler scale can show 0.0100 g (10 mili) or more
  difference, often returned MORE than expected, and
  the old rule blocked that return until a reason was
  typed. Now the box returns automatically, with
  remarks of the difference added automatically:
    - Heavier return (e.g. expected 100.0000 g,
      returned 100.0100 g): no Sale panel, no manual
      reason, box closes at once with auto remarks
      "Auto: scale difference +0.0100 g — returned
      100.0100 g vs expected 100.0000 g (returned
      more than expected)".
    - Lighter return, user clicks No on "go to Sell
      panel?": box also returns at once, done, with
      auto remarks "Auto: difference -10.0000 g —
      returned 90.0000 g vs expected 100.0000 g
      (returned less than expected, no sale
      recorded)".
    - If you DO type your own remarks in the Return
      dialog, those are kept, never overwritten.
    - Difference 0 needs no remarks, as before.
  The final message still shows the difference, and
  the difference + auto remarks are recorded in the
  report / Excel, so nothing is hidden. Clicking
  Yes and recording the sale is unchanged: the sale
  is saved first, then the box closes with
  difference 0.

----------------------------------------------------------------
v1.28 — LATEST PYTHON (3.15) SUPPORT, NO INTERPRETER MISMATCH
----------------------------------------------------------------
  "Installed latest Python, now it crashes after the
  update" — the app's own code uses no Python 3.15
  removed API (sqlite3.connect passes check_same_
  thread as a keyword, all strptime formats include
  a year, no glob0/glob1/is_reserved/etc.), so the
  crash is not the language version itself. It is
  the interpreter mismatch: a new Python is a fresh
  environment with no openpyxl, and the old scripts
  did not even list Python 3.15 (released 9 Oct
  2026), while Debug/Safe used bare `python`
  (PATH order, usually the newest install) and the
  desktop icon used a 312-first order — so Setup,
  the icon and diagnostics could run three different
  interpreters, only one of which had openpyxl.
  Fixed in the .bat files only (no app code change):
    - Setup.bat and Weighing-Scale.bat (launcher)
      now list Python315 in the same 312, 313, 314,
      315 order, in user, Program Files and C:\
      locations, so a PC with only 3.15 is found
      explicitly and Setup installs openpyxl for it.
    - Weighing-Scale-Debug.bat and Weighing-
      Scale-Safe.bat now use that SAME finder
      (and print the Python version first) instead
      of bare `python`, so diagnostics and safe
      mode run the same interpreter as the icon.
  On the client PC: extract v1.28, run its
  Setup.bat once (it installs openpyxl for
  whichever Python it finds, and step [1/5]
  shows that version), then use the desktop icon
  as normal. If it still fails, v1.26+ shows a
  dialog and a fresh crash_log.txt — send that.

----------------------------------------------------------------
v1.29 — RUNS ON ANY PYTHON 3.8+ (VERSION-AGNOSTIC LAUNCHER)
----------------------------------------------------------------
  Yes, it can run on every Python version — with
  two real limits, not a version list:
    (1) Python 3.8 or newer only: openpyxl 3.1.5
        requires >=3.8, and Python 2 / 3.7 and
        older cannot run it. The app code itself
        uses only stdlib + openpyxl, no version-
        specific syntax, so 3.8 through 3.15 all
        work, and a future 3.16+ works as soon as
        Setup is run once on it (it cannot be
        guaranteed before that version exists).
    (2) That Python must have tkinter (python.org
        installer includes it by default) and
        openpyxl installed FOR THAT interpreter —
        packages are per-Python, never shared
        between installed Pythons.
  How v1.29 makes that true, in the .bat files
  only (no app code change):
    - Setup.bat, after its tkinter check, writes
      the exact interpreter it found into
      python_used.txt next to app.py ("Launcher
      locked to this Python: ...").
    - Weighing-Scale.bat (icon), Debug and Safe
      all use that locked Python FIRST. A later
      Python install can no longer silently switch
      the icon to a fresh interpreter with no
      openpyxl — installing a new Python alone
      now changes nothing. Re-running Setup
      re-locks to the new Python.
    - If the locked Python was uninstalled, the
      launcher falls through to the normal search
      (312–315 paths, then py -3w / py -3, then
      PATH), so a PC with only a future version
      still works via the py launcher once Setup
      has installed openpyxl for it.
    - python_used.txt is NOT in the zip and
      survives in-app updates (the updater
      overwrites zip files only, it never deletes
      extra files in the app folder), so updating
      does not unlock the Python.
  On a client PC: extract v1.29, run its Setup.bat
  once, then use the desktop icon — whatever
  Python that PC has (3.8+) becomes the locked
  one, and later Python installs will not break it.

================================================================
v1.30 — Edit a past sale, split payment, great Category search,
        Mettler Opening Weight with Enter (no mouse)
================================================================
  (1) EDIT A PAST SALE. Sold 2 gm in Cash 10 minutes ago and
      want to change the mode, amount, weight or bill no.?
      Dashboard: select the box, press E or click Edit Last
      Sale (edits that box's latest sale). Daily Entries:
      pick the date, select the exact sale row, press E or
      click Edit Sale (edits a sale from any past date).
      Old values are NOT deleted — they stay in the audit
      trail (SALE_EDIT, old -> new). On an active box the new
      weight must still fit in remaining + old weight; on a
      returned box the difference is recomputed.
  (2) SPLIT PAYMENT WHILE SELLING. In the Add Sale / Edit
      Sale box, tick "Split payment", pick Mode 2 (e.g. UPI)
      and enter Part 2 amount. Main Mode = Mode 1, main
      Amount = TOTAL, Part 1 = Total - Part 2, shown live.
      Example: 2 gm, Total Rs 100000, Part 2 UPI Rs 40000
      = Cash Rs 60000 + UPI Rs 40000, saved as CASH+UPI.
      If the split is wrong (Part 2 missing, >= Total, or
      Mode 2 = Mode 1) the split line turns RED and BLINKS
      until you fix it, and Save is blocked. Excel shows
      the split in Remarks ("Split: CASH Rs 60000.00 +
      UPI Rs 40000.00") and the total is counted once only.
      Unticking Split turns a split sale back to a single
      mode and clears the split rows.
  (3) GREAT BOX CATEGORY SEARCH (also Salesperson). Type
      ANY part of a name, not just the start: RING finds
      LADIES RING + GENTS RING (rings first, EARRINGS last),
      CHAIN finds LADIES CHAIN + GENTS CHAIN, LAD RING
      finds LADIES RING. A popup below the box shows the
      ranked matches + count: Down/Up to pick, Enter to
      select, Esc to close, click a row to pick, B = open
      the list. Typing is never auto-filled, so what you
      typed stays exactly as typed until you pick.
      SPACE fix: while you are searching (text typed),
      Space types a real space, so LADIES RING can be
      typed in full; when the field is empty, Space still
      jumps to the table as before. Shift+Space also types
      a space, as before.
  (4) METTLER OPENING WEIGHT — ENTER SAVES, NO MOUSE.
      After a box is saved there is NO popup to dismiss
      (no OK button to click) and focus goes straight
      back to Opening Weight, with Category / Salesperson
      / Metal kept as-is. So for the next box of the same
      category: weigh (scale prints), type the weight,
      press Enter, saved, repeat — no mouse to the Save
      button, no mouse to dismiss anything. The green
      status line under Box Out confirms each save.
      Shift+Tab goes back to change Category /
      Salesperson / Metal for a different box.
  (5) BUG FIX — typed numbers in weight fields. The
      numbers-only check in v1.25 had a wrong method
      signature, so typed digits in weight fields could
      be rejected on some systems. Fixed in v1.30:
      digits and one decimal point type normally,
      letters/spaces are still blocked.
  On a client PC: extract v1.30, run its Setup.bat once
  if this is a fresh folder, or use the in-app update
  (Backup tab -> Check for Updates) if v1.29 is already
  installed — data in Documents\Weighing Scale is never
  touched by an update. Do NOT delete Documents\
  Weighing Scale.

================================================================
v1.31 — Dropdown-based search for Box Category + Salesperson
================================================================
  v1.30 replaced the Category/Salesperson dropdowns with a
  separate popup list. v1.31 puts the DROPDOWN back, with the
  same great search inside it:
  - The field is a normal dropdown again, with its ▼ arrow.
    Click the arrow, or press Down, or press B, to drop the
    list down.
  - Type any part first — RING, CHAIN, LAD RING — and the
    dropdown list itself is filtered to the ranked matches
    (rings first, EARRINGS last for RING). Then drop it down
    and pick with the mouse, Down, or Enter.
  - Typing is never auto-filled, so what you typed stays
    exactly as typed until you pick.
  - Why the list is not auto-opened while you type: a
    native dropdown moves focus to its own list when it
    opens, so auto-opening would stop you typing the next
    letter. Type first, then drop down to pick — that is
    how a dropdown search works.
  - Space still types a real space while searching, and
    jumps to the table only when the field is empty.
  - Same dropdown search on the Attendance tab's
    Salesperson field.
  Everything from v1.30 is still in: Edit Sale (E),
  Split Payment with red-blinking bad-split warning,
  Mettler Opening Weight Enter-to-save with no popup and
  focus staying on Opening Weight, and the typed-numbers
  fix. Update via Backup tab -> Check for Updates, or
  extract the zip over the old folder. Data in
  Documents\Weighing Scale is never touched.

---
v1.32 — ACTIVE blinking red, vertical payment column with auto total, Box Out Enter movement, dropdown auto
- ACTIVE box rows in Today's Boxes now BLINK RED (bright red / normal, every half second). RETURNED rows never blink. (This was the correct target — v1.30's red blink was only on a bad split warning, not on ACTIVE.)
- Sale panel payment is now a VERTICAL COLUMN listing all modes (Cash, UPI, Card, Bank Transfer, Credit / Udhaar, Cheque, Other), each with its own amount entry. Enter an amount against each mode you used (e.g. Cash 60000 + UPI 40000) and the Amount total above auto-fills with the sum (100000). One mode = single sale, two or more = split sale (CASH+UPI) — no Mode dropdown, no Split checkbox any more. Edit Sale prefills the mode amounts back.
- Box Out Enter movement: Enter moves Category → Salesperson → Metal → Opening Weight, and only Enter in Opening Weight saves the box. No need to use Tab. (Tab still works.)
- Category / Salesperson DROPDOWN AUTO: type a letter and the dropdown drops down BY ITSELF — type G, it shows all categories starting with G (GENTS CHAIN + GENTS RING), same for salesperson. Pick with mouse / Down / Enter. If there is no prefix match, it falls back to word/substring search (RING still finds LADIES RING + GENTS RING). Esc closes the list, then type a further letter to re-filter.
- To update: Backup tab → Check for Updates, or extract this zip over the old folder. Your data in Documents\Weighing Scale is untouched.

---
v1.33 — Live MCX rates fix (OFFLINE bug)
- Fixed the live-rate banner showing OFFLINE even with internet. Cause: when gold/silver go UP, mcxlive.org shows the change with a '+' sign (+292, +0.21%), and the rate parser only accepted a '-' sign, so the whole parse failed and the banner fell back to OFFLINE. Sunday's rates were down (-66, -0.05%), so it worked then; Monday's rates are up, so it broke.
- The parser now accepts '+' as well as '-' for Change and Change in %. Live check after the fix: Gold ₹1,38,723 ▲ +238 (+0.17%), Silver ₹1,81,000 ▲ +1,868 (+1.04%).
- Nothing else changed in v1.33. To update: extract this zip over the old folder (your data in Documents\Weighing Scale is untouched), or Backup tab → Check for Updates once your app can reach the channel.

---
v1.34 — Monthly attendance showcase
- Yes, attendance was already stored — one record per salesperson per date in the same database (Backup restores it too). What was missing was a monthly view: the Attendance tab only showed one day at a time.
- New MONTHLY ATTENDANCE SHOWCASE in the Attendance tab, below the daily table: pick Month + Year, Show Monthly — one row per salesperson, one column per day of the month (P = Present, A = Absent, L = Leave, H = Half Day, blank = not marked that day), with Present / Absent / Leave / Half Day / Marked totals per person, and a month total at the top. Blank days are never counted as absent.
- Export Monthly Excel saves the same monthly grid (with the same P/A/L/H colours) as Attendance-Month-Year.xlsx alongside your daily reports, so you can print or share a month at a glance.
- To update: extract this zip over the old folder (your data in Documents\Weighing Scale is untouched), or Backup tab → Check for Updates once your app can reach the channel.

---
v1.35 — Metal buttons, silver carry-forward, 3 decimals, B fix
- Metal is now BUTTONS in Box Out, not a dropdown: click GOLD or SILVER. The selected button is gold, the other is plain. Default GOLD, and the choice stays for the next box.
- GOLD dashboard is unchanged. SILVER is different, as asked: an ACTIVE silver box shows its REMAINING weight in the Return / Remaining column (instead of a return weight), sales show in Sold as usual, and next morning yesterday's remaining automatically becomes today's opening — the old silver box closes at its remaining (difference 0) and a new silver box opens today for the same category + salesperson. Starting the app twice never duplicates this. Gold boxes are never carried forward.
- Every weight figure is now 3 decimals (100.000 g, not 100.0000 g), in the tables, in messages, and in Excel. Amounts in Rs stay at 2 decimals.
- B key fix: B from the table only puts focus IN the Box Category input box — it does NOT open the dropdown any more. Type an alphabet after that and the dropdown fetches by itself, as in v1.32.
- To update: extract this zip over the old folder (your data in Documents\Weighing Scale is untouched), or Backup tab → Check for Updates once your app can reach the channel.

---
v1.36 — Check for Updates tells the truth (updater fix only)
- Fixes the exact problem you just reported: the old Check for Updates showed "Up to date" even when the check itself failed (no internet for Python, firewall blocking Python, or a slow server timing out). That hid every new version on a PC that could not reach the server.
- Now: Backup tab → Check for Updates gives three honest answers — "Update available" if there is one, "Up to date" only if the server actually answered and there is nothing newer, and "Could not reach update server" with the reason if the check failed. The reason is also saved in update_check_error.txt in the app folder, so you can report it exactly.
- Also: the check now waits up to 20 seconds (was 8) and tries a second GitHub address if the first one fails.
- Everything from v1.35 is included (metal buttons, silver carry-forward, 3 decimals, B fix). Nothing else changes.
- Install this zip once by hand (extract over the old folder) — v1.31's old check cannot fetch v1.36 by itself if it cannot reach the server. After this one manual install, Check for Updates should work honestly from then on.

---
v1.37 — Smart Box Category autocomplete + Dashboard metal filter
- Box Category autocomplete, as specified: press B from the Dashboard table to focus Box Category (B works only from the table, so it never steals focus while you are typing in another input). Type a letter and the dropdown drops down by itself with only categories starting with that letter, case-insensitive (G shows GENTS + GOLD, S shows SILVER, etc.), fetched from your existing categories in the database — no new categories are created, no other feature changes.
- Arrow Down/Up move in the dropdown, Enter selects, Escape closes. After a category is selected, pressing Enter again moves on in the form (Category -> Salesperson -> Opening Weight -> Save).
- If nothing matches, the dropdown shows "No matching categories found". Picking that message clears the field instead of filling it with that text.
- Note on the spec's React wording: this software is Python/tkinter, not React, so there is no React ref or browser preventDefault to add — the tkinter equivalent (focus_set() for focus, native Combobox keys for navigation) is what was built and tested.
- Dashboard metal filter: above Today's Boxes, ALL / GOLD / SILVER buttons filter only the table rows — GOLD shows only gold boxes, SILVER shows only silver boxes. This is separate from the Box Out GOLD/SILVER buttons, which choose the metal for a new box.
- Silver daily + gold clean slate (already in v1.35, included here): silver boxes carry yesterday's remaining to today's opening automatically; gold boxes never carry and start clean every day.
- To update: extract this zip over the old folder (your data in Documents\Weighing Scale is untouched), or Backup tab → Check for Updates (v1.36+ tells the truth if the check fails).

---
v1.38 — Backspace works while the dropdown is open
- Fixes the exact bug you just reported: press B, type F, the dropdown opens and focus moves to its list, so Backspace went to the list and F could not be deleted without the mouse.
- Now: while the dropdown is open, Backspace (and Delete) close the dropdown, put focus back in the Box Category input, delete the last typed letter, and re-filter. If you delete the last letter, the dropdown stays closed and focus stays in the input, so you can type again straight away — no mouse needed.
- Bonus from the same fix: typing a second letter while the dropdown is open now also goes back to the input and re-filters (before, only the first letter worked). Arrow Down/Up, Enter to select, and Escape to close still work in the dropdown exactly as before, and normal Backspace in the input still deletes exactly once.
- Everything from v1.37 is included (smart autocomplete, metal filter, silver daily carry-forward, gold clean slate, 3 decimals).
- To update: extract this zip over the old folder (your data in Documents\Weighing Scale is untouched), or Backup tab → Check for Updates.

---
v1.39 — Edit Box / Delete Box + Metal dropdown + Payment mode totals in Excel
- Edit Box: select a box row in Today's Boxes, press Ctrl+E (or the Edit Box button). Change Category, Salesperson, or Metal any time — those are labels and never change a weight total. Opening Weight can be changed only on a fresh box with no sales and no stock adds yet (the usual typo case); on a box with entries, or a returned box, Opening is locked and a note explains why. Every change is kept in the audit trail (View History shows BOX_EDIT, old -> new).
- Delete Box: select a box row, press Delete (or the Delete Box button). Only a freshly created box with no sales, stock adds, or return can be deleted — a box with real entries is refused, so sales history can never be erased this way (use Return, or Void / Correct its entries instead). A safety backup is made first, then the one box row, its transactions, and its audit rows are deleted, and the day's Excel is re-synced. Other boxes and other days are NOT touched. This replaces having to Reset Today (which deleted the whole day) just to remove one mistaken box.
- Metal is a dropdown again in Box Out, like Category and Salesperson, as asked: click the arrow to see GOLD / SILVER, or type G for GOLD, S for SILVER, arrows / Enter to pick, Escape to close, Backspace while the dropdown is open goes back to the input. Enter still moves Category -> Salesperson -> Metal -> Opening Weight -> Save. The Dashboard ALL / GOLD / SILVER filter buttons above Today's Boxes stay as they are — they filter the table only, they are a different control from the Box Out metal choice.
- Excel report, payment mode totals: below the Daily Summary, a new PAYMENT MODE TOTALS section shows how much of the day's sale amount came in as CASH, UPI, CARD, BANK TRANSFER, CREDIT / UDHAAR, CHEQUE, or OTHER, with each mode's share of the day's sales, and a TOTAL row. Split sales are broken down by their actual splits (a CASH 60000 + UPI 40000 sale adds 60000 to CASH and 40000 to UPI, never double-counted), voided sales are excluded, so the TOTAL always equals "Total Sale Amount (Rs)" in the Daily Summary above it. On a day with no sales it says "No sales recorded today." instead of an empty table.
- Everything from v1.38 is included (Backspace in dropdown, smart autocomplete, metal filter, silver daily carry-forward, gold clean slate, 3 decimals).
- To update: extract this zip over the old folder (your data in Documents\Weighing Scale is untouched), or Backup tab -> Check for Updates.

---
v1.40 — Update check can no longer be hidden by a stale cache (updater fix only)
- Fixes the exact problem you just reported in v1.38: Check for Updates said "latest" even though v1.39 was already live. Cause: the old check stopped at the first address that answered, and GitHub's cache on your connection was still serving the old 1.38 version file, so the app never tried the other addresses.
- Now: Check for Updates tries three addresses for the same version file (raw GitHub, github.com raw, and jsDelivr — three different caches) and takes the NEWEST version any of them reports. Only if none of them answer does it say "Could not reach update server".
- Everything from v1.39 is included (Edit Box / Delete Box, metal dropdown, Excel payment mode totals).
- Note: this fix only helps once v1.40 itself is installed, so install this zip once by hand (extract over the old folder) — your v1.38 check uses the old one-address logic and can still be fooled by a stale cache. After this one manual install, future update checks use all three addresses.
- To update: extract this zip over the old folder (your data in Documents\Weighing Scale is untouched), or Backup tab -> Check for Updates.
