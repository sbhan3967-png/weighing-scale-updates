================================================================
 WEIGHING SCALE — Jewellery Box Management & Daily Weighing
================================================================
Offline Windows desktop software. No internet needed after setup.
No cloud, no login. Your data stays on your own computer.

WHAT IT DOES
  Morning: pick a Box Category + Salesperson, type the opening
  weight from the scale, SAVE BOX OUT. A Box ID is generated
  automatically, e.g. BOX-20261031-001.
  During the day: select the active box and Add Sale / Add Stock.
  Remaining weight updates instantly:
      Remaining = Opening + Stock Added - Sold
  Evening: select the box, Return Box, type the actual weight
  from the scale. The software shows Expected vs Actual and the
  Difference, and asks for an explanation if they differ.
  Every save writes to SQLite immediately AND updates that day's
  Excel file. Close the laptop, reopen later — everything is back.

INSTALL (one time, needs internet for Python/packages only)
  1. Extract the FULL zip to a folder (e.g. Documents\Weighing-Scale).
     Do not run Setup from inside the zip.
  2. Double-click Setup.bat and wait. If Python is missing it
     installs Python 3.12 by itself, installs openpyxl, and puts a
     "Weighing Scale" icon on your desktop.
  3. Double-click the desktop icon to start.
  NOTE: if your antivirus quarantines Setup.bat, restore it from
  Windows Security -> Protection history (it only installs Python
  and one Excel package — nothing harmful).

FIRST USE (2 minutes)
  1. Settings tab -> Salespersons -> type each name -> Add.
     (Categories are pre-loaded: Ladies Ring, Gents Ring, Ladies
     Chain, Gents Chain, Necklace, Earrings, Bangles, Bracelet,
     Pendant, Payal, Nose Pin, Mangalsutra, Other. Add/rename/
     deactivate any of them there.)
  2. Settings tab -> General -> check your showroom name.
  3. Dashboard -> pick Category + Salesperson, type opening
     weight, SAVE BOX OUT. Done — the box is active.

DAILY USE
  Dashboard: today's boxes, opening, sold and remaining totals
  are at the top. Active boxes are listed below.
  Add Sale: select a box -> Add Sale -> type sold weight.
    If the sale is bigger than the remaining weight, the software
    STOPS and asks for an override with a reason. Without a reason
    a negative remaining weight is not allowed.
  Add Stock: select a box -> Add Stock -> type weight added.
  Return Box: select a box -> Return Box -> type actual weight.
  View History: select a box -> View History -> every transaction
    plus the audit trail (corrections and voids).
  Daily Entries: correct or void an entry — a reason is required
    and the old value stays in the audit trail. Nothing is ever
    silently overwritten.
  Reports & History: pick any past date, filter by category /
    salesperson / type, search by Box ID, re-export or open Excel.
  Salesperson Reports: per-day boxes, categories, opening, sold,
    returned, active and remaining per salesperson.
  Backup & Restore: backup runs automatically on every close.
    Backup Now / Restore from Backup are on this tab.

WHERE YOUR DATA LIVES
  Documents\Weighing Scale\
      Database\weighing_scale.db        <- source of truth
      Daily Reports\2026\October\31-10-2026.xlsx
      Backups\Database Backups\weighing_scale_YYYYMMDD_HHMMSS.db
  Change the folder in Settings -> Change Folder (the database
  is copied to the new folder; restart the app after changing).

EXCEL — IMPORTANT
  One Excel file per date, never two. It is regenerated from the
  database on every save, with a gold header, 2-decimal weights,
  a daily summary, category-wise totals and salesperson-wise
  totals, plus a "Boxes Summary" sheet.
  If the Excel file is OPEN when you save, nothing is lost: the
  database save succeeds and the Excel update is QUEUED. Close
  Excel, then Backup tab -> Retry Pending Excel. The dashboard
  header warns you while anything is pending.
  Do not edit the Excel file by hand to fix a mistake — correct
  it in the software (Daily Entries) so the database stays true.

NEW DAY
  On 1 November the dashboard starts fresh and empty, and a new
  01-11-2026.xlsx is created. Yesterday's records are NOT deleted
  — open them any time in Reports & History.

TROUBLESHOOTING
  - App doesn't open: run Weighing-Scale-Debug.bat — it shows the error.
  - "Salesperson list is empty": add names in Settings first.
  - Excel not updating: check the dashboard header for the pending
    warning, close Excel, retry from the Backup tab.
  - Wrong weight entered: Daily Entries -> select it -> Correct
    Entry, with a reason. Do not edit the Excel file directly.

SOURCE FILES IN THIS FOLDER
  app.py           - the desktop interface (all 7 tabs)
  db.py            - SQLite database + weight calculations + audit
  excel_export.py  - daily Excel generation + locked-file queue
  test_all.py      - the 10 acceptance tests (run: python test_all.py)

Built for Ramanand Jewellers. Tested: box 126.44 g - sale 26.44 g = 100.00 g;
close/reopen recovery; new-day freshness with history intact;
return difference; Excel totals; locked-Excel queue with no data loss.

----------------------------------------------------------------
GITHUB AUTO-UPDATE (v1.1, online updates)
----------------------------------------------------------------
  The app checks GitHub on every launch (in the background) for a
  newer version, and also has "Check for Updates" on the Backup tab.
  Update channel (public repo, no login needed to read it):
      github.com/sbhan3967-png/weighing-scale-updates
      version.json  +  Weighing-Scale-Software.zip
  If a newer version is found, the app asks once. On Yes it
  downloads the new zip, installs it over the app folder and
  restarts. Your database, daily Excel files and backups live in
  Documents\Weighing Scale\ — outside the app folder — so updates
  never touch them.
  No internet? The check just finds nothing and the app runs
  normally, offline, as before.
  TO PUSH A NEW VERSION (from the developer side): replace
  Weighing-Scale-Software.zip in that repo and bump "version" in
  version.json. Every PC picks it up on next launch.

APP ICON
  icon.ico is the gold weighing-scale icon: it shows in the app
  window title bar and on the desktop shortcut created by Setup.bat.
