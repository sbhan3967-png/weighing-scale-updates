================================================================
 WEIGHING SCALE — Jewellery Box Management & Daily Weighing
================================================================
Offline Windows desktop software. No internet needed after setup.
No cloud, no login. Your data stays on your own computer.

WHAT IT DOES
  Morning: pick a Box Category + Salesperson, type the opening
  weight from the scale, SAVE BOX OUT. A Box ID is generated
  automatically, e.g. BOX-20261031-001.
  During the day: select the active box and Add Sale / Add Stock.
  Remaining weight updates instantly:
      Remaining = Opening + Stock Added - Sold
  Evening: select the box, Return Box, type the actual weight
  from the scale. The software shows Expected vs Actual and the
  Difference, and asks for an explanation if they differ.
  Every save writes to SQLite immediately AND updates that day's
  Excel file. Close the laptop, reopen later — everything is back.

INSTALL (one time, needs internet for Python/packages only)
  1. Extract the FULL zip to a folder (e.g. Documents\Weighing-Scale).
     Do not run Setup from inside the zip.
  2. Double-click Setup.bat and wait. If Python is missing it
     installs Python 3.12 by itself, installs openpyxl, and puts a
     "Weighing Scale" icon on your desktop.
  3. Double-click the desktop icon to start.
  NOTE: if your antivirus quarantines Setup.bat, restore it from
  Windows Security -> Protection history (it only installs Python
  and one Excel package — nothing harmful).

FIRST USE (2 minutes)
  1. Settings tab -> Salespersons -> type each name -> Add.
     (Categories are pre-loaded: Ladies Ring, Gents Ring, Ladies
     Chain, Gents Chain, Necklace, Earrings, Bangles, Bracelet,
     Pendant, Payal, Nose Pin, Mangalsutra, Other. Add/rename/
     deactivate any of them there.)
  2. Settings tab -> General -> check your showroom name.
  3. Dashboard -> pick Category + Salesperson, type opening
     weight, SAVE BOX OUT. Done — the box is active.

DAILY USE
  Dashboard: today's boxes, opening, sold and remaining totals
  are at the top. Active boxes are listed below.
  Add Sale: select a box -> Add Sale -> type sold weight.
    If the sale is bigger than the remaining weight, the software
    STOPS and asks for an override with a reason. Without a reason
    a negative remaining weight is not allowed.
  Add Stock: select a box -> Add Stock -> type weight added.
  Return Box: select a box -> Return Box -> type actual weight.
  View History: select a box -> View History -> every transaction
    plus the audit trail (corrections and voids).
  Daily Entries: correct or void an entry — a reason is required
    and the old value stays in the audit trail. Nothing is ever
    silently overwritten.
  Reports & History: pick any past date, filter by category /
    salesperson / type, search by Box ID, re-export or open Excel.
  Salesperson Reports: per-day boxes, categories, opening, sold,
    returned, active and remaining per salesperson.
  Backup & Restore: backup runs automatically on every close.
    Backup Now / Restore from Backup are on this tab.

WHERE YOUR DATA LIVES
  Documents\Weighing Scale\
      Database\weighing_scale.db        <- source of truth
      Daily Reports\2026\October\31-10-2026.xlsx
      Backups\Database Backups\weighing_scale_YYYYMMDD_HHMMSS.db
  Change the folder in Settings -> Change Folder (the database
  is copied to the new folder; restart the app after changing).

EXCEL — IMPORTANT
  One Excel file per date, never two. It is regenerated from the
  database on every save, with a gold header, 2-decimal weights,
  a daily summary, category-wise totals and salesperson-wise
  totals, plus a "Boxes Summary" sheet.
  If the Excel file is OPEN when you save, nothing is lost: the
  database save succeeds and the Excel update is QUEUED. Close
  Excel, then Backup tab -> Retry Pending Excel. The dashboard
  header warns you while anything is pending.
  Do not edit the Excel file by hand to fix a mistake — correct
  it in the software (Daily Entries) so the database stays true.

NEW DAY
  On 1 November the dashboard starts fresh and empty, and a new
  01-11-2026.xlsx is created. Yesterday's records are NOT deleted
  — open them any time in Reports & History.

TROUBLESHOOTING
  - App doesn't open: run Weighing-Scale-Debug.bat — it shows the error.
  - "Salesperson list is empty": add names in Settings first.
  - Excel not updating: check the dashboard header for the pending
    warning, close Excel, retry from the Backup tab.
  - Wrong weight entered: Daily Entries -> select it -> Correct
    Entry, with a reason. Do not edit the Excel file directly.

SOURCE FILES IN THIS FOLDER
  app.py           - the desktop interface (all 7 tabs)
  db.py            - SQLite database + weight calculations + audit
  excel_export.py  - daily Excel generation + locked-file queue
  test_all.py      - the 10 acceptance tests (run: python test_all.py)

Built for Ramanand Jewellers. Tested: box 126.44 g - sale 26.44 g = 100.00 g;
close/reopen recovery; new-day freshness with history intact;
return difference; Excel totals; locked-Excel queue with no data loss.

----------------------------------------------------------------
GITHUB AUTO-UPDATE (v1.1, online updates)
----------------------------------------------------------------
  The app checks GitHub on every launch (in the background) for a
  newer version, and also has "Check for Updates" on the Backup tab.
  Update channel (public repo, no login needed to read it):
      github.com/sbhan3967-png/weighing-scale-updates
      version.json  +  Weighing-Scale-Software.zip
  If a newer version is found, the app asks once. On Yes it
  downloads the new zip, installs it over the app folder and
  restarts. Your database, daily Excel files and backups live in
  Documents\Weighing Scale\ — outside the app folder — so updates
  never touch them.
  No internet? The check just finds nothing and the app runs
  normally, offline, as before.
  TO PUSH A NEW VERSION (from the developer side): replace
  Weighing-Scale-Software.zip in that repo and bump "version" in
  version.json. Every PC picks it up on next launch.

APP ICON
  icon.ico is the gold weighing-scale icon: it shows in the app
  window title bar and on the desktop shortcut created by Setup.bat.

----------------------------------------------------------------
WHY THE CMD WINDOW OPENED (v1.0/v1.1) — FIXED IN v1.2
----------------------------------------------------------------
  The old launcher ran the app with python.exe, which is a
  console program: Windows kept its black cmd window open for
  as long as the app ran, and closing that window killed the app.
  v1.2 fixes it two ways:
  1. Weighing-Scale.bat now uses pythonw.exe (windowless Python)
     and exits immediately, so no cmd window stays open.
  2. The desktop shortcut (recreated by Setup.bat) now points to
     Weighing-Scale.vbs, which runs the launcher completely
     hidden — not even a brief cmd flash.
  If you launch Weighing-Scale.bat directly you may still see a
  very brief flash; launch from the desktop icon for none at all.
  Weighing-Scale-Debug.bat still opens a cmd window on purpose,
  so errors are visible when troubleshooting.

----------------------------------------------------------------
SALE PAYMENT DETAILS (v1.3)
----------------------------------------------------------------
  When you Add Sale, the sale window now asks for:
    Mode of Transaction — dropdown: CASH, UPI, CARD, BANK TRANSFER,
      CREDIT / UDHAAR, CHEQUE, OTHER (defaults to CASH, as on the
      old manual sheet)
    Amount (Rs) — typed by you, e.g. 250000
    Bill No. (BN) — typed by you, e.g. 25150
  Amount and Bill No. may be left blank if you don't have them yet;
  they are saved with the sale and show in Daily Entries, Reports,
  Box History and the daily Excel file (new Mode / Amount / Bill
  columns), and the daily summary now totals the sale amount in Rs.
  Old databases are upgraded automatically on first launch of v1.3
  — your existing sales simply show blank Mode/Amount/Bill No.

----------------------------------------------------------------
CLIENT PC INSTALL — WHAT SETUP INSTALLS AUTOMATICALLY (v1.4)
----------------------------------------------------------------
  On a brand-new client PC, the client does NOTHING except:
    1. Extract the zip to a folder.
    2. Double-click Setup.bat once.
    3. Double-click the desktop "Weighing Scale" icon.
  Setup.bat then installs/verifies, in order, with no manual steps:
    a. Python 3.12 — if Python is missing, Setup installs it
       itself (first via winget, else by downloading the official
       Python 3.12 installer from python.org, per-user, no admin).
       It only accepts a Python that actually runs — the Windows
       Microsoft Store stub that says "Python was not found" is
       ignored, and known install folders are searched even if
       Python is not on PATH.
    b. tkinter + sqlite3 — checked (both ship inside Python on
       Windows; if tkinter is missing Setup stops with a clear
       message to reinstall Python with "tcl/tk and IDLE" ticked).
    c. Python packages — openpyxl (for Excel) + its dependency
       et_xmlfile, installed from the wheels/ folder bundled in
       this zip, so packages install EVEN WITHOUT INTERNET.
       If the wheels folder is missing, Setup falls back to
       downloading them online (pip).
    d. App self-check — Setup runs: python app.py --check
       which proves tkinter + sqlite3 + openpyxl + the database
       all work, and prints the version. Setup stops with an
       error instead of claiming success if this fails.
    e. Data folders + desktop shortcut — Documents\Weighing Scale
       (Database / Daily Reports / Backups) is created, and the
       shortcut points to the hidden launcher (no cmd window).
  After Setup, the app works fully OFFLINE. Internet is needed
  only once, and only if Python itself is missing (step a).
  Future updates need NO Setup re-run: the app auto-updates
  from GitHub (see GITHUB AUTO-UPDATE above).
  Files that make this work: Setup.bat, requirements.txt,
  wheels/openpyxl-*.whl, wheels/et_xmlfile-*.whl, app.py --check.

----------------------------------------------------------------
BOX IDENTIFICATION — GOLD OR SILVER (v1.5)
----------------------------------------------------------------
  Every box now carries a Metal identity: GOLD or SILVER.
  Dashboard -> BOX OUT panel has a Metal dropdown (defaults to
  GOLD) next to Category and Salesperson. Pick it when the box
  is taken out — it stays with that box for its whole life.
  Metal shows in: Active Boxes table, Daily Entries, Reports &
  History (with a Metal filter: GOLD / SILVER / all), Box History,
  and the daily Excel file (new Metal column + METAL-WISE TOTALS
  section: boxes, opening, sold, added and remaining per metal).
  Old boxes made before v1.5 show a blank Metal (they were made
  before this field existed); their weights and history are
  unchanged, and the database upgrades automatically.
