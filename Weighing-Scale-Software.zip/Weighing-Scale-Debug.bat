@echo off
REM Debug launch: uses the SAME Python as the desktop icon.
REM v1.29: Setup's locked Python (python_used.txt) first, then the
REM normal search. Prints the Python version first, so a screenshot
REM shows exactly which interpreter ran.
cd /d "%~dp0"
if not exist python_used.txt goto :search
set /p PY=<python_used.txt
if not defined PY goto :search
set PY="%PY%"
echo Using locked Python:
%PY% --version
goto :run
:search
set PY=
for %%P in (
    "%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
    "%LOCALAPPDATA%\Programs\Python\Python313\python.exe"
    "%LOCALAPPDATA%\Programs\Python\Python314\python.exe"
    "%LOCALAPPDATA%\Programs\Python\Python315\python.exe"
    "%ProgramFiles%\Python312\python.exe"
    "%ProgramFiles%\Python313\python.exe"
    "%ProgramFiles%\Python314\python.exe"
    "%ProgramFiles%\Python315\python.exe"
    "C:\Python312\python.exe"
    "C:\Python313\python.exe"
    "C:\Python314\python.exe"
    "C:\Python315\python.exe"
) do (
    if not defined PY if exist %%P set PY="%%P"
)
if not defined PY (
    py -3 --version >nul 2>nul
    if %errorlevel%==0 set PY=py -3
)
if not defined PY set PY=python
echo Using Python:
%PY% --version
:run
%PY% app.py
pause
